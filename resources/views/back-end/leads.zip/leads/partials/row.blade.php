<tr id="lead-{{ $lead->id }}">
    <td class="text-center">{{ $index + 1 }}</td>

    <td class="text-center" style="display: flex; justify-content: center; gap: 8px;">
         @if($lead->flag == '1')
            <div class="form-check form-check-sm form-check-custom form-check-solid m-5">
                <input onchange="checkedLead(this, {{ $lead->id }})" class="form-check-input widget-13-check" type="checkbox" checked value="1">
            </div>
        @else
            <div class="form-check form-check-sm form-check-custom form-check-solid m-5">
                <input onchange="checkedLead(this, {{ $lead->id }})" class="form-check-input widget-13-check" type="checkbox" value="1">
            </div>
        @endif
        <div class="form-check form-switch my-auto">
            <input class="form-check-input" type="checkbox" id="{{ $lead->id }}" role="switch" checked
                onchange="handleChange(this, {{ $lead->id }})">
        </div>
        <a href="{{ url('/lead/edit/' . $lead->id) }}" target="_blank" class="btn btn-sm btn-secondary">
            <li class="fa fa-edit"></li>
        </a>
        <button type="button" class="btn btn-sm btn-primary" onclick="convert(this, {{ $lead->id }})"
            id="convert-btn-{{ $lead->id }}">
            <i class="fa fa-sync"></i>
        </button>

        @if (auth()->user()->role_id == 1)
            <button type="button" id="loadTemplatesBtn{{ $lead->user->id }}" class="btn btn-sm btn-success"
                onclick="loadTemplates({{ $lead->user->id }})">
                <i class="fa fa-whatsapp"></i>
            </button>
           
        @endif

        <button type="button" id="loadChat{{ $lead->id }}" class="btn btn-sm btn-warning"
            onclick="loadchat({{ $lead->id }})">
            <li class="fa fa-phone"></li>
        </button>
        <!-- Fullscreen Chat Modal -->


        

    </td>
    <td class="text-center">
        @if ($lead['frontendorder'] == '1')
            <span class="badge badge-light-primary fs-7 fw-bold">{{ $lead->order_id }}</span>
        @else
            {{ $lead->order_id }}
        @endif
        <br>
        @if ($lead['resit'] == 'on')
            <span class="badge badge-light-danger fs-7 fw-bold">Resit Work</span>
        @endif
        @if ($lead['service_type'] == 'First Class Work')
            <span class="badge badge-light-info fs-7 fw-bold">First Class Work</span>
        @endif
    </td>
    <td>
        {{ $lead->user->name ?? 'No Name' }}<br>
        <span class="badge badge-light-danger fs-7 fw-bold">{{ $lead->user->mobile_no ?? '' }}</span>
    </td>
    <td>{{ \Carbon\Carbon::parse($lead->create_at)->format('d M Y') }}</td>
    <td>
        {!! $lead->project_title
            ? e($lead->project_title)
            : '<span class="badge badge-light-danger fs-7 fw-bold">No Title</span>' !!}
        @if ($lead->semester)
            <br><span class="badge badge-light-success fs-7">Semester: {{ $lead->semester }}</span>
        @endif
        @if ($lead->tech === 'on')
            <br><span class="badge badge-light-success fs-7">Technical Work</span>
        @endif
        @if ($lead->module_code)
            <br><span class="badge badge-light-danger fs-7">{{ $lead->module_code }}</span>
        @endif
    </td>
    <td>
        {!! $lead->pages ? e($lead->pages) : '<span class="badge badge-light-danger fs-7 fw-bold">No Pages</span>' !!}
    </td>
    <td>
        {!! $lead->price ? e($lead->price) : '<span class="badge badge-light-danger fs-7 fw-bold">No Price</span>' !!}
    </td>
    <td>
        {{ \Carbon\Carbon::parse($lead->deadline)->format('d M Y') }}
        @if ($lead->delivery_time)
            <span class="badge badge-light-info fs-7 fw-bold">({{ $lead->delivery_time }})</span>
        @endif

        @if ($lead->draft_required == 'Yes')
            <br><span class="badge badge-light-success fs-7">{{ $lead->draft_date }}</span>
            <br><span class="badge badge-light-success fs-7">{{ $lead->draft_time }}</span>
        @endif
    </td>
</tr>

<style>
    /* Slide-in animation */
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }

        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    /* Desktop defaults */


    .modal.fade.custom-slide-right .modal-dialog {
        position: fixed;
        top: 0;
        right: 0;
        margin: 0;
        height: 100vh;

        width: 40%;
        transform: translateX(100%);
        transition: transform 0.4s ease-out;
        display: flex;
        flex-direction: column;
    }

    .modal.fade.custom-slide-right.show .modal-dialog {
        transform: translateX(0);
        animation: slideInRight 0.4s ease-out;
        border-radius: 0;
    }

    /* Modal content should fill height */
    .modal-content {
        height: 100vh;
        display: flex;
        flex-direction: column;
        border-radius: 0;
    }

    /* Body grows and scrolls as needed */
    .modal-body {
        flex: 1;
        overflow-y: auto;
    }

    /* Responsive for mobile */
    @media (max-width: 768px) {
        .modal.fade.custom-slide-right .modal-dialog {
            width: 100%;
        }
    }
</style>
