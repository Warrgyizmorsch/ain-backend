@extends('layouts.app')

@section('content')
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <div class="col-xl-12">
        <!-- Filter Card -->
        <div class="card card-xxl-stretch mb-5 mb-xl-8">
            <div class="card-body py-3">
                <div class="row mb-3">
                    <div class="col-md-3">
                        <input type="text" id="search_order" class="form-control form-control-solid" placeholder="Search by Order ID / Title">
                    </div>
                    <div class="col-md-3">
                        <select id="status_filter" class="form-select form-select-solid">
                            <option value="">Select Status</option>
                            <option value="Quote">Quote</option>
                            <option value="Waiting">Waiting</option>
                            <option value="Confirmation">Confirmation</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="type_filter" class="form-select form-select-solid">
                            <option value="">Search Tech / Resit / First Class</option>
                            <option value="First">First Class Work</option>
                            <option value="Resit">Resit</option>
                            <option value="Technical">Technical</option>
                        </select>
                    </div>
                    <div class="col-md-3 fv-row">
                        <input type="text" list="searchDatalist" id="searchInput" name="user" class="form-control form-control-solid" placeholder="Search..." autocomplete="off">
                        <!-- Datalist for displaying search results -->
                        <datalist id="searchDatalist"></datalist>
                        <!-- Container to display search results -->
                        <div id="searchResultss"></div>
                        <!-- Hidden field to store the selected value -->
                        <input type="hidden" id="selectedValue" name="uid">
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-3">
                        <input type="date" id="date_from" class="form-control form-control-solid">
                    </div>
                    <div class="col-md-3">
                        <input type="date" id="date_to" class="form-control form-control-solid">
                    </div>
                    <div class="col-md-3">
                        <select id="date_type" class="form-select form-select-solid">
                            <option value="">Date Type</option>
                            <option value="Deadline">Deadline</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <a href="/lead" class="btn btn-sm btn-light">Clear Filters</a>
                        <button id="applyButton" class="btn btn-sm btn-primary">Search</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Leads Table -->
        <div class="card card-xl-stretch mb-5">
            <div class="card-header border-0 pt-5 d-flex justify-content-between align-items-center">
                <div>
                    <h3 class="card-title fw-bolder fs-3 mb-1">Active Leads</h3>
                    <span class="text-muted mt-1 fw-bold fs-7">Live data with real-time update</span>
                </div>
                <div class="card-toolbar">
                    <button class="btn btn-sm btn-light-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_create_appaa_newLeads">
                        <span class="svg-icon svg-icon-2">+</span> Add New Lead
                    </button>
                </div>
            </div>
            <div class="card-body py-3">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle" id="leads-table">
                        <thead>
                            <tr class="fw-bolder text-muted bg-light">
                                <th class="text-center">sr</th>
                                <th class="text-center">Action</th>
                                <th>Order ID</th>
                                <th>Name</th>
                                <th>Order Date</th>
                                <th>Project Title</th>
                                <th>Words</th>
                                <th>Price</th>
                                <th>Delivery Date</th>
                            </tr>
                        </thead>
                        <tbody id="lead-rows">
                            @foreach ($leads as $index => $lead)
                                @include('back-end.leads.partials.row', ['lead' => $lead])
                            @endforeach
                        </tbody>
                    </table>
                    <div id="load-more-wrapper" class="text-center mt-4">
                        <button id="load-more" class="btn btn-light-primary">Load More</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('back-end.leads.partials.create')
</div>
 @include('back-end.leads.partials.preloader')
 @include('back-end.leads.ajax')
 @include('back-end.leads.partials.models', ['lead' => $lead])

@endsection
