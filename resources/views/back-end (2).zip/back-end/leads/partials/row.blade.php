<tr id="lead-{{ $lead->id }}">
    <td class="text-center">{{ $index + 1}}</td>
    
    <td class="text-center" style="display: flex; justify-content: center; gap: 8px;">
         <div class="form-check form-switch my-auto">
            <input 
                class="form-check-input" 
                type="checkbox" 
                id="{{ $lead->id }}" 
                role="switch" 
                checked
                onchange="handleChange(this, {{ $lead->id }})"
            >
        </div>
        <a href="{{ url('/lead/edit/' . $lead->id) }}" target="_blank" class="btn btn-sm btn-secondary">
            <li class="fa fa-edit"></li>
        </a>
        <button type="button"
                class="btn btn-sm btn-primary"
                onclick="convert(this, {{ $lead->id }})"
                id="convert-btn-{{ $lead->id }}">
            <i class="fa fa-sync"></i>
        </button>
    </td>
    <td class="text-center">
     @if ($lead['frontendorder'] == '1')
            <span class="badge badge-light-primary fs-7 fw-bold">{{ $lead->order_id }}</span>
        @else
            {{ $lead->order_id }}
        @endif
        <br>
        @if ($lead['resit'] == 'on')
            <span class="badge badge-light-danger fs-7 fw-bold">Resit Work</span>
        @endif
        @if ($lead['service_type'] == 'First Class Work')
            <span class="badge badge-light-info fs-7 fw-bold">First Class Work</span>
        @endif
    </td>
    <td>
        {{ $lead->user->name ?? 'No Name' }}<br>
        <span class="badge badge-light-danger fs-7 fw-bold">{{ $lead->user->mobile_no ?? '' }}</span>
    </td>
    <td>{{ \Carbon\Carbon::parse($lead->create_at)->format('d M Y') }}</td>
    <td>
        {!! $lead->project_title ? e($lead->project_title) : '<span class="badge badge-light-danger fs-7 fw-bold">No Title</span>' !!}
        @if ($lead->semester)
            <br><span class="badge badge-light-success fs-7">Semester: {{ $lead->semester }}</span>
        @endif
        @if ($lead->tech === 'on')
            <br><span class="badge badge-light-success fs-7">Technical Work</span>
        @endif
        @if ($lead->module_code)
            <br><span class="badge badge-light-danger fs-7">{{ $lead->module_code }}</span>
        @endif
    </td>
    <td>
        {!! $lead->pages ? e($lead->pages) : '<span class="badge badge-light-danger fs-7 fw-bold">No Pages</span>' !!}
    </td>
    <td>
        {!! $lead->price ? e($lead->price) : '<span class="badge badge-light-danger fs-7 fw-bold">No Price</span>' !!}
    </td>
    <td>
        {{ \Carbon\Carbon::parse($lead->deadline)->format('d M Y') }}
        @if ($lead->delivery_time)
            <span class="badge badge-light-info fs-7 fw-bold">({{ $lead->delivery_time }})</span>
        @endif

        @if ($lead->draft_required == 'Yes')
            <br><span class="badge badge-light-success fs-7">{{ $lead->draft_date }}</span>
            <br><span class="badge badge-light-success fs-7">{{ $lead->draft_time }}</span>
        @endif
    </td>
</tr>
