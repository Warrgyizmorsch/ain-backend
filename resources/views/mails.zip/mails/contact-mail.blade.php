<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Contact Message</title>
    <style>
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f5f3ff;
            margin: 0;
            padding: 40px 0;
        }
        .email-container {
            max-width: 640px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        }
        .email-header {
            background: linear-gradient(135deg, #4f46e5, #7c3aed);
            padding: 24px;
            text-align: center;
        }
        .email-header img {
            max-width: 120px;
            height: auto;
            display: block;
            margin: 0 auto;
        }
        .email-header h1 {
            color: #ffffff;
            font-size: 24px;
            font-weight: 600;
            margin: 16px 0 0;
        }
        .email-content {
            padding: 32px;
            color: #1f2937;
        }
        .email-content p {
            font-size: 16px;
            line-height: 1.6;
            margin: 12px 0;
        }
        .email-content strong {
            color: #111827;
            font-weight: 600;
        }
        .message-box {
            background: #f8fafc;
            border-left: 4px solid #4f46e5;
            padding: 16px;
            border-radius: 6px;
            margin-top: 16px;
        }
        .email-footer {
            background: #faf5ff;
            padding: 24px;
            text-align: center;
            border-top: 1px solid #e5e7eb;
        }
        .email-footer p {
            font-size: 14px;
            color: #6b7280;
            margin: 8px 0;
        }
        .email-footer a {
            color: #4f46e5;
            text-decoration: none;
            font-weight: 500;
        }
        .email-footer a:hover {
            text-decoration: underline;
        }
        @media screen and (max-width: 600px) {
            .email-container {
                margin: 0 16px;
            }
            .email-content {
                padding: 24px;
            }
            .email-header h1 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="email-header">
            <h1>New Contact Message Received</h1>
        </div>
        <div class="email-content">
            <p><strong>Name:</strong> {{ $details['name'] }}</p>
            <p><strong>Email:</strong> {{ $details['email'] }}</p>
            <p><strong>Mobile:</strong> {{ $details['mobile'] ?? 'N/A' }}</p>
            <p><strong>Message:</strong></p>
            <div class="message-box">
                <p>{{ $details['message'] }}</p>
            </div>
        </div>
        <div class="email-footer">
            <p>This email was automatically sent from the website contact form.</p>
            <p><a href="https://www.assignnmentinneed.com/">Visit our website</a> | <a href="mailto:order@assignnmentinneed.com">Contact Support</a></p>
            <p>© 2025 Assignment In Need. All rights reserved.</p>
        </div>
    </div>
</body>
</html>