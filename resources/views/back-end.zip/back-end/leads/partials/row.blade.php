<tr id="lead-{{ $lead->id }}">
    <td class="text-center" style="padding-right: 0px;">{{ $index + 1 }}</td>

    <td class="text-center">
        <div style="display: flex; justify-content: center; align-items: center; gap: 8px;">
            @if($lead->flag == '1')
                <div class="form-check form-check-sm form-check-custom form-check-solid">
                    <input onchange="checkedLead(this, {{ $lead->id }})" class="form-check-input widget-13-check" type="checkbox"
                        checked value="1">
                </div>
            @else
                <div class="form-check form-check-sm form-check-custom form-check-solid">
                    <input onchange="checkedLead(this, {{ $lead->id }})" class="form-check-input widget-13-check" type="checkbox"
                        value="1">
                </div>
            @endif
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" id="{{ $lead->id }}" role="switch" checked
                    onchange="handleChange(this, {{ $lead->id }})">
            </div>
            <a href="{{ url('/lead/edit/' . $lead->id) }}" target="_blank" class="btn btn-sm btn-icon"
                style="background-color: #1e1e2d;">
                <li style="color: white;" class="fa fa-edit"></li>
            </a>
            <button type="button" class="btn btn-sm btn-primary btn-icon" onclick="convert(this, {{ $lead->id }})"
                id="convert-btn-{{ $lead->id }}">
                <i class="fa fa-sync"></i>
            </button>
            
            <!-- @if (auth()->user()->role_id == 1)
                <button type="button" id="loadTemplatesBtn{{ $lead->user->id ?? '' }}" class="btn btn-sm btn-success btn-icon"
                    onclick="loadTemplates({{ $lead->user->id ?? '' }})">
                    <i class="fa fa-whatsapp"></i>
                </button>

            @endif
             -->
            <button type="button" id="loadChat{{ $lead->id }}" class="btn btn-sm btn-warning btn-icon"
                onclick="loadchat({{ $lead->id }})">
                <li class="fa fa-phone"></li>
            </button>
            <!-- Fullscreen Chat Modal -->
             <!-- Select per lead/order -->
           <!-- Assign Type Toggle -->
<div class="form-check form-switch" style="margin-left:6px;">
    <input
        class="form-check-input assign-toggle"
        type="checkbox"
        id="type{{ $lead->id }}"
        {{ ($lead->assign_type ?? 0) == 1 ? 'checked' : '' }}
        onchange="handleTypeToggle(this, {{ $lead->id }})"
    >
</div>
<style>
.assign-toggle{
    transform: scale(1.1);
    cursor: pointer;
}

/* OFF = AIN (Yellow) */
.assign-toggle:not(:checked){
    background-color:#FFC107 !important;
    border-color:#e0a800 !important;
}

/* ON = Let's Learn (Green) */
.assign-toggle:checked{
    background-color:#28a745 !important;
    border-color:#1e7e34 !important;
}
</style>
<script>
function handleTypeToggle(el, leadId)
{
    let assign_type = el.checked ? 1 : 0;

    fetch("{{ url('/lead/assign-type') }}", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRF-TOKEN": "{{ csrf_token() }}"
        },
        body: JSON.stringify({
            lead_id: leadId,
            assign_type: assign_type
        })
    })
    .then(res => res.json())
    .then(data => {
        if(!data.status){
            alert("Failed to update");
        }
    })
    .catch(() => alert("Server error"));
}
</script>
<select
    id="leadReason{{ $lead->id }}"
    name="lead_reason[{{ $lead->id }}]"
    class="mini-select"
    onchange="handleLeadReason({{ $lead->id }})"
>
    <option value="">Select</option>
    <option value="Hot" {{ ($lead->l_status ?? '') == 'Hot' ? 'selected' : '' }}>Hot</option>
    <option value="Price" {{ ($lead->l_status ?? '') == 'Price' ? 'selected' : '' }}>Price</option>
    <option value="Deadline" {{ ($lead->l_status ?? '') == 'Deadline' ? 'selected' : '' }}>Deadline</option>
    <option value="Feedback" {{ ($lead->l_status ?? '') == 'Feedback' ? 'selected' : '' }}>Feedback</option>
    <option value="Serious Concern" {{ ($lead->l_status ?? '') == 'Serious Concern' ? 'selected' : '' }}>Serious Concern</option>
    <option value="Marks" {{ ($lead->l_status ?? '') == 'Marks' ? 'selected' : '' }}>Marks</option>
    <option value="Unknown" {{ ($lead->l_status ?? '') == 'Unknown' ? 'selected' : '' }}>Unknown</option>   
    <option value="Quality" {{ ($lead->l_status ?? '') == 'Quality' ? 'selected' : '' }}>Quality</option>
    <option value="Customer Service" {{ ($lead->l_status ?? '') == 'Customer Service' ? 'selected' : '' }}>Customer Service</option>
</select>
<style>
.mini-select{
    width:130px !important;
    height:32px;
    padding:0 6px;
    font-size:12px;
    border:1px solid #d1d5db;
    border-radius:6px;
}
</style>
<script>
function handleLeadReason(leadId)
{
    let value = document.getElementById('leadReason'+leadId).value;

    fetch("{{ url('/lead-reason-update') }}", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRF-TOKEN": "{{ csrf_token() }}"
        },
        body: JSON.stringify({
            lead_id: leadId,
            l_status: value   // 🔴 change here
        })
    })
    .then(res => res.json())
    .then(data => {
        if(!data.status){
            alert("Update failed");
        }
    })
    .catch(() => alert("Server error"));
}
</script>


        </div>


        

    </td>
    <td class="text-center">
        @if ($lead['frontendorder'] == '1')
            <span class="badge badge-light-primary fs-7 fw-bold">{{ $lead->order_id }}</span>
        @else
            {{ $lead->order_id }}
        @endif
        <br>
        @if ($lead['resit'] == 'on')
            <span class="badge badge-light-danger fs-7 fw-bold">Resit Work</span>
        @endif
        @if ($lead['service_type'] == 'First Class Work')
            <span class="badge badge-light-info fs-7 fw-bold">First Class Work</span>
        @endif
    </td>
    <td class="text-center">
        {{ $lead->user->name ?? 'No Name' }}<br>
        <span class="badge badge-light-danger fs-7 fw-bold">{{ $lead->user->mobile_no ?? '' }}</span>
    </td>
    <td class="text-center">{{ \Carbon\Carbon::parse($lead->create_at)->format('d M Y') }}</td>
    <td class="text-center">
        {!! $lead->project_title
    ? e($lead->project_title)
    : '<span class="badge badge-light-danger fs-7 fw-bold">No Title</span>' !!}
        @if ($lead->semester)
            <br><span class="badge badge-light-success fs-7">Semester: {{ $lead->semester }}</span>
        @endif
        @if ($lead->tech === 'on')
            <br><span class="badge badge-light-success fs-7">Technical Work</span>
        @endif
        @if ($lead->module_code)
            <br><span class="badge badge-light-danger fs-7">{{ $lead->module_code }}</span>
        @endif
    </td>
    <td class="text-center">
        {!! $lead->pages ? e($lead->pages) : '<span class="badge badge-light-danger fs-7 fw-bold">No Pages</span>' !!}
    </td>
    <td class="text-center">
        {!! $lead->price ? e($lead->price) : '<span class="badge badge-light-danger fs-7 fw-bold">No Price</span>' !!}
    </td>
    <td class="text-center">
        {{ \Carbon\Carbon::parse($lead->deadline)->format('d M Y') }}
        @if ($lead->delivery_time)
            <span class="badge badge-light-info fs-7 fw-bold">({{ $lead->delivery_time }})</span>
        @endif

        @if ($lead->draft_required == 'Yes')
            <br><span class="badge badge-light-success fs-7">{{ $lead->draft_date }}</span>
            <br><span class="badge badge-light-success fs-7">{{ $lead->draft_time }}</span>
        @endif
    </td>
</tr>

<style>
    /* Slide-in animation */
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }

        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    /* Desktop defaults */


    .modal.fade.custom-slide-right .modal-dialog {
        position: fixed;
        top: 0;
        right: 0;
        margin: 0;
        height: 100vh;

        width: 40%;
        transform: translateX(100%);
        transition: transform 0.4s ease-out;
        display: flex;
        flex-direction: column;
    }

    .modal.fade.custom-slide-right.show .modal-dialog {
        transform: translateX(0);
        animation: slideInRight 0.4s ease-out;
        border-radius: 0;
    }

    /* Modal content should fill height */
    .modal-content {
        height: 100vh;
        display: flex;
        flex-direction: column;
        border-radius: 0;
    }

    /* Body grows and scrolls as needed */
    .modal-body {
        flex: 1;
        overflow-y: auto;
    }

    /* Responsive for mobile */
    @media (max-width: 768px) {
        .modal.fade.custom-slide-right .modal-dialog {
            width: 100%;
        }
    }
</style>
