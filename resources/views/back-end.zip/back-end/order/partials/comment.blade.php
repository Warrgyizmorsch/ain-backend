<div style="overflow: hidden;" id="kt_drawer_chat{{ $order->id }}" class="bg-body" data-kt-drawer="true"
    data-kt-drawer-name="chat{{ $order->id }}" data-kt-drawer-activate="true" data-kt-drawer-overlay="true"
    data-kt-drawer-width="{default:'90%', 'md':'60%', 'lg':'40%'}" data-kt-drawer-direction="end"
    data-kt-drawer-toggle="#kt_drawer_chat_toggle{{ $order->id }}"
    data-kt-drawer-close="#kt_drawer_chat_close{{ $order->id }}">

    <!-- Drawer Content -->
    <div class="card w-100 rounded-0 border-0 h-100">
        <!-- Header -->
        <div class="card-header bg-primary text-white" id="kt_drawer_chat_messenger_header" style="border-radius: 0px;">
            <div class="card-title">
                <div class="d-flex flex-column">
                    <span class="fs-4 fw-bold text-white">Order: {{ $order->order_id }}</span>
                    <small class="text-white-50">Feedback Thread</small>
                </div>
            </div>
            <div class="card-toolbar">
                <div class="btn btn-sm btn-icon btn-close-white" id="kt_drawer_chat_close{{ $order->id }}">
                    <i class="bi bi-x-lg fs-2 text-white"></i>
                </div>
            </div>
        </div>

        <!-- Messages Area -->
        <div class="card-body p-4">
            <div class="chat-box" id="messageContainer{{ $order->id }}">
                @foreach($order->feedback->sortBy('created_at') as $feedback)
                    @if($feedback->comment != '')
                        @php $isCurrentUser = $feedback->created_by == Auth::user()->id; @endphp
                        <div class="d-flex mb-2 {{ $isCurrentUser ? 'justify-content-end' : 'justify-content-start' }}">
                            <div class="message-bubble {{ $isCurrentUser ? 'sent' : 'received' }}">
                                <div class="message-text">
                                    {{ $feedback->comment }}
                                </div>
                                <div class="message-meta">
                                    {{ $isCurrentUser ? 'You' : $feedback->user->name }} •
                                    {{ $feedback->created_at->format('h:i A') }}
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>

        <!-- Footer Input -->
        <div class="card-footer border-top p-3 d-flex">
            <input type="text" id="description{{ $order->id }}" class="form-control me-2"
                placeholder="Type your message...">
            <button class="btn btn-primary" onclick="sendFeedback({{ $order->id }})">Send</button>
        </div>
    </div>
</div>

<!-- Chat Bubble Styles -->
<style>
    .bg-primary {
        background-color: var(--primary);
    }

    .chat-box {
        padding: 1rem;
        overflow-y: auto;
        max-height: 400px;
        display: flex;
        flex-direction: column;
    }

    .message-bubble {
        max-width: 75%;
        padding: 10px 14px;
        border-radius: 18px;
        box-shadow: 0 2px 3px rgba(0, 0, 0, 0.1);
        font-size: 0.95rem;
        line-height: 1.4;
        position: relative;
    }

    .message-bubble.sent {
        background-color: #dcf8c6;
        align-self: flex-end;
        border-bottom-right-radius: 4px;
    }

    .message-bubble.received {
        background-color: #f9f9f9;
        align-self: flex-start;
        border-bottom-left-radius: 4px;
    }

    .message-meta {
        font-size: 0.7rem;
        color: #666;
        margin-top: 5px;
        text-align: right;
    }

    .message-text {
        word-wrap: break-word;
    }
</style>

<!-- Feedback Script -->
<script>
    function sendFeedback(orderId) {
        var message = $('#description' + orderId).val();

        if (message.trim() === '') return;

        $.ajax({
            type: 'POST',
            url: 'comment/' + orderId,
            data: {
                _token: '{{ csrf_token() }}',
                comment: message,
                order_id: orderId
            },
            success: function (response) {
                var container = $('#messageContainer' + orderId);
                var newMsg = `
                    <div class="d-flex mb-2 justify-content-end">
                        <div class="message-bubble sent">
                            <div class="message-text">${response.message}</div>
                            <div class="message-meta">You • ${response.created_at}</div>
                        </div>
                    </div>
                `;
                container.append(newMsg);
                $('#description' + orderId).val('');
                container.scrollTop(container[0].scrollHeight);
            },
            error: function (err) {
                console.error('Send failed:', err);
            }
        });
    }
</script>