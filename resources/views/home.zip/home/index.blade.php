@extends('frontend-layouts.app')
@section('content')

  @include('home.section.hero')

  @include('home.section.academic_success')

  @include('home.section.about-us')

  @include('home.section.how-it-works')

  @include('home.section.expert-section')


  @include('home.section.choose-us')

  @include('home.section.quality-assurance')

  @include('home.section.numbers')

  @include('home.section.writing-services')

  @include('home.section.sample-guide')

  @include('home.section.samples-demo')

  @include('home.section.ticket')

  @include('home.section.subjects') 

  @include('home.section.guidance-section') 

  @include('home.section.whatsapp')

  @include('home.section.grades')



  

  @include('home.section.banner')

  @include('home.section.video-testimonial')

  <!-- @include('home.section.boost') -->

  @include('home.section.blog')

  @include('home.section.scrollable')

  @include('home.section.faq-section')
  <!-- JS -->
  <script>
    function loadYoutube(el) {
    const videoId = el.getAttribute('data-video-id');
    const iframe = document.createElement('iframe');
    iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;
    iframe.setAttribute('frameborder', '0');
    iframe.setAttribute('allowfullscreen', '');
    iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture');
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    el.innerHTML = '';
    el.appendChild(iframe);
    }
  </script>
@endsection