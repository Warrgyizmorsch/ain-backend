<section class="bg-hero">
    <div class="container-section">
        <div class="hero-content">
            <!-- Content Column -->
            <div class="content-column">
                <h1 class="main-heading">
                    Trusted Online Assignment Help Services in the UK 
                </h1>
                <div class="content-paragraph">
                    <p>From essays to dissertations, our expert assignment helpers provide high-quality, subject-specific academic assistance tailored to UK university standards.
                    </p>
                </div>

                <div class="content-list-item">
                    <ul class="content-list">
                        <li>100% Plagiarism-Free & Custom-Written</li>
                        <li>Guaranteed On-Time Delivery - No Missed Deadlines</li>
                         <li>Unlimited Free Revisions Until You're Satisfied</li>
                    </ul>
                    <ul class="content-list">
                        <li>24/7 Live Support - Anytime, Anywhere</li>
                        <li>Expert Referencing (APA, MLA, etc.)</li>
                        <li>Safe & Flexible Payment Options </li>
                    </ul>
                </div>

                <div class="Trusted-paragraph">
                    <p>Trusted by <b>5,000+&nbsp;students </b>- Rated 4.4/5 Across All Platforms
</p>
                </div>

                @include('components.review-section')
            </div>

            <!-- Form Column -->
            <div class="form-column">
                <div class="form-container">
                    @include('new-form')
                </div>
            </div>
        </div>
    </div>

    <style>
        .bg-hero {
            background: url(/images/background/home-bg.avif) no-repeat center center;
            background-size: cover;
            padding: 3rem 2rem;
            box-shadow: rgba(0, 0, 0, 0.06) 0px 2px 4px inset;
        }

        .container-section {
            max-width: 1200px;
            margin: auto;
            padding: 0 1rem;
        }

        .hero-content {
            display: flex;
            flex-direction: row;
            gap: 2rem;
            opacity: 0;
            transform: translateY(40px);
            animation: fadeSlideIn 0.8s ease-out 0.2s forwards;
        }

        .form-container {
            margin: auto;
            display: flex;
            justify-content: center;
        }

        .main-heading {
            background: linear-gradient(to bottom, #3F159A, #0E8FCE);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-size: 2.5rem;
            font-weight: 900;
            line-height: 1.3;
            margin-bottom: 1rem;
        }

        .content-paragraph p {
            font-size: 1.1rem;
            color: #000;
            font-weight: 600;
            margin-bottom: 1rem;
            text-align: justify;
        }

        .content-list-item {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .content-list {
            padding-left: 20px;
            margin: 0;
        }

        .content-list li {
            color: #333;
            list-style-type: square;
            font-size: 0.95rem;
            margin-bottom: 0.5rem;
        }

        .Trusted-paragraph {
            margin-top: 1rem;
            font-size: 1rem;
            font-weight: 500;
        }

        /* Lightweight compositor-friendly animation */
        @keyframes fadeSlideIn {
            0% {
                opacity: 0;
                transform: translateY(40px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            .hero-content {
                flex-direction: column;
            }
            .main-heading {
                font-size: 2rem;
            }
            .content-paragraph p {
                font-size: 1rem;
                text-align: left;
            }
        }

        @media (max-width: 600px) {
            .bg-hero {
                padding: 1.5rem 1rem;
            }
            .main-heading {
                font-size: 1.7rem;
            }
            .content-list-item {
                flex-direction: column;
            }
        }

        @media (max-width: 1154px) {
            .content-list-item {
                gap: 0;
            }
        }
    </style>
</section>
