<!-- About Us Section -->
<section class="page-section about-us-section">
  <h2 class="section-title">About <span>Us</span></h2>

  <div class="about-content-wrapper">
    <div class="about-video">
      <div class="youtube-facade" data-video-id="kfydpnoyWXE" onclick="loadYoutube(this)">
        <img
          src="https://img.youtube.com/vi/kfydpnoyWXE/hqdefault.jpg"
          alt="Introduction Video"
          loading="lazy"
          fetchpriority="high"
        />
        <div class="play-button"></div>
      </div>
    </div>

    <div class="about-text">
      <p>
       Founded in 2018,<a href="/"><b> Assignment in Need</b></a> was built on the belief that students deserve more than just assignment help; they deserve authentic academic support from experts who truly understand their academic journey. Our biggest strength lies in our team of 3,000+ highly qualified professionals, including PhD holders, researchers, and university-level educators from top institutions in the UK. With deep subject knowledge and practical academic insight, we match every student with the right expert, not just to complete a task, but to help them grasp the subject fully. From first-year undergraduates to master’s students, we provide the guidance, clarity, and academic confidence you need to succeed.
      </p>
      <p>🎓 100% AI-Free Assignments | Real Experts. Real Support. Real Results.</p>
      <p>
        <a href="/what-we-are"><button class="expert-btn">About Us</button></a>
      </p>
    </div>
  </div>
</section>

<!-- CSS -->
<style>
.about-us-section {
  background-color: #f7f7f7;
  border-radius: 1rem;
  padding: 40px 20px;
  margin: 2rem auto;
}

.about-content-wrapper {
  display: flex;
  flex-wrap: wrap;
  gap: 2rem;
  align-items: center;
  justify-content: center;
  max-width: 1200px;
  margin: auto;
}

.about-video {
  flex: 1 1 45%;
  min-width: 280px;
  aspect-ratio: 16 / 9;
  position: relative;
  width: 100%;
  max-width: 600px;
}

.youtube-facade {
  position: absolute;
  inset: 0;
  cursor: pointer;
  border-radius: 1rem;
  overflow: hidden;
}

.youtube-facade img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 1rem;
}

/* Shared Play Button style (same as other videos) */
.play-button {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 70px;
  height: 70px;
  background: rgba(0, 0, 0, 0.6);
  border-radius: 50%;
  border: 3px solid white;
  z-index: 2;
}
.play-button::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-40%, -50%);
  border-style: solid;
  border-width: 15px 0 15px 25px;
  border-color: transparent transparent transparent white;
}

.about-text {
  flex: 1 1 45%;
  min-width: 280px;
  color: #444;
  font-size: 1rem;
  line-height: 1.7;
  max-width: 600px;
}

.about-text p {
  margin-bottom: 1.2rem;
  text-align: justify;
}

/* Tablet and down */
@media (max-width: 1024px) {
  .about-content-wrapper {
    align-items: stretch;
    text-align: center;
  }

  .about-text {
    text-align: left;
  }
}

/* Phone-specific */
@media (max-width: 480px) {
  .about-text {
    font-size: 0.8rem;
    line-height: 1.6;
  }

  .expert-btn {
    font-size: 0.95rem;
    padding: 8px 16px;
  }
}
</style>

<!-- JS -->
<!-- <script>
  function loadYoutube(el) {
    const videoId = el.getAttribute('data-video-id');
    const iframe = document.createElement('iframe');
    iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;
    iframe.setAttribute('frameborder', '0');
    iframe.setAttribute('allowfullscreen', '');
    iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture');
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    el.innerHTML = '';
    el.appendChild(iframe);
  }
</script> -->
