<section class="page-section academic-services">
    <div class="container">
    <h2 class="section-title">Explore Our Range of Expert Assignment <span>Writing Services</span></h2>
    <p class="section-description">High-Quality, Original Academic Writing for All, from Students to Researchers, Across All Assignment Types.</p>
    
<div class="services-slider-wrapper">
  <div class="owl-carousel services-slider owl-theme m-auto">
    <div class="service-item">
      <a href="uk/essay-writing-help"><h3>Essay Help</h3></a>
      <p>Struggling to write a high-scoring essay? Our assignment writing experts UK guide you through every stage—from topic selection and outlining, to integrating credible sources and perfecting your conclusion. We ensure your essays meet university guidelines and achieve top marks.</p>
    </div>
    <div class="service-item">
      <a href="uk/reseach-paper-writing-help"><h3>Research Paper Help</h3></a>
      <p>Master the art of academic research with research paper guidance UK. We help you develop focused research questions, structure abstracts, analyse data, and present clear, well-referenced findings. Our support ensures your work reflects academic integrity and critical thinking.</p>
    </div>
    <div class="service-item">
      <a href="/uk/dissertation-writing-help-online"><h3>Dissertation Help</h3></a>
      <p>Conquer your dissertation with comprehensive support—from topic refinement and literature review writing to data analysis and discussion structuring. We ensure your dissertation meets UK university standards and postgraduate expectations.</p>
    </div>
    <div class="service-item">
      <a href="uk/thesis-assignment-writing-help"><h3>Thesis Help</h3></a>
      <p>Need help with your thesis? We guide you in selecting the right theoretical framework, developing clear arguments, and ensuring cohesion and originality in your work. Perfect for master’s and final-year students looking to make an impact.</p>
    </div>
    <div class="service-item">
      <a href="/uk/coursework-writing-help"><h3>Coursework Help</h3></a>
      <p>Stay on track with ongoing assessments. Our coursework assistance UK covers weekly assignments, lab reports, and reflective essays. We align your work with grading rubrics and help you develop independent learning skills to excel in your studies.</p>
    </div>
    <div class="service-item">
      <a href="/uk/case-study-writing-help"><h3>Case Study Help</h3></a>
      <p>Tackle complex case studies with confidence. We guide you in analysing real-world scenarios, applying theories, and structuring your findings into a logical, well-organised format.</p>
    </div>
    <div class="service-item">
      <a href="/uk/homework-help-service"><h3>Homework Help</h3></a>
      <p>Struggling to complete your homework on time? Our homework guidance UK provides step-by-step explanations, problem-solving strategies, and timely assistance across all subjects, ensuring you submit accurate, on-time work.</p>
    </div>
  </div>
   <!-- Custom Nav Buttons -->
                <div class="custom-nav">
                    <button class="custom-prev">Prev</button>
                    <button class="custom-next">Next</button>
                </div>
</div>


</div>
</section>

<style>
/* Wrapper */
.services-slider-wrapper {
  position: relative;
  margin: 0 auto;
  max-width: 100%;
  padding: 10px 0 20px;
}

/* Service Item */
.service-item {
  background: white;
  border-radius: 10px;
  border: 2px solid rgb(63, 21, 154);
  box-shadow: 0 4px 8px rgba(63, 21, 154, 0.2);
  padding: 20px;
  text-align: center;
  height: 350px;
  overflow-y: auto;
  transition: transform 0.3s, box-shadow 0.3s;
}

.service-item:hover {
  transform: translateY(-5px);
  box-shadow: 0 6px 12px rgba(94, 44, 237, 0.3);
}

/* Scrollbar (Firefox) */
.service-item {
  scrollbar-width: thin;
  scrollbar-color: #5e2ced #f0f0f0;
}

/* Scrollbar (WebKit) */
.service-item::-webkit-scrollbar {
  width: 8px;
}
.service-item::-webkit-scrollbar-track {
  background: #f0f0f0;
}
.service-item::-webkit-scrollbar-thumb {
  background-color: #5e2ced;
  border-radius: 10px;
  border: 1.5px solid #f0f0f0;
}
.service-item::-webkit-scrollbar-thumb:hover {
  background-color: #35189f;
}

/* Headings & Paragraphs */
.service-item h3 {
  font-weight: bold;
  font-size: 20px;
  color: #5e2ced;
  margin-bottom: 10px;
}
.service-item p {
  text-align: left;
  font-weight: 500;
  font-size: 1rem;
}

/* Custom Nav Buttons */
.custom-nav {
  text-align: center;
  margin-top: 20px;
}
.custom-nav button {
  background: linear-gradient(135deg, #5e2ced, #4821c3);
  color: #fff;
  border: none;
  padding: 10px 20px;
  margin: 0 10px;
  border-radius: 30px;
  cursor: pointer;
  font-weight: bold;
  transition: background 0.3s, transform 0.3s;
}
.custom-nav button:hover {
  background: linear-gradient(135deg, #4821c3, #35189f);
  transform: translateY(-2px);
}

/* Owl Carousel Nav Buttons – hide built-in if not used */
.owl-nav {
  display: none !important;
}

/* Responsive */
@media (max-width: 1024px) {
  .service-item {
    height: 330px;
  }
}
@media (max-width: 768px) {
  .service-item {
    height: 300px;
  }
  .service-item h3 {
    font-size: 18px;
  }
}
@media (max-width: 480px) {
  .service-item {
    height: auto;
  }
  .service-item h3 {
    font-size: 16px;
  }
  .service-item p {
    font-size: 12px;
  }
}
</style>


<script>
  $(document).ready(function () {
    // Initialize Owl Carousel
    var serviceSlider = $(".services-slider").owlCarousel({
      loop: false,
      margin: 20,
      nav: false, // Disable default owl nav since using custom
      autoplay: true,
      autoplayTimeout: 4000,
      autoplayHoverPause: true,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 2
        },
        1024: {
          items: 3
        }
      }
    });

    // Custom navigation
    $('.custom-next').click(function () {
      serviceSlider.trigger('next.owl.carousel');
    });

    $('.custom-prev').click(function () {
      serviceSlider.trigger('prev.owl.carousel');
    });
  });
</script>
