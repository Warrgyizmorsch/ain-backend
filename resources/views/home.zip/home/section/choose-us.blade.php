<section class="page-section why-choose-us">
    <div class="container">
        <h2 class="section-title">Our Guarantees That Make <span>Assignment Help</span> Stress-Free and Reliable</h2>
        <p class="section-description">Unlock the key benefits of our assignment help with the security of our <a
                href="GuaranteedPolicy ">guarantees</a> designed for your academic success.</p>
        <div class="features-grid">
            <!-- Feature Box 1 -->
            <div class="feature-box" data-aos="fade-up">
                <div class="feature-icon">
                    <i class="fas fa-check"></i>
                </div>
                <div class="heading-text">
                    <h3>Quality of Work</h3>
                </div>
                <div class="paragraph-text">
                   <p>We don't just deliver assignment help, we ensure high-quality academic guidance that reflects deep research, critical
                thinking, and proper structure. Every solution is custom-crafted, plagiarism-free, and formatted according to your
                university's guidelines.</p>
                </div>
            </div>
            <!-- Feature Box 2 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="100">
                <div class="feature-icon">
                    <i class="fa fa-truck"></i>
                </div>
                <div class="heading-text">
                    <a href="/contact-us">
                    <h3>Unlimited Revisions</h3>
                    </a>
                </div>
                <div class="paragraph-text">
                  
                  <p>Your satisfaction matters. If something doesn’t align with your expectations, we revise it, free of cost. Whether it’s
                restructuring, refining the tone, or improving clarity, our unlimited revisions policy guarantees that the final
                document matches your assignment brief and your professor’s feedback.</p>
               
                </div>
            </div>

            <!-- Feature Box 3 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="200">
                <div class="feature-icon">
                    <i class="fa fa-refresh"></i>
                </div>
                <div class="heading-text">
                    <h3>Experienced Writers</h3>
                </div>
                <div class="paragraph-text">
                     <p>We handpick only the best, Master’s and PhD-qualified assignment writers who are native English speakers and subject
                    specialists. With years of academic experience, our writers understand UK university standards, grading rubrics, and the
                    nuances professors look for in high-scoring papers.</p>
                </div>
            </div>

            <!-- Feature Box 4 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="300">
                <div class="feature-icon">
                    <i class="fa fa-user	"></i>
                </div>
                <div class="heading-text">
                      <a href="/writers">
                    <h3>Affordable Prices</h3>
                    </a>
                </div>
                <div class="paragraph-text">
                    <p>We understand that most students work with limited budgets. That’s why we offer competitive pricing and zero hidden
                    charges. Whether you're placing your first order or returning for multiple assignments, we ensure maximum value for
                    every pound you spend, without cutting corners on quality.</p>
                </div>
            </div>

            <!-- Feature Box 5 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="400">
                <div class="feature-icon">
                    <i class="fa fa-money"></i>
                </div>
                <div class="heading-text">
                        <h3>24/7 Customer Support</h3>
                </div>
                <div class="paragraph-text">
                    <p>Have a question at 3 AM? Need a status update before submission? We’re here. Our friendly support team is available 24/7
                    via chat, WhatsApp, email, and phone to answer queries, resolve issues, and keep your worries away. We don’t just
                    respond, we assist like an academic guide by your side.</p>

                </div>
            </div>

            <!-- Feature Box 6 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="500">
                <div class="feature-icon">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div class="heading-text">
                   
                       <h3>In-Depth Research & Accurate Referencing</h3>
                    
                </div>
                <div class="paragraph-text">
                    <p>Our experts go beyond surface-level content. Every assignment is backed by credible sources, academic journals, and
                    university-recommended material. Whether it’s APA, MLA, Harvard, Chicago, or any custom style, we provide flawless
                    referencing and citation support for students.</p>

                </div>
            </div>
            <!-- Feature Box 7 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="500">
                <div class="feature-icon">
                    <i class="fas fa-edit"></i>
                </div>
                <div class="heading-text">
                    <a href="/pricing">
                        <h3>Skill Enhancement & Proofreading Assistance</h3>
                    </a>
                </div>
                <div class="paragraph-text">
                    <p>We assist students with academic growth and clarity to improve their work through constructive feedback, grammar refinement, content flow enhancement, and strategic suggestions. Our expert writers also support you with proofreading and writing skill development to ensure every submission is polished and impactful.
                    </p>

                </div>
            </div>
            <!-- Feature Box 8 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="500">
                <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="heading-text">
                    <a href="/PrivacyPolicy">
                      <h3>Full Privacy & Data Confidentiality</h3>
                    </a>
                </div>
                <div class="paragraph-text">
                    <p>Your privacy is our top priority. We guarantee 100% confidentiality; your personal info, payment details, and academic
                    requests are safe with us. We use secure, encrypted systems and never share your data with third parties. You can seek
                    help confidently, without judgment or risk.</p>

                </div>

            </div>
            
              
        </div>
    </div>      
</section>
<!-- ........mobile view  -->
<div class="mobile-slider">
    <div class="slider-track">
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fas fa-check"></i>
            </div>
            <div class="heading-text">
                <h3>Quality of Work</h3>
            </div>
            <div class="paragraph-text">
                <p>We don’t just deliver assignments, we ensure high-quality academic guidance that reflects deep research, critical
                thinking, and proper structure. Every solution is custom-crafted, plagiarism-free, and formatted according to your
                university's guidelines.</p>
            </div>
        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                    <i class="fa fa-truck"></i>
            </div>
            <div class="heading-text">
                <a href="/contact-us">
                    <h3>Unlimited Revisions</h3>
                </a>
            </div>
            <div class="paragraph-text">
            
                <p>Your satisfaction matters. If something doesn’t align with your expectations, we revise it, free of cost. Whether it’s
                restructuring, refining the tone, or improving clarity, our unlimited revisions policy guarantees that the final
                document matches your assignment brief and your professor’s feedback.</p>
            
            </div>
        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                    <i class="fa fa-refresh"></i>
            </div>
            <div class="heading-text">
                <h3>Experienced Writers</h3>
            </div>
            <div class="paragraph-text">
                <p>We handpick only the best, Master’s and PhD-qualified assignment writers who are native English speakers and subject
                specialists. With years of academic experience, our writers understand UK university standards, grading rubrics, and the
                nuances professors look for in high-scoring papers.</p>
            </div>
        </div>
        <div class="feature-box card-mobile-view">
             <div class="feature-icon">
                <i class="fa fa-user	"></i>
            </div>
            <div class="heading-text">
                <a href="/writers">
                    <h3>Affordable Prices</h3>
                </a>
            </div>
            <div class="paragraph-text">
                <p>We understand that most students work with limited budgets. That’s why we offer competitive pricing and zero hidden
                charges. Whether you're placing your first order or returning for multiple assignments, we ensure maximum value for
                every pound you spend, without cutting corners on quality.</p>
            </div>
        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fa fa-money"></i>
            </div>
            <div class="heading-text">
                <h3>24/7 Customer Support</h3>
            </div>
            <div class="paragraph-text">
                <p>Have a question at 3 AM? Need a status update before submission? We’re here. Our friendly support team is available 24/7
                via chat, WhatsApp, email, and phone to answer queries, resolve issues, and keep your worries away. We don’t just
                respond, we assist like an academic guide by your side.</p>
            
            </div>
        </div>
        <div class="feature-box card-mobile-view">
           <div class="feature-icon">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="heading-text">
            
                <h3>In-Depth Research & Accurate Referencing</h3>
            
            </div>
            <div class="paragraph-text">
                <p>Our experts go beyond surface-level content. Every assignment is backed by credible sources, academic journals, and
                university-recommended material. Whether it’s APA, MLA, Harvard, Chicago, or any custom style, we provide flawless
                referencing and citation support for students.</p>
            
            </div>
        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fas fa-edit"></i>
            </div>
            <div class="heading-text">
                <a href="/pricing">
                    <h3>Skill Enhancement & Proofreading Assistance</h3>
                </a>
            </div>
            <div class="paragraph-text">
                <p>We’re not just here to complete tasks; we’re here to help you grow. Our service includes constructive feedback, grammar
                checks, content flow improvement, and strategic suggestions. We offer proofreading and writing skills assistance by
                professional writers.</p>
            
            </div>
        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fas fa-shield-alt"></i>
            </div>
            <div class="heading-text">
                <a href="/PrivacyPolicy">
                    <h3>Full Privacy & Data Confidentiality</h3>
                </a>
            </div>
            <div class="paragraph-text">
                <p>Your privacy is our top priority. We guarantee 100% confidentiality; your personal info, payment details, and academic
                requests are safe with us. We use secure, encrypted systems and never share your data with third parties. You can seek
                help confidently, without judgment or risk.</p>
            
            </div>
        </div>
    </div>

    <!-- Navigation buttons -->
    <button class="slider-btn prev">&#10094;</button>
    <button class="slider-btn next">&#10095;</button>
</div>
<!-- ................................ -->
 <div class="upload-btn">
    <a href="/upload-your-assignment">
        <button class="place-order-btn">Upload your Assignment</button>
    </a>
</div>
<style>
    .upload-btn 
    {   
         /* margin: auto; */
    /* align-items: center; */
    /* justify-content: center; */
    text-align: center;
    margin: -37px 0px 20px 0px;
}
    /* ......................... */

    /* Hide mobile slider by default */

    .mobile-slider {
        display: none;
    }

    /* Mobile-only styles */
    @media (max-width: 767px) {
        .features-grid {
            display: none !important;
            /* Hide desktop grid on mobile */
        }

        .mobile-slider {
            display: block;
            position: relative;
            width: 100%;
            height: 320px;
            padding: 8px;
            overflow: hidden;
            /* Changed to hidden to prevent cards from overflowing */
        }

        .slider-track {
            margin-top: 35px;
            display: flex;
            transition: transform 0.3s ease-in-out;
            width: 100%;
            /* Ensure track takes full width */
        }

        .mobile-slider .feature-box {
            flex: 0 0 calc(100% - 20px);
            /* Account for margins */
            box-sizing: border-box;
            padding: 20px;
            background: linear-gradient(135deg, #3F159A, #0E8FCE);
            margin: 0 10px;
            /* 10px margin on each side */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        }

        .slider-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background-color: rgba(0, 0, 0, 0.6);
            color: white;
            border: none;
            padding: 12px 16px;
            font-size: 18px;
            border-radius: 50%;
            cursor: pointer;
            z-index: 10;
        }

        .slider-btn.prev {
            left: 10px;
        }

        .slider-btn.next {
            right: 10px;
            /* Adjusted to positive value to stay within bounds */
        }

        .feature-icon {
            max-width: 80px;
            height: 75px;
            font-size: 50px;
        }
    }

    /* .............................. */
    .feature-box h3 {
        font-size: 20px;
        margin-bottom: 10px;
        font-weight: bold;
        color: white;
    }

    .feature-box p {
        font-size: 14px;
    }

    .heading-text {
        margin-top: -50px;
    }

    .paragraph-text {
        margin-top: 5px;
        /* text-align: justify; */

    }

    /* General Section Styling */

    /* Features Grid */
    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 30px;
        max-width: 1150px;
        margin: 1.5rem auto;
    }

    /* Feature Box */
    .feature-box {
        background: linear-gradient(135deg, #3F159A, #0E8FCE);
        color: white;
        padding: 15px;
        border-radius: 10px;
        text-align: center;
        transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        animation: fadeInUp 1s ease-in-out;
        margin-top: 20px;
    }

    .feature-box:hover {
        transform: translateY(-10px);
        box-shadow: 0px 15px 25px rgba(0, 0, 0, 0.2);
    }

    /* Feature Icon */
    .feature-icon {
        font-size: 30px;
        margin-bottom: 10px;
        background: white;
        color: rgb(30 0 90);
        display: inline-block;
        padding: 15px;
        border-radius: 100%;
        position: relative;
        top: -50px;
        width: 80px;
        height: 80px;
        background: #fffafa;
        border: 11px double;
    }

    /* Animations */
    

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @media (max-width: 1024px) {
        .features-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 768px) {
        .features-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .feature-box {
            padding: 20px;
        }

        .feature-icon {
            font-size: 25px;
            height: 80px;
            width: 80px;
        }

        .feature-box h3 {
            font-size: 18px;
        }

        .feature-box p {
            font-size: 14px;
        }
    }

    @media (max-width: 480px) {

        .place-order-btn {
            margin-top: 50px !important;
        }

            .feature-box {
                padding: 15px;
            }

            .feature-icon {
                font-size: 30px !important;

            }
       

        .feature-box h3 {
            font-size: 16px;
        }

        .feature-box p {
            font-size: 12px;
        }
    }
</style>

<!-- Include AOS (Animate on Scroll) for additional smooth animations -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true
    });
</script>


<!-- mobile view card javascript -->
<script>
    const sliderTrack = document.querySelector('.slider-track');
    const slides = document.querySelectorAll('.mobile-slider .feature-box');
    const nextBtn = document.querySelector('.slider-btn.next');
    const prevBtn = document.querySelector('.slider-btn.prev');

    let currentIndex = 0;

    function updateSlider() {
        if (slides.length === 0) return; // Prevent errors if no slides
        const slideWidth = slides[0].offsetWidth + 20; // Include margin (10px left + 10px right)
        sliderTrack.style.transform = `translateX(-${slideWidth * currentIndex}px)`;
    }

    // Initialize slider
    updateSlider();

    // Navigation
    nextBtn.addEventListener('click', () => {
        if (currentIndex < slides.length - 1) {
            currentIndex++;
            updateSlider();
        }
    });

    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updateSlider();
        }
    });

    // Recalculate on resize
    window.addEventListener('resize', updateSlider);
</script>
<!-- ...................................................... -->

</section>