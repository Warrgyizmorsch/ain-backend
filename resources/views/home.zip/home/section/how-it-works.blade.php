<section class="how-it-works-lazy">
  <div class="auto-container">
    <h2 class="section-title">
      How Does Our Expert <span>Online Assignment</span> Help Works in UK?
    </h2>

    <div class="content-wrapper">
      <!-- Left Side: YouTube Lazy Video -->
      <div class="video-column">
        <div class="youtube-facade" data-video-id="_TDbpVaGHVU" onclick="loadYoutube(this)">
          <img
            src="https://img.youtube.com/vi/_TDbpVaGHVU/hqdefault.jpg"
            alt="How It Works Video"
            loading="lazy"
          />
          <div class="play-button"></div>
        </div>
      </div>

      <!-- Right Side: All Steps -->
      <div class="steps-column">
        <div class="step">
          <h3 style="margin-bottom: 0;"><span class="step-number" style="margin: 0;">1. </span> Submit Your Requirements</h3>
          <p>Fill out our user-friendly order form with all the details of your assignment, including the topic, deadline, academic level, and any specific instructions or rubrics. This ensures we understand your needs perfectly.</p>
        </div>

        <div class="step">
          <h3 style="margin: 0;"><span class="step-number" style="margin: 0;">2. </span> Get Matched with an Expert</h3>
          <p>Once your order is placed, our system intelligently matches you with a Master's or PhD-qualified expert in your specific subject area. You're connected with someone who truly understands your task.</p>
        </div>

        <div class="step">
          <h3 style="margin: 0;"><span class="step-number" style="margin: 0;">3. </span> Collaborate & Monitor Progress</h3>
          <p>Communicate directly with your assigned expert through our secure portal. You can provide additional materials, ask
          questions, and track the progress of your assignment every step of the way, ensuring full transparency.</p>
        </div>

        <div class="step">
          <h3 style="margin: 0;"><span class="step-number" style="margin: 0;">4. </span> Review & Request Revisions</h3>
          <p>Receive your completed assignment before the final deadline. Review the work thoroughly and, if needed, request any
          revisions. We offer unlimited revisions to ensure you are 100% satisfied with the quality and precision.</p>
        </div>

        <a href="https://www.assignnmentinneed.com/upload-your-assignment">
          <button class="place-order-btn">Get Our Assistance</button>
        </a>
      </div>
    </div>
  </div>
</section>

<style>
.how-it-works-lazy {
  padding: 2rem 1.5rem;
  background: #fff;
  text-align: center;
}

.content-wrapper {
  display: flex;
  gap: 20px;
  align-items: center;
  justify-content: space-around;
  flex-wrap: wrap;
}

/* Lazy Video Facade */
.video-column {
  flex: 1;
  min-width: 300px;
  max-width: 600px;
  text-align: center;
  position: relative;
}

.youtube-facade {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 9;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
}

.youtube-facade img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.play-button {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 64px;
  height: 64px;
  background: url('/assets/play-button.svg') no-repeat center center;
  background-size: contain;
  transform: translate(-50%, -50%);
  opacity: 0.9;
}

/* Steps section */
.steps-column {
  flex: 1;
  max-width: 600px;
  text-align: left;
}

.step {
  margin-bottom: 30px;
}

.step-number {
  font-size: 28px;
  color: #5e2ced;
  font-weight: bold;
  display: inline-block;
  margin-bottom: 8px;
}

.step h3 {
  font-size: 22px;
  margin: 8px 0;
  color: #333;
}

.step p {
  font-size: 16px;
  color: #555;
  line-height: 1.6;
}

/* Responsive */
@media (max-width: 768px) {
  .content-wrapper {
    flex-direction: column;
    align-items: stretch;
    gap: 20px;
  }
  .step-number { font-size: 24px; }
  .step h3 { font-size: 20px; }
  .step p { font-size: 14px; }
}

@media (max-width: 480px) {
  .how-it-works-lazy {
    padding: 0 !important;
  }
  .how-it-works-lazy .auto-container {
    padding: 5px !important;
  }

  .content-wrapper {
    flex-direction: column;
    align-items: stretch;
    gap: 20px;
  }
  .step-number { font-size: 20px; }
  .step h3 { font-size: 18px; }
  .step p { font-size: 13px; }
  /*.place-order-btn { width: 200px; font-size: 13px; padding: 8px; }*/
  .place-order-btn { 
    width: 200px; 
    font-size: 13px; 
    padding: 8px;
    transition: transform 0.3s ease, box-shadow 0.3s ease; 
    will-change: transform;
  }

  .place-order-btn:hover {
    transform: translateY(-5px) scale(1.05);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
  }
}

</style>

<!-- <script>
function loadYoutube(el) {
  const videoId = el.getAttribute('data-video-id');
  const iframe = document.createElement('iframe');
  iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;
  iframe.frameborder = "0";
  iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture";
  iframe.allowFullscreen = true;
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  el.innerHTML = '';
  el.appendChild(iframe);
}
</script> -->
