<section class="page-section reviews-section">
    <div class="container">
        <h2 class="section-title">Our Students Testimonial </h2>
        <p class="reviews-subtitle">
            Over <a href="/review">4.4★ average rating from 5,000+ reviews</a> across trusted platforms! Students trust
            Assignment In Need for reliable, fast, and high-quality assignment help.
        </p>

        <!-- Tabs -->
        <div class="review-tabs">
            <button class="tab-btn active" data-tab="assignnmentinneed">
                <img src="/images/icons/assignment_logo_2.avif" alt="assignnmentinneed">
            </button>
            <button class="tab-btn" data-tab="trustpilot">
                <img src="/images/icons/Trustpilot_Logo.avif" alt="Trustpilot">
            </button>
            <button class="tab-btn" data-tab="sitejabber">
                <img src="/images/icons/google-logo.avif" alt="Sitejabber">
            </button>
            <button class="tab-btn" data-tab="youtube">
                <img src="/images/icons/youtube_logo.avif" alt="YouTube">
            </button>
        </div>

        <!-- assignnment in need Tab -->
        <div class="tab-content active" id="assignnmentinneed">
            <div class="slider-containers">
                <div class="cards-wrapper" id="cardWrappers">
                    <!-- 8 Cards -->
                    @foreach ($data['review'] as $review)
                        <div class="slider-card">
                            <p class="subheading-p">{{ $review->name }}</p>
                            <p class="location-text">{{ $review->location }}</p>
                            <div class="stars">
                                @for ($i = 1; $i <= 5; $i++)
                                    @if ($i <= $review->customer_rating)
                                        <i class="fas fa-star" style="color: gold;"></i>
                                    @else
                                        <i class="far fa-star" style="color: gold;"></i>
                                    @endif
                                @endfor
                            </div>
                            <p class="review-text">{{ $review->description }}</p>
                            <div class="review-details">
                                <p class="review-date">
                                    {{ \Carbon\Carbon::parse($review->submission_date)->format('F j, Y') }}</p>
                                <p class="review-deatline">{{ $review->deadline }}</p>
                                <p class="review-services-type">{{ $review->services_type }}</p>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="controls">
                <button onclick="moveSlid(-1)">Prev</button>
                <button onclick="moveSlid(1)">Next</button>
            </div>

        </div>

        <!-- Trustpilot Tab -->
        <div class="tab-content" id="trustpilot">
            <div class="slider-box">
                <div class="slider-track" id="trustSliderTrack">
                    @for ($i = 1; $i <= 5; $i++)
                        <div class="review-card">
                            <img src="images/trust/review-{{ $i }}.jpg" alt="Review {{ $i }}">
                        </div>
                    @endfor
                </div>
                <button class="slider-btns prev-btn" onclick="changeTrustSlide(-1)">&#10094;</button>

                <button class="slider-btns next-btn" onclick="changeTrustSlide(1)">&#10095;</button>
            </div>
        </div>

        <!-- Sitejabber (Google Slider Cards) -->
        <div class="tab-content" id="sitejabber">
            <div class="custom-slider-container">
                <div class="custom-slider-track-wrapper">
                    <div class="custom-slider-tracks" id="googleSliderTrack">
                        <div class="custom-cards">
                            <div class="first-letter-div">
                                <p class="subheading-p">Arshpreet Kaur</p>
                            </div>
                            <div class="star-google">

                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i
                                    class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                            <div class="review">
                                <p class="review-date">19 November 2024</p>
                                <p class="review-para">You guys are the best. Thank you for your efforts. I really
                                    like your services and
                                    the way every staff member behaves 🥰.</p>
                            </div>
                        </div>
                        <div class="custom-cards">
                            <div class="first-letter-div">
                                <p class="subheading-p">Wajahat Afreen</p>
                            </div>
                            <div class="star-google">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i
                                    class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                            <div class="review">
                                <p class="review-date">27 March 2024</p>
                                <p class="review-para">First of all Thank you great team . You have very professional
                                    team because of you
                                    lot of us achieve our dream . thanks alot for your help and support.</p>
                            </div>
                        </div>

                        <div class="custom-cards">
                            <div class="first-letter-div">
                                <p class="subheading-p">Satwinder Saini</p>
                            </div>
                            <div class="star-google">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i
                                    class="fas fa-star"></i>
                            </div>
                            <div class="review">
                                <p class="review-date">12 January 2024</p>
                                <p class="review-para">First of all Thank you great team . You have very professional
                                    team because of you
                                    lot of us achieve our dream . thanks alot for your help and support.</p>
                            </div>
                        </div>

                        <div class="custom-cards">
                            <div class="first-letter-div">
                                <p class="subheading-p">Albena Kaneva</p>
                            </div>
                            <div class="star-google">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i
                                    class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                            <div class="review">
                                <p class="review-date">22 July 2024</p>
                                <p class="review-para">So quick and reliable service! Almost 24 hours provides support! The best in prices and quality as well! Thank you guys!
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="google-nxt-pre-btn">
                    <button class="custom-slider-btn custom-prev-btn" onclick="moveGoogleSlider(-1)">&#10094;</button>
                    <button class="custom-slider-btn custom-next-btn" onclick="moveGoogleSlider(1)">&#10095;</button>
                </div>
            </div>


        </div>

        <!-- YouTube Tab -->
        <div class="tab-content" id="youtube">
            <div class="video-slider-container">
                <div class="video-slider-track" id="videoSliderTrack">
                    <div class="video-slide">
                        <div class="youtube-facade" data-video-id="Mndzuh8f_Zo" onclick="loadYoutube(this)">
                            <img src="https://img.youtube.com/vi/Mndzuh8f_Zo/hqdefault.jpg" alt="Janissa Review"
                                loading="lazy" />
                            <div class="play-button"></div>
                        </div>

                        <p class="reviewer-name">Janissa</p>
                        <p class="reviewer-comment">
                            My name is Janissa. I just want to say that I'm really in love with the sign of union. This
                            website and
                            this company have me for almost two years. I cannot complain. The staff is so friendly. The
                            people that
                            arrive, they're amazing. The resources, the Harvard-Fed, the structure of my assignment, and
                            everything.
                            It's just me. I've had proper time to do my assignment. They do amazing presentation, they
                            do amazing
                            report. I don't know what to for. I don't know what to say. That was not this website, but
                            really not
                            the customer. I just had really good documentation, and my feedback has probably been really
                            good. I
                            really would say that you are the two of you time to walk home. I just want to say to you
                            that I love
                            you. When I got around here, it's really great. When we were together, when I sat down.
                            Really, really,
                            really. Thank you for all the things that you did.
                        </p>

                        <div class="reviewer-meta">
                            <p>15 pages | 4 days | Bristol, UK</p>
                        </div>

                    </div>
                    <div class="video-slide">

                        <div class="youtube-facade" data-video-id="deg5LjJ3Exc" onclick="loadYoutube(this)">
                            <img src="https://img.youtube.com/vi/deg5LjJ3Exc/hqdefault.jpg" alt="Petrana Review"
                                loading="lazy" />
                            <div class="play-button"></div>
                        </div>

                        <p class="reviewer-name">Petrana</p>
                        <p class="reviewer-comment">
                            Hi, I'm Petrana. I want to say a huge thank you to Assignment In Need.
                            You helped me immensely with your high-quality service, ensuring I passed all my assignments
                            on time
                            with great results.
                            I highly recommend you to everyone. Thank you so much.
                        </p>

                        <div class="reviewer-meta">
                            <p>8 pages | 6 days | Manchester, UK</p>
                        </div>

                    </div>

                    <div class="video-slide">

                        <div class="youtube-video">
                            <div class="youtube-facade" data-video-id="UxneGvVjiZQ" onclick="loadYoutube(this)">
                                <img src="https://img.youtube.com/vi/UxneGvVjiZQ/hqdefault.jpg"
                                    alt="Jules George Review" loading="lazy" />
                                <div class="play-button"></div>
                            </div>
                        </div>

                        <p class="reviewer-name">Jules George</p>
                        <p class="reviewer-comment">
                            Hey everyone, I'm Jules George, studying in South Wales.
                            Assignment In Need helped me a lot during critical times.
                            If you ever need help, don't hesitate — contact them!
                            They will guide you through everything you need.
                        </p>

                        <div class="reviewer-meta">
                            <strong>— Jules George</strong>
                            <p>12 pages | 8 days | Birmingham, UK</p>
                        </div>

                    </div>

                    <div class="video-slide">

                        <div class="youtube-video">
                            <div class="youtube-facade" data-video-id="4_llz5IpEdE" onclick="loadYoutube(this)">
                                <img src="https://img.youtube.com/vi/4_llz5IpEdE/hqdefault.jpg" alt="Dani Review"
                                    loading="lazy" />
                                <div class="play-button"></div>
                            </div>
                        </div>

                        <p class="reviewer-name">Dani</p>
                        <p class="reviewer-comment">
                            Good evening, my name is Dani. For the past three years, Assignment In Need has helped me
                            immensely.
                            Their service quality is exceptional, and the customer support team is always supportive and
                            professional.
                            Without them, managing all my assignments on time would have been impossible.
                            Thank you so much for everything!
                        </p>
                        <div class="reviewer-meta">
                            <strong>— Dani</strong>
                            <p>10 pages | 7 days | London, UK</p>
                        </div>

                    </div>
                </div>

                <div class="slider-buttons">
                    <button id="prevBtn" onclick="moveSlide(-1)">&#10094; Prev</button>
                    <button id="nextBtn" onclick="moveSlide(1)">Next &#10095;</button>
                </div>
            </div>

        </div>
    </div>
</section>


<style>
    .slider-containers {
        max-width: 1200px;
        margin: auto;
        overflow: hidden;
        position: relative;
    }

    .cards-wrapper {
        height: auto;
        display: flex;
        transition: transform 0.5s ease;
        gap: 20px;
    }

    .slider-card {
        /* background: #fff; */
        background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
        /* light gradient */
        border: 2px solid #7744e0;
        border-radius: 12px;
        padding: 20px;
        flex: 0 0 100%;
        max-width: 100%;
        width: 100%;
        height: auto;
        box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;
    }

    .slider-card p {
        text-align: left;
        /* border-bottom:2px solid rgb(30, 25, 25); */
        color: #5b21b6;
        font-size: 25px;
        margin-bottom: 12px;
    }

    .slider-card p {
        font-size: 16px;
        line-height: 1.5;
        text-align: justify;
        color: #333;

    }

    .stars {
        text-align: left;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
    }

    .review-text {
        height: 150px;
        overflow-y: scroll;
        /* scrollbar-width: none; */
        -ms-overflow-style: none;
        padding: 10px;

    }

    .review-text::-webkit-scrollbar {
        width: 4px;
    }

    .review-text::-webkit-scrollbar-thumb {
        background-color: #9995a7;
        /* blue */
        border-radius: 4px;
    }

    /* Scrollbar Track (background) */
    .review-text::-webkit-scrollbar-track {
        background-color: #f1f1f1;
    }

    .location-text {
        width: 100px;
        padding: 5px;
        border-radius: 10px;
        text-align: center;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #3b1e9e;
        color: #fff !important;
    }


    .review-details {
        display: flex;
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        background: rgba(255, 255, 255, 0.1);
        border-radius: 16px;
        padding: 10px;
        flex-wrap: wrap;
        gap: 10px;
        justify-content: flex-start;
        align-items: center;
        font-size: 14px;
        color: #333;
        margin: 10px 0;
    }

    .review-details p {
        margin: 0;
        padding: 8px 12px;
        background-color: #f1f1f1;
        border-radius: 8px;
        flex: 1 1 auto;
        text-align: center;
        min-width: 100px;
        color:#3b1e9d;

    }

    .controls {
        text-align: center;
        margin-top: 20px;
    }

    .controls button {
        padding: 10px 20px;
        background: #5b21b6;
        color: white;
        border: none;
        border-radius: 25px;
        margin: 0 10px;
        font-weight: bold;
        cursor: pointer;
        transition: background 0.3s;
    }

    .controls button:hover {
        background-color: #3f168f;
    }

    /* Responsive card width */
    @media (min-width: 768px) {
        .slider-card {
            flex: 0 0 calc((100% - 20px) / 2);
            max-width: calc((100% - 20px) / 2);
        }
    }

    @media (min-width: 1024px) {
        .slider-card {
            flex: 0 0 calc((100% - 40px) / 3);
            max-width: calc((100% - 40px) / 3);
        }
    }
</style>


<style>
    .custom-slider-viewport {
        overflow: hidden;
        width: 100%;
    }

    .custom-slider-tracks {
        display: flex;
        gap: 2px;
        transition: transform 0.4s ease;
    }


    .custom-cards {
        flex: 0 0 100%;
        padding: 20px;
        margin-right: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px #ddd;
        background: linear-gradient(to right, #3d1c9d, #5046a6, #1382c8);
        color: #fff;
    }

    @media (min-width: 768px) {
        .custom-cards {
            flex: 0 0 calc(50% - 20px);
        }
    }

    @media (min-width: 1024px) {
        .custom-cards {
            flex: 0 0 calc(33.333% - 20px);
        }
    }

    .first-letter-div {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1rem;
        justify-content: center;
    }

    .first-letter {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 3.5vw;
        min-width: 40px;
        height: auto;
        min-height: 40px;
        padding: 2px;
        font-size: clamp(1.5rem, 2vw, 2.5rem);
        font-weight: bold;
        color: #fff;
        border-radius: 50%;
        background: linear-gradient(to right, #3d1c9d, #1382c8);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }

    .subheading-p {
        font-size: clamp(1rem, 2vw, 1.25rem) !important;

        font-weight:bold;
        color: #fff;
        font-weight: 600;
        margin: 0;
    }

    .star-google {
        width: 100%;
        font-size: 14px;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 10px;
        color: #f1c40f;
    }

    .review {
        color: #fff;
    }

    .review-date {
        font-weight: bold;
        margin-bottom: 5px;
    }

    .google-nxt-pre-btn {
        text-align: center;
        margin-top: 20px;
    }

    .custom-slider-btn {
        padding: 10px 15px;
        background: #5b21b6;
        color: white;
        border: none;
        border-radius: 50px;
        margin: 0 5px;
        font-weight: bold;
        cursor: pointer;
    }

    .review-tabs {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 7px;
        margin-bottom: 30px;
        flex-wrap: nowrap;
        overflow-x: scroll;
        width: 100%;
        padding-bottom: 10px;
    }

    .review-tabs::-webkit-scrollbar {
        display: none;
    }

    .tab-btn {
        position: relative;
        overflow: hidden;
        border: 1px solid transparent;
        border-radius: 10px;
        padding: 10px;
        background: transparent;
        cursor: pointer;
        flex: 0 0 auto;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .tab-btn::before {
        content: "";
        position: absolute;
        inset: 0;
        background-color: #fff;
        opacity: 0;
        transition: opacity 0.3s ease;
        z-index: 0;
        border-radius: 10px;
    }

    .tab-btn.active {
        border-color: #5e2ced;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .tab-btn.active::before {
        opacity: 1;
    }

    .tab-btn img {
        width: 120px;
        position: relative;
        z-index: 1;
    }

    .tab-btn:hover {
        transform: scale(1.05);
    }

    .review-tabs button {
        background: none;
        border: none;
        margin: 0 10px;
        cursor: pointer;

    }

    .review-tabs button img {}

    .tab-content {
        display: none;
    }

    .tab-content.active {
        display: block;
    }

    .slider-containers,
    .custom-slider-container {
        max-width: 1200px;
        margin: auto;
        overflow: hidden;
        position: relative;
    }

    .cards-wrapper,
    .custom-slider-track {
        display: flex;
        gap: 20.2px;
        transition: transform 0.4s ease;
    }

    .slider-card,
    .custom-card {
        flex: 0 0 100%;
        background: #f9f9f9;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px #ddd;
    }

    @media (max-width: 600px) {
        .tab-btn img {
            width: 80px;
        }
    }

    @media (max-width: 600px) {
        .review-tabs {
            justify-content: space-between;
        }

        .tab-btn {
            width: 48%;
            margin-bottom: 10px;
        }

        .tab-btn img {
            width: 100%;
        }
    }



    @media (min-width: 768px) {

        /* .review-card img {
        width: 100%;
        height: auto;
        max-height: 400px;
        border-radius: 10px;
        border:7px solid #00ac65;
        object-fit: cover;
     } */
        .slider-card,
        .custom-card {
            flex: 0 0 50%;
        }
    }

    @media (min-width: 1024px) {

        .slider-card,
        .custom-card {
            flex: 0 0 33.33%;
        }
    }

    .controls {
        text-align: center;
        margin-top: 15px;
    }

    .controls button,
    .custom-slider-btn {
        padding: 10px 15px;
        background: #5b21b6;
        color: white;
        border: none;
        border-radius: 50px;
        margin: 0 5px;
        font-weight: bold;
        cursor: pointer;
    }

    .slider-box {
        position: relative;
        max-width: 800px;
        margin: auto;
        overflow: hidden;
    }

    .slider-track {
        display: flex;
        transition: transform 0.4s ease-in-out;
    }

    .review-card {
        min-width: 100%;
    }

    .review-card img {
        width: 100%;
        height: auto;
        /* ✅ Adjusts height automatically */
        max-height: 400px;
        /* padding:10px; */
        border-radius: 10px;
        border: 7px solid #00ac65;
        object-fit: cover;
    }

    .slider-btns {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: #00a26975;
        color: #fff;
        font-size: 24px;
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 50%;
    }

    .prev-btn {
        left: 10px;
    }

    .next-btn {
        right: 10px;
    }
</style>

{{-- youtube-slider --}}
<style>
    .video-slider-container {
        /* max-width: 700px; */
        width: 100%;
        height: auto;
        overflow: hidden;
        position: relative;
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        padding: 20px;
    }

    .video-slider-track {
        display: flex;
        transition: transform 0.5s ease;
    }

    .video-slide {
        min-width: 100%;
        box-sizing: border-box;
        padding: 10px;
        text-align: center;
    }

    .video-slide {
        margin-bottom: 10px;
        font-size: 2rem;
        color: #fff;
    }


    .youtube-facade img {
        width: 100%;
        /* height: 400px; */
        border-radius: 8px;
        border: none;
    }

    .slider-buttons {
        display: flex;
        justify-content: space-between;
        margin-top: 15px;
    }

    .slider-buttons button {
        padding: 10px 20px;
        background: #3d1c9d;
        color: #fff;
        border: none;
        border-radius: 50px;
        cursor: pointer;
        font-weight: bold;
    }

    .slider-buttons button:disabled {
        opacity: 0.5;
        cursor: default;
    }

    .reviewer-name {
        margin-top: 10px;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        height: 60px;
        background: #3b1e9e;
        border-radius: 10px;
        color: #fff;
    }

    .reviewer-comment {
        height: 230px;
        overflow-y: scroll;
        font-size: 1rem;
        text-align: center;
        color:black;
    }

    .reviewer-meta {
        width: 100%;
        height: auto;
        background-color: #f5f2f2;
        padding: 15px;
        text-align: center;
        font-size: 14px;
        margin-top: 10px;
    }

    .reviewer-meta p {

        font-size: 20px;
        color: #3b1e9e;
    }
</style>

<script>
    // Tab Switch Logic
    const tabButtons = document.querySelectorAll(".tab-btn");
    const tabContents = document.querySelectorAll(".tab-content");

    tabButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            tabButtons.forEach(b => b.classList.remove("active"));
            tabContents.forEach(c => c.classList.remove("active"));
            btn.classList.add("active");
            const id = btn.getAttribute("data-tab");
            document.getElementById(id).classList.add("active");
            moveAssignmentSlider(0);
            moveGoogleSlider(0);
        });
    });

    // assignnmentinneed Slider

    const wrapper = document.getElementById("cardWrappers");
    const cards = wrapper.children;
    const totalCards = cards.length;
    let currentIndexs = 0;

    function getVisibleCount() {
        if (window.innerWidth >= 1024) return 3;
        if (window.innerWidth >= 768) return 2;
        return 1;
    }

    function moveSlid(direction) {
        const visible = getVisibleCount();
        const cardWidth = cards[0].offsetWidth + 20;
        const maxIndex = totalCards - visible;

        currentIndexs += direction;

        if (currentIndexs < 0) currentIndexs = 0;
        if (currentIndexs > maxIndex) currentIndexs = maxIndex;

        const offset = currentIndexs * cardWidth;
        wrapper.style.transform = `translateX(-${offset}px)`;
    }

    window.addEventListener("resize", () => {
        moveSlid(0);
    });


    // Trustpilot Slider
    let trustIndex = 0;

    function changeTrustSlide(dir) {
        const track = document.getElementById("trustSliderTrack");
        const total = track.children.length;
        trustIndex = (trustIndex + dir + total) % total;
        track.style.transform = `translateX(-${trustIndex * 100}%)`;
    }

    // Google Slider (Sitejabber)
    const googleSlider = document.getElementById("googleSliderTrack");
    const googleCards = googleSlider.children;
    let googleIndex = 0;

    function getVisibleCount() {
        const width = window.innerWidth;
        if (width >= 1024) return 3;
        if (width >= 768) return 2;
        return 1;
    }

    function moveGoogleSlider(direction) {
        const perView = getVisibleCount();
        const cardWidth = googleCards[0].offsetWidth + 20; // 20 is the gap
        const max = googleCards.length - perView;

        googleIndex += direction;
        if (googleIndex < 0) googleIndex = 0;
        if (googleIndex > max) googleIndex = max;

        googleSlider.style.transform = `translateX(-${googleIndex * cardWidth}px)`;
    }

    window.addEventListener("resize", () => moveGoogleSlider(0));

    document.addEventListener("DOMContentLoaded", () => {
        moveGoogleSlider(0);
    });
</script>

{{-- youtube tab --}}

<script>
    const videoTrack = document.getElementById("videoSliderTrack");
    const videoSlides = document.querySelectorAll(".video-slide");
    let videoIndex = 0;

    function moveSlide(direction) {
        const totalSlides = videoSlides.length;

        videoIndex += direction;
        if (videoIndex < 0) videoIndex = 0;
        if (videoIndex >= totalSlides) videoIndex = totalSlides - 1;

        const slideWidth = videoSlides[0].offsetWidth;
        videoTrack.style.transform = `translateX(-${videoIndex * slideWidth}px)`;

        document.getElementById("prevBtn").disabled = videoIndex === 0;
        document.getElementById("nextBtn").disabled = videoIndex === totalSlides - 1;
    }

    window.addEventListener("resize", () => {
        moveSlide(0); // reset on resize
    });

    // Initialize on load
    document.addEventListener("DOMContentLoaded", () => {
        moveSlide(0);
    });
</script>
