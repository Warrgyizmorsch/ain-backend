<section class="page-section testimonial-section-four">
    <div class="container">
        <h2 class="section-title">Hire Trusted Native <span>Assignment Writers</span> to Receive A+ Grades</h2>
    
        <p class="section-description">Feeling stuck with your academic writing? Don't worry—we've got you covered. At  Assignment In Need, we connect you with British academic 3,000+ PhD-level professional experts who deliver top-quality, personalised support. Say goodbye to stress and hello to high-scoring assignments, just a click away.
        </p>

        <div class="inner-container my-4">
            <div class="hm4-testimonial-carousel owl-carousel owl-theme">
                @foreach ($data['expert'] as $expert)
                    <div class="testimonial-block-four item">
                        <div class="expert-card">
                            <!-- <img src="{{ '/images/expert-default.png' }}" alt="Expert {{ $expert['name'] }}"
                                class="expert-img"> -->
                            <div class="image-outer">
                                <div class="image">
                                    <img src="{{ $expert['image'] ?? '/images/default-expert.jpg' }}" alt="Expert {{ $expert['name'] }}" class="">
                                </div>
                            </div>
                            <h3 class="expert-name">{{ $expert['name'] ?? 'Dr. Expert' }}</h3>

                            @php
    $reviews = json_decode($expert->customer_review, true) ?? [];
    $totalReviews = count($reviews);
    $averageRating = $totalReviews > 0 ? round(array_sum(array_column($reviews, 'rating')) / $totalReviews, 1) : 0;
    $fullStars = floor($averageRating);
    $halfStar = ($averageRating - $fullStars) >= 0.5;
                            @endphp

                            <div class="stars " style="text-align: right;">
                                @for ($i = 1; $i <= 5; $i++)
                                    @if ($i <= $fullStars)
                                        <i style="color:gold" class="fa fa-star"></i>
                                    @elseif ($halfStar && $i == $fullStars + 1)
                                        <i style="color:gold" class="fa fa-star-half-o"></i>
                                    @else
                                        <i style="color:gold" class="far fa-star"></i>
                                    @endif
                                @endfor
                            </div>

                            <div style="text-align: right;">
                                <a href="/free-samples">View Sample</a>
                            </div>

                            <div class="expert-description-wrapper" style="margin: 15px 0px 8px;">
                                <p class="expert-description">{!! $expert->content !!}</p>
                            </div>

                            <div class="expert-box">
                                <div class="expert-box-item">
                                    <span class="expert-box-value">{{$expert->finish_order}}</span>
                                    <div class="expert-box-details">
                                        <div class="expert-box-label">Completed</div>
                                    </div>
                                </div>
                                <div class="expert-box-divider"></div>
                                <div class="expert-box-item">
                                    <span class="expert-box-value">{{$expert->inprogress_order}}</span>
                                    <div class="expert-box-details">
                                        <div class="expert-box-label">In Progress</div>
                                    </div>
                                </div>
                            </div>

                            <div class="buttons">
                                <a href="{{ url('/upload-your-assignment') }}" class="hire-btn">Hire Writer</a>
                                <a href="{{ url('writers/' . $expert->slug) }}" class="about-btn">About Writer</a>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="custom-nav-btn">
                <button class="custom-prev"><i class="fa fa-chevron-left"></i></button>
                <button class="custom-next"><i class="fa fa-chevron-right"></i></button>
            </div>
        </div>
    </div>

    <style>
        .expert-box {
            display: flex;
            align-items: center;
            justify-content:center;
            gap: 10px;
            margin: 10px 0px 20px;
        }

        .expert-box-label {
            font-size: 17px;
            font-weight: 700;
        }

        .expert-box-value {
            font-size: 17px;
            font-weight: 400;
            color: blue;
            font-weight: 700;
        }

        .expert-box-item {
            width: 100%;
        }

        .expert-box-divider {
            width: 3px;
            height: 30px;
            background-color: #e0e0e0;
        }

        .image-outer {
            position: absolute;
            top: 18px;
            left: 40px;
            width: 80px;
            height: 80px;
            overflow: hidden;
            border-radius: 50%
        }

        .image {
            width: 80px;
            height: 80px;
            overflow: hidden;
            border-radius: 50%;
            background: white;
            padding:2px;
            margin: 0 auto;
            border: 3px solid #7f3ffb;
            box-shadow: 0 0 0 5px #e4d9ff;
        }

        .image img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .expert-description-wrapper {
            line-height: 24px;  
            max-height: 80px; /* 3 lines */
            overflow-y: auto;
        }

        .expert-description-wrapper::-webkit-scrollbar {
            width: 2px;
        }

        .expert-description-wrapper::-webkit-scrollbar-thumb {
            background-color: #ccc;
            border-radius: 10px;
        }

        .expert-description-wrapper::-webkit-scrollbar-track {
            background: transparent;
        }

        .testimonial-section-four {
            max-width: 100%;
            padding: 20px 0px !important;
        }

        .star-rating {
            font-size: 20px;
            margin: 5px auto;
            color: gold;
        }

        .expert-slider {
            overflow: hidden;
            position: relative;
            max-width: 1000px;
            margin: auto;
        }

        .slider-container {
            display: flex;
            width: 200%;
            animation: slide 20s infinite linear;
        }

        .expert-card {
            background: white;
            padding: 20px;
            position: relative;
            margin: 10px;
            border-radius: 10px;
            border: 2px solid #4821c3;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            flex: 0 0 20%;
            text-align: center;
            transition: .3s;
        }

        .expert-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        .expert-img {
            margin: -10px auto;
            height: 100px;
            width: 100px !important;
            border-radius: 50%;
            margin-bottom: 5px;
        }

        .expert-name {
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 0px;
            color: #4821c3;
            text-align: right;
        }

        .expert-card p {
            font-size: .9rem !important;
            line-height: 1.5;
            color: #333;
            text-align: justify;
            margin-bottom: 15px;
        }

        .buttons {
            display: flex;
            margin: auto;
            font-size: .9rem;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .hire-btn {
            background: #4821c3;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }

        .hire-btn:hover {
            background: #35189f;
            transform: translateY(-5px);
            background: linear-gradient(135deg, #4821c3, #35189f);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
            color: white;
        }

        .about-btn {
            background-color: white;
            border: 3px solid #4821c3;
            color: #4821c3;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        .about-btn:hover{
            background-color: #4821c3;
            color: white;

        }

        @keyframes slide {
            0% {
                transform: translateX(0);
            }

            100% {
                transform: translateX(-50%);
            }
        }



        @media (max-width: 768px) {
            .expert-card {
                flex: 0 0 90%;
                margin: 0 auto 20px;
            }

            .expert-name {
                font-size: 1.2rem;
                margin-bottom: 10px;
            }

            .expert-card p {
                line-height: 1.5;
            }

            .buttons {
                flex-direction: row;
                gap: 10px;
            }

            .hire-btn,
            .about-btn {
                width: 100%;
                font-size: 1rem;
                padding: 10px;
            }
        }

        @media (max-width: 480px) {
            .expert-card {
                flex: 0 0 100%;
                padding: 15px;
                margin: 0 auto 15px;
            }

            .expert-img {
                height: 70px;
                width: 70px !important;
            }

            .hire-btn,
            .about-btn {
                font-size: .7rem;
                padding: 6px;
            }
        }
        .custom-nav-btn {
    text-align: center;
    margin-top: 20px;
}

.custom-nav-btn button {
    background-color: #6C63FF; /* Purple */
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 8px;
    margin: 0 10px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.custom-nav-btn button:hover {
    background-color: #5a52d1; /* Darker purple on hover */
}

    </style>

</section>




<style>
.video-section {
    padding: 0;
    background: none !important;
}

.video-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 20px;
    padding: 20px;
    max-width: 1300px;
    margin: 0 auto;
}

.video-box {
    position: relative;
    aspect-ratio: 16 / 9;
    overflow: hidden;
    border-radius: 15px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    cursor: pointer;
}

.video-box img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.play-button {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 70px;
    height: 70px;
    background: rgba(0, 0, 0, 0.6);
    border-radius: 50%;
    border: 3px solid white;
}

.play-button::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-40%, -50%);
    border-style: solid;
    border-width: 15px 0 15px 25px;
    border-color: transparent transparent transparent white;
}

@media (max-width: 480px) {
    .video-grid {
        padding: 10px 0px;
        gap: 10px;
    }
}
</style>

<!-- <script>
function loadYoutube(el) {
    const videoId = el.getAttribute('data-video-id');
    const iframe = document.createElement('iframe');
    iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;
    iframe.setAttribute('frameborder', '0');
    iframe.setAttribute('allowfullscreen', '');
    iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture');
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    el.innerHTML = '';
    el.appendChild(iframe);
}
</script> -->


<!-- Owl Carousel CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

<!-- Optional theme -->

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Owl Carousel JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>


<script>
  document.addEventListener("DOMContentLoaded", function () {
    // Destroy any existing Owl Carousel instances first
    const $carousel = $('.hm4-testimonial-carousel');

    if ($carousel.hasClass('owl-loaded')) {
      $carousel.trigger('destroy.owl.carousel');
      $carousel.removeClass('owl-loaded owl-carousel owl-theme').find('.owl-stage-outer').children().unwrap();
    }

    const totalItems = $carousel.find('.item').length;
    const maxVisible = 3;

    // Reinitialize with forced loop=false
    $carousel.addClass('owl-carousel owl-theme').owlCarousel({
      loop: false,                   // Force no loop
      rewind: true,                 // Scrolls back to start at the end
      margin: 20,
      nav: false,
      autoplay: false,              // Disable autoplay for full control
      responsive: {
        0: { items: 1 },
        768: { items: 2 },
        1024: { items: maxVisible }
      }
    });

    // Custom navigation
    $('.custom-next').off('click').on('click', function () {
      $carousel.trigger('next.owl.carousel');
    });

    $('.custom-prev').off('click').on('click', function () {
      $carousel.trigger('prev.owl.carousel');
    });
  });
</script>

