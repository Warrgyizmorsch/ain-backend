<section class="page-section faq-section">
    <div class="container">
        <h2 class="section-title">Assignment in Need: <span>Frequently Asked Questions</span></h2>
        <div class="faq-container">
            <div class="faq-column">


                <div class="faq-item">
                    <button class="faq-question">
                        <span>1. What kind of assignment help do you offer and how does your service work?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            We provide comprehensive academic assistance for a wide range of assignments, including essays, research papers, dissertations, and coursework across various subjects. Our online process is simple: submit your assignment details, get a free quote, confirm your order, and our expert writers will deliver a high-quality, plagiarism-free paper by your deadline.
                        </p>
                    </div>
                </div>

                <div class="faq-item">
                    <button class="faq-question">
                        <span>2. Can you help with urgent assignments or tight deadlines?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            Yes, we specialise in expedited services for urgent assignment requests. Whether you need assistance with an assignment due tomorrow or a research paper with a tight turnaround, our team is equipped to handle quick deadlines while consistently maintaining our high standards of quality and originality.
                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>3. What subjects and academic levels do your experts cover?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            We cover a vast range of subjects and academic levels, from high school through university. Our experts are proficient in disciplines like mathematics, chemistry, English, history, law, linguistics, nursing, physics, accounting, sociology, engineering, finance, and programming, ensuring specialised support for almost any academic task.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>4. Who are your assignment writers, and are they qualified?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            Absolutely. Our team consists of over 3,000 Master's and PhD-qualified professionals from leading UK and international universities. Each undergoes a rigorous vetting process to ensure they are subject-matter experts with proven academic writing skills, guaranteeing the highest quality for your assignments.
                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>5. How do you ensure the originality and quality of the work you provide?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                           We guarantee 100% originality by writing all content from scratch and using advanced plagiarism detection tools to ensure your work is unique. Every assignment also undergoes a rigorous quality assurance process, including thorough proofreading and editing by a dedicated team, ensuring your submissions meet the highest academic standards.
                        </p>
                    </div>
                </div>
                  <div class="faq-item">
                    <button class="faq-question">
                        <span>6. How much does your assignment help service cost, and are there any discounts?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                          Our pricing is transparent and competitive, starting from £12.01, tailored to factors like academic level, assignment length, complexity, and urgency. You can get an instant, no-obligation quote using our online order form. We also offer various discounts, including 40% off for first-time users, and provide valuable freebies like plagiarism reports and unlimited revisions.
                        </p>
                    </div>
                    
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>7. Can I hire someone to help with my case study or CV writing?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            Yes, you can hire our expert writers for specialised tasks like case study assignment writing and professional CV writing. For case studies, our team delivers high-quality, customised help in every subject. Our CV writing service aims to highlight your skills and experiences effectively, helping you secure the best job opportunities.
                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>8. How can I access your services from outside the UK (e.g., Australia, Canada)?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            Students from various countries, including the UK, Australia, Spain, Canada, Malaysia, and the UAE, can seamlessly access our services online. Our platform is designed for global accessibility; simply visit our website, choose your service, and provide the necessary details to get started with our assistance.
                        </p>
                    </div>
                </div>
               
            </div>
            <div class="faq-column">
                
                <div class="faq-item">
                    <button class="faq-question">
                        <span>9. What is your refund policy if I'm not satisfied with the work?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            We offer a 120% money-back guarantee if we miss the delivery deadline or fail to meet your clear expectations based on your initial instructions. Your satisfaction is our priority, and we are committed to delivering the highest quality work or ensuring your money back, providing peace of mind with our service.
                        </p>
                    </div>
                </div>

                <div class="faq-item">
                    <button class="faq-question">
                        <span>10. Do you offer support after the assignment is delivered?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            Yes, absolutely! Our dedicated 24/7 customer support team is always available to assist you even after your assignment is delivered. Whether you have questions, need clarification, or wish to request revisions (as per our unlimited free revisions policy), we're here to ensure your complete satisfaction.
                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>11. Is using an assignment writing service ethical or legal?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            Our service provides professional academic assistance to help students understand complex topics, improve their writing skills, and manage their workload effectively. The custom content we deliver is intended to be used as a reference, a study guide, or for research purposes to aid your learning process. We encourage all students to use our services responsibly and to check their institution's specific policies.
                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>12. Is my personal information and privacy protected?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            Yes, we value your privacy and implement strict confidentiality controls to guarantee that your personal data is anonymous and secure. We will never share your information with third parties, and all our systems are protected by advanced encryption to safeguard your details throughout your use of our services.
                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>13. Do you offer assignment help in the UK specifically for British universities?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            Yes, we specialise in providing assignment help in the UK. Our UK-based writers are highly experienced with the UK academic standard and the specific requirements of British universities. We ensure your paper is perfectly aligned with local educational expectations.
                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>14. Can you write my assignments in UK university formatting and styles?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            Absolutely. When you ask us to write your assignments, our professional writers are highly proficient in all major UK university formatting and referencing styles, including Harvard, OSCOLA, APA, MLA, and Chicago. We guarantee your paper will be meticulously formatted to your institution's specific guidelines.
                        </p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <button class="faq-question">
                        <span>15. What payment methods do you accept for your services?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            We accept a variety of secure payment methods for our services, including major credit/debit cards (Visa, MasterCard, American Express) and other trusted online payment gateways. All transactions are encrypted with the latest technology to ensure your financial data remains safe and confidential throughout the payment process.
                        </p>
                    </div> 
                </div>
                
                <div class="faq-item">
                    <button class="faq-question">
                        <span>16. Can I communicate directly with the writer working on my assignment?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>
                            Yes, our platform allows you to communicate directly with your writer. This ensures that you can provide additional details, ask questions, and receive updates throughout the writing process to ensure the final work meets your expectations.
                        </p>
                    </div>         
                </div>
                
            </div>
        </div>
        <a href="/faqs"> <button class="expert-btn">View More FAQs </button></a>
    </div>
</section>

<style>
    .faq-container {
        display: flex;
        justify-content: center;
        gap: 20px;
    }

    .faq-column {
        width: 45%;
    }

    .faq-item {
        margin-bottom: 10px;
        border: 2px solid #5e2ced;
        border-radius: 5px;
        overflow: hidden;
    }

    .faq-question {
        width: 100%;
        text-align: left;
        background: white;
        padding: 15px;
        cursor: pointer;
        font-size: 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border: none;
        font-weight: 500;
    }

    .faq-question i {
        transition: transform 0.3s ease-in-out;
        color: #5e2ced;
    }

    .faq-answer {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.4s ease-out, padding 0.4s ease-out;
        padding-bottom: 15px;
        background: #f9f9f9;
        font-size: 14px;
    }
    .faq-answer p {
        margin: 0;
        padding: 10px;
        font-size: 1rem;
        line-height: 1.5;
        text-align: justify;
    }

    .faq-item.active .faq-answer {
        max-height: 150px;
        padding: 10px 15px;
    }

    .faq-item.active .faq-question i {
        transform: rotate(180deg);
    }

    @media (max-width: 768px) {
        .faq-container {
            flex-direction: column;
            align-items: center;
            margin: auto;
            gap: 0;
        }

        .faq-column {
            width: 100%;
        }
    }
</style>

<script>
    document.querySelectorAll(".faq-question").forEach((button) => {
        button.addEventListener("click", () => {
            const faqItem = button.parentElement;
            const faqAnswer = faqItem.querySelector(".faq-answer");

            // Close other open FAQs
            document.querySelectorAll(".faq-item").forEach((item) => {
                if (item !== faqItem) {
                    item.classList.remove("active");
                    item.querySelector(".faq-answer").style.maxHeight = null;
                }
            });

            // Toggle current FAQ
            faqItem.classList.toggle("active");
            if (faqItem.classList.contains("active")) {
                faqAnswer.style.maxHeight = faqAnswer.scrollHeight + "px";
            } else {
                faqAnswer.style.maxHeight = null;
            }
        });
    });
</script>