 
 @extends('frontend-layouts.app')

@section('content')



<style>
		.text {
			color: #0c0d24;
			line-height: 1.8em;
			font-size: 16px;
		}
		.text-black{
			color: black;
			
		}
		.banner-section-three .content-column .inner-column {
			padding-top: 5px;
		}
		
	</style>
	<style>
		.iti {
			position: relative;
			display: inline-block;
			width: 100%;
		}
	</style>

	<style>
		.header-section 
		{
			background: rgb(255,255,255);
			background: linear-gradient(170deg, rgba(255,255,255,1) 6%, rgba(135,166,219,0.4009978991596639) 72%, rgba(135,166,219,0.5690651260504201) 91%, rgba(126,137,221,0.865983893557423) 100%);
		}

		h1 {
			font-size: 35px;
			font-weight: 600;
			color: black
			}

		p {
			position: relative;
			line-height: 1.8em;
			font-size: large;
			color:black;
			text-align: justify;
		}
		.place-order 
		{
			background:#d7f0fd; 
			color:black;
			padding: 10px 20px;
			border-radius: 5%;
			margin: 10px;
		}
		.place-now
		{
			background:#77bfe5; 
			color:black;
			padding: 20px 80px;
			border-radius: 3%;
			margin: 10px;
			font-weight: 500;
			font-size: 20px;
		}
		.place-order:hover
		{
			background:#7e89dd;
			color:white ;

		}
		.place-now:hover
		{
			box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;			
			color: white;
			transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */

		}
		.order-now		
		{
			font-size: 25px;
			font-weight: 500;	
			color: black;
		}

		.offer-badge {
		    position: absolute;
			top: -65px;
			right: -30px;
			color: white;
			font-weight: bold;
			border-radius: 10%;
			font-size: 17px;
			z-index: 0;
		}
		.banner-stats-title
		{
			font-size: 30px;
			font-weight: 600;
			color: black;
		}
		.banner-stats-container {
			display: flex;
			justify-content: space-between;
			text-align: center;
		}

		.banner-stat {
			flex: 1;
			padding: 0 10px; /* Adjust the space between elements */
		}

		.banner-stats-text {
			font-size: 1em;
			margin-top: 5px;
		}
		
		ul 
		{
			font-size: 17px;
			color: black;
		}

		h3 
		{
			font-size: 21px;
			font-weight: 500;
			color: black;
		}

		@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

			.image-container {
				width: 50%;
			}

			.text-content {
				width: 50%;
				margin-left: 40px;
			}

			.text-content h2 {
				font-size: 2rem;
			}
		}

		.current_offer
		{
			font-weight: bold;
			font-size: 35px;
		}

		.offer-container
		{
			background: rgb(221,245,245);
			background: -moz-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: -webkit-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5",endColorstr="#6ebae7",GradientType=1);
						background-color: white; 
			border-radius: 
			5px; 
			box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); 
			padding: 20px;
		}

		@media (min-width: 1200px) {
    .container {
        max-width: 1199px;
    }
}
	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}
	.offer-badge-offer:hover{

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
				transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
    padding: 0px 0px 0px;
}
      /* Assignment Writing */
	</style>

	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">
				
				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center">Expert Online Math Assignment Help | Math Homework Help for Detailed Solutions
						</h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Rating</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
				
				@include('formsection')
			</section>
			<section class="news-section-two py-3 mt-3">
		<div class="auto-container">
			<div class="row clearfix">
				<div class="col-md-12 col-md-offset-2">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center my-4">How Our Math Assignment and Homework Help Services Work for Students?</h2>
				
				</div>
				<div class="blocks-column col-lg-12 col-md-12 col-sm-12 mt-2">
					<div class="inner-column">
						<div class="row clearfix p-2">
							<div class="column col-lg-4 col-md-4 col-sm-12 ">
								<div class="news-block-four mt-0">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/shopping-list.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Submit Your Order</a></h3>
										<div class="text">Complete the "Order Now" form by sharing your basic details and outlining the specific requirements you'd like us to meet.</div>
										
									</div>
								</div>
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="150ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 150ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/secure-payment.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Make Secure Payment</a></h3>
										<div class="text">Pay a budget-friendly price through our fully secure payment gateway, ensuring complete privacy and safety.</div>
									</div>
								</div>
								
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/sharing.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Receive Your Paper</a></h3>
										<div class="text">
										Get a top-notch assignment crafted by our expert writers, delivered on time, and designed to help you achieve exceptional grades.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/Offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Our Writer -->
	  @if($data['expert']->isEmpty())
    
@else
    <!-- Case: Experts are available -->
    <section class="testimonial-section-three py-0">
        <div class="color-layer"></div>
        <div class="auto-container">
            <div class="sec-title">
                <div class="section-color-layer"></div>
                <h2 style="font-weight:500; font-size: 30px; color:black">
                  Our Writer For Online math Assignment Help Service<
                </h2>
            </div>
            <div class="testimonial-carousel-three owl-carousel owl-theme">
                @foreach($data['expert'] as $expert)
                    <!-- Testimonial Block Three -->
                    <div class="testimonial-block-three">
                        <div class="inner-box">
                            <div class="image-outer">
                                <div class="image">
                                    <img src="{{$expert->image}}" alt="Expert Image" />
                                </div>
                                <div class="quote flaticon-left-quote"></div>
                            </div>
                            <h6>{{$expert->name}}</h6>
                            <div class="designation" style="
                                color: blue !important;
                                margin: 0 auto;
                                text-align: center;
                                width: auto;
                                padding: 5px 15px;
                                border-radius: 20px;
                                font-size: 20px;
                                font-weight: 700;">
                                {{$expert->service}} Writing Help
                            </div>
                            <div class="text" style="text-align: justify; margin-top: 10px;">
                                <span class="short-content">
                                    {{ Str::limit($expert->content, 150) }}
                                </span>
                                <span class="full-content" style="display: none;">
                                    {{$expert->content}}
                                </span>
                                <button class="btn-toggle" onclick="toggleContent(this)" style="
                                    margin-top: 5px;
                                    border: none;
                                    background-color: transparent;
                                    color: #007BFF;
                                    cursor: pointer;">
                                    ...
                                </button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="lower-text">Click the button for slide</div>
        </div>
    </section>
@endif

	<script>
    function toggleContent(button) {
        const textContainer = button.parentElement;
        const shortContent = textContainer.querySelector('.short-content');
        const fullContent = textContainer.querySelector('.full-content');

        if (shortContent.style.display === 'none') {
            shortContent.style.display = '';
            fullContent.style.display = 'none';
            button.textContent = '...';
        } else {
            shortContent.style.display = 'none';
            fullContent.style.display = '';
            button.textContent = 'Less';
        }
    }
</script>

    <!-- Assignment Writing Help In Math -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Online Math Assignment Writing Help Services</h2>

							<p>Looking for help with a math assignment? Math plays an important part in both our personal and academic lives to solve real-world issues. It helps understand complex concepts and increases your chances of getting a high-paying job, especially in the STEM fields.</p>
							<p>However, many students find math tough (if not boring). They are scared of making mistakes and often need help with math assignments. So how to overcome this? Consulting professionals like Assignment in Need.</p>	 
							 <p>We can help you understand tough concepts and give personal help with me with math homewmork. Our online <a href="https://www.assignnmentinneed.com/uk/online-math-assignment-helper"><b>math assignment help</b></a> not only boosts your confidence and grades but also shows how math shapes everything around us and help to improve learning in math subjects. </p>
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>




       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our Online Math Assignment Help Service today and enjoy a special discount!</h2>
							<p>Get help with your math assignment writing easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>
	<!-- Our Mathematics Assignment Help and Services -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Our Mathematics Assignment Help and Services For Students</h2>
                            
                            <p>How can our consulting professionals assist with math assignments? For instance, we provide:</p>
                            <p><b>Detailed Solutions: </b> Our team of experts provides comprehensive solutions to solve any math problem. They break down complex math concepts into easy-to-understand steps that help students to learn effectively and perform better in your assignments.</p>
                            <p><b>Various Math Fields:</b> Our experts can help you in various areas of mathematics, from algebra to calculus. Whether you're struggling with geometry or basic arithmetic, our knowledgeable experts can help you through your math assignments online.</p>
                            <p><b> Personalized Assistance:</b> We offer personalized assistance based on your specific math assignment needs and learning styles. Whether you're stuck with your assignments, struggling to understand certain concepts or need to revise for your tests, our experts are here to help you every step of the way.							</p>
                             
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="popular-subjects-section">
  <div class="container text-center">
    <h2 class="heading">Get Popular Subjects for Math Assignment Help And Math Homework Help </h2>
    <p class="description">
    Math assignment help ensures you get clear, detailed solutions from PhD-level experts. With over 45,000+ assignments delivered, we guarantee timely help you succeed in academic assignments and homework help.

    </p>
    <ul class="subject-list">
      <li><a href="https://www.assignnmentinneed.com/algebra-assigment-help">Algebra Assignment Help</a></li>
      <li><a href="https://www.assignnmentinneed.com/geometry-assignment-help">Geometry Assignment Help</a></li>
      <li><a href="https://www.assignnmentinneed.com/calculus-assignment-help">Calculus Assignment Help</a></li>
      <li><a href="https://www.assignnmentinneed.com/probability-assignment-help">Probability Assignment Help</a></li>
      <li>Statistics Assignment Help</li>
      <li><a href="https://www.assignnmentinneed.com/linear-algebra-assignment-help">Linear Algebra Assignment Help</a></li>
    </ul>
    <button class="show-more-btn" id="more-subject">Show More</button>
  </div>
</section>

<script>
  document.getElementById("more-subject").addEventListener("click", function () {
    const subjectList = document.querySelector(".subject-list");
    const showMoreBtn = document.getElementById("more-subject");

    const moreSubjects = [
      '<li><a href="https://www.assignnmentinneed.com/trigonometry-assignment-help">Trigonometry Assignment Help</a></li>',
      '<li>Differential Equations Assignment Help</li>',
      '<li>Mathematical Modelling Assignment Help</li>',
      '<li>Number Theory Assignment Help</li>',
      '<li>Mathematical Logic Assignment Help</li>',
      '<li>Combinatorics Assignment Help</li>'
    ];

    if (showMoreBtn.textContent === "Show More") {
      subjectList.innerHTML += moreSubjects.join("");
      showMoreBtn.textContent = "Show Less";
    } else {
      const currentSubjects = subjectList.querySelectorAll("li");
      // Remove the extra subjects
      for (let i = currentSubjects.length - 1; i >= 6; i--) {
        currentSubjects[i].remove();
      }
      showMoreBtn.textContent = "Show More";
    }
  });
</script>
	
    <!--Why Choose Our Service for Math Assignments Help?-->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Choose Our Service for Math Assignments Help?</h2>
                              <p>But why choose us and not others for your online math assignment help? Simply because we provide:</p>


                           <h3>Quality Assistance</h3>
                       
                           <p>We make it easy for you to grasp difficult math concepts and ensure clear solutions and accurate answers for your math assignments with our top-notch support. </p>
                         
                           <h3>Customized Support for Every Student</h3>
                           <p>Each student has different math needs, so we offer personalized solutions. Our experts give tailored guidance and adjust to your specific needs to help you understand any problem or learn new things.
						   </p>
                           
						    <h3>Timely Delivery of Your Math Assignment</h3>
                            <p>Delivering services on time is just as important as being an expert in the field. Our experts keep punctuality as their top priority. Whether it's delivering our services or timely help, our experts make sure to stay on track with your academic goals.</p>

							<h3>Academic Success For Students</h3>
                            <p>Our math assignment help is designed to enhance your academic performance. By working with our experts, you’ll not only complete assignments accurately but also improve your overall understanding of math, leading to better understanding and stronger problem-solving skills.</p>
							
							<h3>A Proven Track Record of Student Satisfaction</h3>
                            <p>We have built a reputation that has existed for ages with satisfied students, ensuring reliable and quality math assignment help. As you would see, the track record speaks for itself: our service and results deliver outstanding quality, and many students keep coming back for future assignments.
							</p>

							<h3>Continuous learning and improvement for your success</h3>
                            <p>We don't only help with assignments; we help grow the academic side of students. Our experts ensure every session adds to your long-term success by offering continuous learning and improvement in math skills. This focus on development prepares you for exams and more difficult math challenges in life.
						</p>
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


    <!-- Types of Assignments We Handle -->
    <section class=" py-p">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Types of Math Assignments and Homework Help We Cover</h2>
                              <p>Wondering if we can help you with your specific assignment needs? Check out the types of math homework help we provide:</p>
							
                            
                              <p><b>Online Math Assignment Help for Algebra: </b>  If you ever find yourself needing help with maths assignments, then we are here for you. Our experts cover every aspect of algebra, from equations to working functions. We can help you master the fundamentals and advanced topics of algebra whether it's linear equations, systems of equations, or polynomials. </p>
							  <p><b>Online Math Assignment Help for Calculus: </b> Calculus can get pretty tricky and might put you in a situation where you need help. But don't worry, we understand that Calculus can be daunting. Our experts can make it manageable for you by assisting with simple topics like derivatives as well as advanced topics like multivariable calculus.							  </p>
                              <p><b>Online Math Assignment Help for Statistics:  </b> Statistics and Probability questions can be tough and often demand a lot of time, knowledge, and effort. If you also find yourself confused every time you try to interpret data for your math assignment then our experts can assist you with topics like probability, hypothesis testing, regression analysis, and more.</p>
                              <p><b>Online Math Assignment Help for Geometry:  </b>  Our experts support you throughout the visual and analytical skill requirements of geometry. We provide comprehensive geometry services that include theorems and calculations whether it's Euclidean or coordinate geometry.</p>
                              <p><b>Online Math Assignment Help for Trigonometry:</b> Our experts can assist you in trigonometry functions, identities, and equations with real-life examples and simple explanations, whether it's sin, cos, and tan or tackling complex trigonometric problems.
							  </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="instructor-section">
	<div class="auto-container">
		<div class="row clearfix">
			<div class="instructor-column col-lg-6 col-md-12 col-sm-12">
				<h2 style="font-weight:500; font-size: 30px; color:black" class="text-start my-4">
					Get Well-Written Assignments in 3 Simple Steps
				</h2>
				<div class="inner-column wow fadeInRight animated" data-wow-delay="0ms" data-wow-duration="1500ms"
					style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInRight;">
					<div class="feature-inner">
						<div class="row">
							<div class="col-2 mt-4">
								<div class="icon"
									style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
									<span
										style="font-size: 39px; color: #04aef3; border: 3px dashed #04aef3; border-radius: 50%; padding: 10px; display: inline-block; text-align: center; width: 50px; height: 50px;">
										1
									</span>
								</div>
							</div>
							<div class="col-10">
								<h3 style="margin: 10px 0; font-size: 20px; font-weight: bold;">Explore Assignment Samples</h3>
								<p style="margin: 0; line-height: 1.6; font-size: 16px; color: black;">
									Explore a variety of free academic samples to understand the quality of work we provide. Each sample showcases the level of detail and research that goes into our assignments.
								</p>
							</div>
						</div>
 
						<div class="row">
							<div class="col-2 mt-4">
								<div class="icon"
									style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
									<span
										style="font-size: 39px; color: #04aef3; border: 3px dashed #04aef3; border-radius: 50%; padding: 10px; display: inline-block; text-align: center; width: 50px; height: 50px;">
										2
									</span>
								</div>
							</div>
							<div class="col-10">
								<h3 style="margin: 10px 0; font-size: 20px; font-weight: bold;">Get Popular Subjects for Math Assignment Help And Math Homework Help</h3>
								<p style="margin: 0; line-height: 1.6; font-size: 16px; color: black;">
									Pick the sample that best matches your assignment type and subject. This will give you a clear idea of how we approach different topics and formats.
								</p>
							</div> 
						</div>
   
						<div class="row">
							<div class="col-2 mt-4">
								<div class="icon"
									style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
									<span
										style="font-size: 39px; color: #04aef3; border: 3px dashed #04aef3; border-radius: 50%; padding: 10px; display: inline-block; text-align: center; width: 50px; height: 50px;">
										3
									</span>
								</div>
							</div>
							<div class="col-10">
								<h3 style="margin: 10px 0; font-size: 20px; font-weight:bold">Download Your Sample</h3>
								<p style="margin: 0; line-height: 1.6; font-size: 16px; color: black;">
									Click the download button to get your chosen sample in PDF instantly. You can review it at your own pace and use it as a reference for your assignment.
								</p>
							</div>
						</div>
					</div>
				</div>
				<div style="text-center" class="mt-4">
					<a href="/upload-your-assignment"><button class=" place-now " style="padding: 10px 20px; color:white">Order Assignment</button></a>
				</div>
			</div>

			<div class="instructor-column col-lg-6 col-md-12 col-sm-12">
				<h2 style="font-weight:500; font-size: 30px; color:black" class="text-start my-4">
					8000+ Samples Reflect the High Standard of Our Work
				</h2>
				@foreach ($data['sample'] as $sample )
				<div class="inner-column wow fadeInRight animated" data-wow-delay="0ms" data-wow-duration="1500ms"
					style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInRight;">
				
					<div class="row">
						<div class="col-2 mt-4">
							<div class="icon"
								style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
								<a href="free-samples/{{$sample->categotyData->name}}/{{$sample->slug}}">
								<img src="images/image.png" style="width: 60px; height: 120px; box-shadow:rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px" alt="">
								</a>
							</div>
						</div>
						<div class="col-10 mb-4">
							<h3 style="margin: 10px 0; font-size: 20px; font-weight: bold;"><a style="color:black" href="free-samples/{{$sample->categotyData->name}}/{{$sample->slug}}">{{$sample->title}}</a></h3>
							<p style="margin: 0; line-height: 1; font-size: 15px; color: #0000008a; font-weight: 700; box-shadow:">
								#{{$sample->categotyData->name}}
							</p>
							@php
								$pageCount = ceil(str_word_count(strip_tags($sample->content)) / 250);
							@endphp
							<div><p class="samplefeature"><span>Number of pages: <b>{{$pageCount}}</b></span> <span>Total Words: <b>{{ str_word_count(strip_tags($sample->content)) }}</b></span></p></div>
						</div>
					</div>
				</div>
			
				@endforeach
				<div style="text-center" class="mt-4" >
					<a href="/free-samples"><button class=" place-now " style="padding: 10px 20px; color:white">View More Sample</button></a>
				</div>
			</div>
			
			</div>
		
	</div>
</section>
       
    <!--Benefits of Our Service -->
    <section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Benefits of Our Math Assignment Help Service</h2>
                             <p>So how can our math homework help and math assignments help benefit for students? Here's how:</p>
							 <p><b>Online Math Assignment Help for Improving Grades: </b> With our expert guidance and clear explanations, you'll see your grades improve significantly over time. Our services are designed to help you do better in school.</p>
                             <p><b>Mathematics Assignment Help for Better Understanding:</b> We focus on improving your overall mathematical concepts by providing clear explanations and personalized assistance.</p>
                             <p>This will help you gain a deeper understanding of the subject matter for building a stronger foundation for any future learning.</p>
							 <p><b>24/7 availability for timely help: </b> Whatever your time zone or deadline may be, our math assignment help is available. You can always reach us when you need help in order to avoid missing the time at which you are supposed to submit assignments on time.</p>
							 <p><b>Boost Your Confidence with Solutions from Experts:</b> Working with our math experts will not only help you solve problems but also boost your overall confidence. By regularly tackling math assignments with expert support, you'll start to feel more competent and secure in your math abilities.</p>
						 	 <p><b>Improved Problem-Solving Skills: </b>With our step-by-step solutions and explanations, you will gain better problem-solving skills not just for your assignments at this moment but also for your future studies and even to the world outside.</p>
						      <p><b>Save Time for Other Subjects:</b> Math assignments can consume so much time. By taking advantage of our expert aid, you will save a lot of time to engage with other subjects or activities so that your academic life remains well balanced.</p>
							 <p><b>High-Quality Work that Meets Your Standards: </b>We ensure high-quality work for every math assignment. Our experts deliver well-researched, detailed solutions that meet your academic institution's standards, ensuring that your assignments are error-free and accurately presented.							 </p>
					
						
							</div>
					</div>
				</div>
			</div>
		</div>
	</section>
    
     <!--Our Seamless Math Assignments Help Process -->
     <section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Our Seamless Math Assignments Help Process For Students	</h2>
                           
                           <p>Online Math Assignment Help for Students, submitting your assignment is quick and easy to do with our user-friendly website. If you've got a math problem and need assistance. All you have to do is to upload your assignment on our website. </p>
						   <p>Get a Price Quote: After you submit your assignment, we will carefully review it and then contact you with a price that fits your budget. Our prices are based on your specific needs and the assignment's complexity.</p>
						   <p>Expert Matching: Your assignment will then be paired with one of our math experts who is highly qualified and specializes in your field. This way, we'll ensure you get the best assistance possible.</p>
						   <p>Customized Solutions: Our next step is to ensure you understand the material thoroughly and get a customized solution. The math expert assigned to you will start working hard on creating a step-by-step solution or a detailed explanation that best suits your assignment needs.</p>
						   <p>Personalized Support: If you need more help, we offer one-on-one tutoring sessions and extra resources to help you understand the concepts better. This won't only help you understand the concepts clearly but also improve your math skills
						   </p>      
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

    
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Ace Your Math Coursework with Our Expert Support and Secure Top Grades</h2>
                           
                           <p>Do you find that the maths homework is becoming problematic for you? Sometimes, mathematics is an imposing challenge that arises from stressful deadlines and challenging concepts, making you feel overwhelmed. Algebra, calculus, or statistics: the challenges could add up quickly. Don't worry—Assignment in Need is here to turn your challenges into successes.</p>
						    <p>Our math homework help services are designed to simplify your academic journey while improving your grades. With a dedicated team of expert mathematicians, we offer precise solutions and personalized guidance designed to meet your unique challenges. We help you navigate coursework, prepare for exams, and address the math dissertation help you need by providing the clarity and confidence you need to thrive at every stage of your academic journey.</p>  
						   <p>So why struggle alone? Choose Assignment in Need and turn your math challenges into stepping stones for success.</p>     
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Math Homework Help Online: The Ultimate Solution for Busy Students</h2>
                             <p>Do you often feel like asking yourself, “I need help with my math homework—who can assist me?” You are not alone. At school, college, or university, things do get very demanding. Ticking deadlines and grasping some intricate math concepts can make you feel overwhelmed. Mostly, late nights spent trying to solve problems, multiple assignments, and math become sources of stress. At Assignment in Need, we understand how overwhelming it can feel when math becomes a source of stress rather than progress.</p>
							 <p>This is where Our math homework service is the ideal solution for busy students. We break down convoluted theorems, simplify complex calculations, and help through each step of complicated challenges. Whether you need calculus homework help, like statistics, algebra, or perhaps simple but very important geometry, a solution to your assignment is at hand.
							 </p>
							 <p>But we don't just help you finish homework. We help you grasp the material. Our services are supposed to ease your workload, thereby improving your mathematical confidence and ultimately ensuring that you become successful in academics and grow empowered in your math endeavors.</p> 
							<p>To simplify, let our experts take care of the tiresome tasks as you study and secure good grades. With our help, math is no longer a struggle, but an opportunity to shine!</p>
                          </div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Do Students Frequently Say, “Can Someone Help Me With My Math Homework?”</h2>
                             <p>Math can be intimidating. It is not just about numbers, but about conquering logic, precision, and interconnected concepts. When piling up assignments with exams, projects, and other coursework, no wonder that students feel this way. That’s why so many turn to math homework help online, seeking a lifeline to manage the complexity and pressure.
							 </p>
							 <p>At Assignment in Need, we often hear countless students ask, “Help me with my math homework!” because they struggle with:</p>
							 <ul>
								<li><p><b>Struggling with Advanced Topics:</b> Whether it’s calculus integrals, trigonometric identities, or statistical analysis, higher-level math can be challenging to understand without proper guidance.</p></li>
							    <li><p><b>Tight Deadlines:</b> With limited time and multiple subjects to juggle, solving intricate math problems often feels impossible.</p></li> 
							    <li><p><b>Dense Coursework:</b> Rushed lessons and dense material can leave students feeling lost and unsure of how to approach their homework.</p></li>
							</ul>
						   <p>This is where we step in. Our expert team simplifies tough concepts, breaks problems into manageable steps, and ensures every solution is clear and precise. But we don’t stop at just completing with your math hw help—we ensure you gain the confidence to master the subject.</p>
						   <p>Let Assignment in Need bridge the gap between frustration and success. Get rid of the stress behind you and welcome the success in academics ahead of you!</p>	
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
    

	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Can You Help Me With My Assignment for Different Educational Boards? Absolutely!</h2>
                             <p>No matter which curriculum you’re following—national, international, or private—our experts have the experience and expertise to handle assignments across all major educational boards. From applying differential equations in AP Calculus, solving trigonometric identities in IB Math HL, or, last but not least, understanding geometry problems in a local curriculum, we are here to assist you.</p>
							 <p>Our math homework solver is designed to adapt to the unique challenges of your syllabus. From middle school assignments to advanced college-level coursework, we provide precise and comprehensive solutions tailored to your academic requirements.</p>
							  <p>We have a team of specialists drawn from diversified educational backgrounds to answer in detail the way the board expects. Be it anything too complex or narrow to discuss—we are here for your successful solution, step after step.</p>
							  <p><b>How Maths Plays a Vital Role in Other Subjects and Fields</b></p>
							  <p>Mathematics is the foundation of logical thinking and problem-solving, which molds how we perceive and interact with the world. From algebra to calculus, Maths equips students with the tools needed to face real-world challenges. It's not just a subject but a universal language that bridges diverse disciplines and unlocks countless opportunities.
							  </p>
						   	</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Physics: Unraveling the Universe with Equations</h2>
                             <p>Maths is the backbone that understands the laws of physics to govern the universe. Equations make an abstract concept into a physical one by reducing the complication of motion, energy, and matter. It works from calculating gravitational forces for predicting the trajectory of objects, and this can always be done through the principles that define mathematical terms in <a href="https://www.assignnmentinneed.com/physics-assignment-writing-help"><b>physics assignment help</b></a>.</p>
						   	</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Statistics: Turning Data into Meaningful Insights</h2>
                             <p>Statistics is another area where Maths plays an indispensable role. From analyzing survey data to predicting market trends, Maths transforms raw numbers into actionable insights. By mastering statistical methods, students can interpret real-world data, which is crucial for disciplines like business, healthcare, and social sciences. If you need guidance, <a href="https://www.assignnmentinneed.com/statistics-assignment-writing-help"><b>Statistics assignment help</b></a> provides expert assistance in breaking down complex datasets.</p>
						   	  <p>A strong base in Maths also helps in future careers as an engineer, computer scientist, or even further. It doesn't only ensure academic success but also readies students to become professionals who can really tackle the challenges of problem solving and analytical thinking.</p>
							</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">We Handle All Grade Level Math Assignment Help For Students</h2>
                             <p>Whether you're fighting middle school algebra or exploring advanced college math dissertation help, we're here for you. Our services cover all levels of mathematical education, so you get the support you seek at whatever stage in school.
							 </p>
						   	<p>Whether you are a school, college, university or other grade level student asking: I need someone to do my math homework for me. Or a university learner struggling with challenging coursework, we are here for all level math <a href="https://www.assignnmentinneed.com/assignment-writing-help-services"><b>assignment writing help</b></a>  and homework help for students.</p>
							<p>Our comprehensive assistance includes:</p>
	<ul>

     <li>
        <p><strong>School-Level Support:</strong> Are arithmetic, geometry, or introductory algebra causing frustration? We simplify foundational concepts, ensuring you grasp them with ease and confidence.</p>
    </li>
    <li>
        <p><strong>College-Level Expertise:</strong> Stuck on advanced topics like calculus, linear algebra, or differential equations? Our tutors are experienced in tackling complex coursework and breaking it down step by step.</p>
    </li>
    <li>
        <p><strong>Specialized Math Dissertation Help:</strong> Mathematics dissertations are quite overwhelming, but we will provide you with research, data analysis, and present your findings in precise and clear terms.</p>
    </li>
    <li>
        <p><strong>University-Level Math Help:</strong> University mathematics is advanced in nature and prepares students for research, engineering, and data-driven careers. Our expertise includes:</p>
        <ul>
            <li><p>Abstract Algebra: Groups, rings, and fields.</p></li>
            <li><p>Real Analysis: Functions, sequences, and series.</p></li>
            <li><p>Complex Analysis: Study of complex numbers and functions.</p></li>
            <li><p>Numerical Methods: Algorithms for mathematical problem-solving.</p></li>
            <li><p>Differential Equations: Ordinary and partial differential equations.</p></li>
            <li><p>Discrete Mathematics: Graph theory, logic, and combinatorics.</p></li>
            <li><p>Optimization: Applications of linear programming and game theory.</p></li>
        </ul>
    </li>
    <li>
        <p><strong>Postgraduate Math Help:</strong> For postgraduate students with research-level math, we are here to help.</p>
        <ul>
            <li><p>Mathematical Modeling: Simulations and predictions in reality.</p></li>
            <li><p>Functional Analysis: Theory of operators and Hilbert spaces.</p></li>
            <li><p>Topology: Geometry, topological spaces, and continuous transformations.</p></li>
            <li><p>Applied Statistics: Multivariate data analysis, regression models, Bayesian inference, and more.</p></li>
        </ul>
    </li>
    <li>
        <p><strong>Online Tests for Math Competency and Preparation:</strong> Standardized and competition exams. Get prepared with your math skills through our qualified support:</p>
        <ul>
            <li><p>SAT, ACT Support for Math problems and data analyses.</p></li>
            <li><p>GRE and GMAT Math Help: Advanced quantitative reasoning for postgraduate admissions.</p></li>
            <li><p>Olympiad Math Help: Training for International and National Mathematics Olympiads.</p></li>
        </ul>
    </li>
    <li>
        <p><strong>Math for Special Needs Students:</strong> We also provide tailored math help for children with learning disabilities:</p>
        <ul>
            <li><p>Step-by-Step Explanations: Breaking down complex problems into simpler steps.</p></li>
            <li><p>Adaptive Learning Techniques: Using visual aids and manipulatives for better comprehension.</p></li>
            <li><p>Focused Support: One-on-one sessions designed for their unique learning style.</p></li>
        </ul>
    </li>
</ul>
   
   <p>No matter what difficulties your assignment may present, our team of seasoned experts tailors their approach to suit your specific needs. With accurate, personalized solutions, we enable you to succeed in your coursework and establish a solid mathematical foundation.</p>

   <p>Say goodbye to late-night struggles and incomplete assignments. Let us handle your math problems so you can focus on achieving your academic goals!   </p>


							</div>
					</div>
				</div>
			</div>
		</div>
	</section>


	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Online Math Class Problems Help from Experienced University Tutors</h2>
                             <p>Are you tired of lagging in your online math classes? Our experienced tutors expressly understand students' challenges while working in virtual classrooms and focus their approach on coursework, assignments, and exams. Our experts provide tailored support for virtual classes, offering explanations, solutions, and personalized assistance to meet individual learning goals.</p>
						   	  <p>By choosing our math coursework help, you’ll get access to step-by-step solutions, one-on-one sessions, and expert insights into concepts you may find tricky. Whether it’s solving calculus equations or understanding probability distributions, we’re here to help you navigate your math journey seamlessly. </p>
							</div>
					</div>
				</div>
			</div>
		</div>
	</section>

      <!-- new section -->

	 <section class="py-4" style="background-color:#BFECFF;"  >
	            <div class="auto-container">
                    <div class="row clearfix">

			<!-- Content Column -->
			  <div class="content-column col-lg-6 col-md-12 col-sm-12">
				 <div class="inner-column">
					<h2 class="py-3" style="font-weight:500; font-size: 30px; color:black">Online Math Assignment Writing Help Services for All Students across the World</h2>
					  <div class="text">
						 <p>Assignment in Need offers math assignment help designed to support students in Spain, Australia, Canada, UAE, the UK, and Malaysia with their academic needs. With 30,000+ happy clients and 9/10 students reporting better grades, their team of experienced experts provides personalised assistance, guiding learners through every aspect of their maths assignments, from foundational concepts to advanced topics. Whether it’s algebra, calculus, or statistics, the platform ensures improved understanding and performance. With a focus on helping students achieve academic success, prompt delivery, and clear solutions, Assignment in Need makes building a strong foundation in maths both accessible and effective. Mastering maths is within reach, no matter where students are.</p>
						</div>
					 
			          <a href="/upload-your-assignment"> <button style="background: #37AFE1;  color:black; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >Order Now</button> </a>	 
			     </div>
			 </div>

			<!-- Image Column -->
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">
					 <div class="image titlt"  style="mix-blend-mode: multiply;">
						<img src="images2\resource\unnamed (5).png  " alt="">  
					</div>        
				</div>
			</div>

		</div>
	</div>
            </section>

            <!-- end new section -->
 
	    <!-- FAQs Question  section for Expert Assignment Writing Help -->
 
	        
		<section class="faq-section bg-light">
	    	<div class="auto-container">
			<div class="row ">
				<div class="titel-column col-lg-12 col-md-12 col-sm-12">
				    <div class="title-box text-center">
						<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4"><b>Frequently Asked Questions For Math Assignment Help</b></h2> 
					 </div>
					<div class="row"> 
					 		 
				<div class="column col-lg-6 col-md-6 col-sm-12 ">
					 
					<ul class="accordion-box ">
					       <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">1. How do I submit my math assignment for help?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <p>You can submit your assignment in two ways, by clicking on the submit button on our website and the other by emailing it with your specific requirements. In both cases, we'll respond to your assignment accordingly.</p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">2. How much does it cost to get help with my math assignment?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>We provide the most affordable prices and they depend on your needs and the complexity of the assignment. You'll get a price quote once we review your assignment after you send it to us.</p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">3. How quickly can I get my assignment done?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <p>Our main goal is to complete your assignment as soon as possible, typically a day before the required date. But in cases of tight deadlines, for example, a 3-day delivery, you can expect your work on day 2 or day 3.</p>
										</div>
                                    </div>
                                </div>
                            </li>
							<li class="accordion block"> 
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">4. Can I get revisions if I'm not satisfied with the solution? <div class="icon fa fa-angle-down"></div></div>
                                  <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>Yes you can get revisions if you are not satisfied with our work. If you are not happy with the final product then you can ask for changes as many times as you need within a month.</p>
											</div>
                                    </div>
                                  </div>
                            </li>
						 
                  	</ul>
					
				</div>
			
				<div class="column col-lg-6 col-md-6 col-sm-12">
					 
					<ul class="accordion-box">
					       <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">5. How do I know my assignment is original and free of plagiarism?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>We take pride in delivering unique assignments that are original and plagiarism-free. For your surety and peace of mind, we can provide a plagiarism report along with the assignment.</p>
										</div>
                                    </div>
                                </div>
                            </li>
							<li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">6. Can I get help with group assignments? <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <p>Yes, we also assist with group assignments. Our only requirement is that all the group members have to be aware and agree to collaborate. We also have an ongoing offer where you can get 1 group project free of cost! All you have to do is refer us to four friends.</p>
										</div>
                                    </div>
                                </div>
                            </li>
							<li class="accordion block">
                                <div class="acc-btn bg-white border" style="font-weight:500; font-size: 20px;; color:black">7. What if my assignment involves complex mathematical modeling or simulations? <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>Our experts are well-equipped to handle complex mathematical modeling and simulations. All you have to do is submit your assignment with the necessary details, and we'll match you with one of our experts that specializes in your field.</p>
										</div>
                                    </div>
                                </div>
                            </li>
						
					 
						 
					
					</ul>
					
				</div>
				 
				 
			     </div>
				   <div class="title-box text-center">
				   <a a href ="https://www.assignnmentinneed.com/faqs/maths-assignment-faqs" style="background: #37AFE1;  color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >View More FAQs</a>
				   </div> 

				</div> 
				 
 			</div>
			  
		</div>
		 
   </section> 

	   
@endsection