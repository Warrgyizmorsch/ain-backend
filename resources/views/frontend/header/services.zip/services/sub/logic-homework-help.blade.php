   
@extends('frontend-layouts.app')

@section('content')

<style>
	@media screen and (max-width: 768px) {
		#testimonial-video {
			width: 100%; /* Set the width to 100% when div goes to col-12 */
			height: auto; /* Set the height to auto to maintain aspect ratio */
		}
		
	}

	.testimonial-block-four .video {
		margin-top: 15px;
	}

	.testimonial-block-four .video video {
		width: 80%;
		height: 250px;
		border-radius: 15px;
	}
</style>
<style>
	.featured-section .feature-block:nth-child(2n + 1) {
		margin-top: 0px;
	}

	.text {
		color: #0c0d24;
		line-height: 1.8em;
		font-size: 16px;
	}

	.text-black {
		color: black;

	}

	.banner-section-three .content-column .inner-column {
		padding-top: 5px;
	}
</style>
<style>
	.iti {
		position: relative;
		display: inline-block;
		width: 100%;
	}
</style>

<style>
	.header-section {
		background: #162561;
		background-image: radial-gradient(
			circle at 20% 100%,
			rgba(184, 184, 184, 0.1) 0%,
			rgba(184, 184, 184, 0.1) 33%,
			rgba(96, 96, 96, 0.1) 33%,
			rgba(96, 96, 96, 0.1) 66%,
			rgba(7, 7, 7, 0.1) 66%,
			rgba(7, 7, 7, 0.1) 99%
			),
			linear-gradient(40deg, #040a22, #162561, #202e64, #6f7aa6);
		background-repeat: no-repeat;
		background-size: cover;	
	}

	h1 {
	    
		color: white
	}

	p {
		position: relative;
		line-height: 1.8em;
		font-size: large;
		color: black;
		text-align: justify;
	}

	.place-order {
		background: #d7f0fd;
		color: black;
		padding: 10px 20px;
		border-radius: 5%;
		margin: 10px;
	}

	.place-now {
		background: #77bfe5;
		color: black;
		padding: 20px 80px;
		border-radius: 3%;
		margin: 10px;
		font-weight: 500;
		font-size: 20px;
	}

	.place-order:hover {
		background: #7e89dd;
		color: white;

	}

	.place-now:hover {
		box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
		color: white;
		transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out;
		/* Smooth transition */

	}

	.order-now {
		font-size: 25px;
		font-weight: 500;
		color: black;
	}

	/*.offer-badge {*/
	/*	position: absolute;*/
	/*	top: -65px;*/
	/*	right: -30px;*/
	/*	color: white;*/
	/*	font-weight: bold;*/
	/*	border-radius: 10%;*/
	/*	font-size: 17px;*/
	/*	z-index: 0;*/
	/*}*/

	.banner-stats-title {
		font-size: 30px;
		font-weight: 600;
		color: black;
	}

	.banner-stats-container {
		display: flex;
		justify-content: space-between;
		text-align: center;
	}

	.banner-stat {
		flex: 1;
		padding: 0 10px;
		/* Adjust the space between elements */
	}

	.banner-stats-text {
		font-size: 1em;
		margin-top: 5px;
	}

	ul {
		font-size: 17px;
		color: black;
	}

	h3 {
		font-size: 21px;
		font-weight: 500;
		color: black;
	}

	@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

		.image-container {
			width: 50%;
		}

		.text-content {
			width: 50%;  
			margin-left: 40px;
		}

		.text-content h2 {
			font-size: 2rem;
		}
	}

	.current_offer {
		font-weight: bold;
		font-size: 35px;
	}

	.offer-container {
		background: rgb(221, 245, 245);
		background: -moz-linear-gradient(275deg, rgba(221, 245, 245, 1) 0%, rgba(175, 214, 232, 0.23012955182072825) 10%, rgba(155, 205, 231, 0.43461134453781514) 68%, rgba(110, 186, 231, 1) 100%);
		background: -webkit-linear-gradient(275deg, rgba(221, 245, 245, 1) 0%, rgba(175, 214, 232, 0.23012955182072825) 10%, rgba(155, 205, 231, 0.43461134453781514) 68%, rgba(110, 186, 231, 1) 100%);
		background: linear-gradient(275deg, rgba(221, 245, 245, 1) 0%, rgba(175, 214, 232, 0.23012955182072825) 10%, rgba(155, 205, 231, 0.43461134453781514) 68%, rgba(110, 186, 231, 1) 100%);
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5", endColorstr="#6ebae7", GradientType=1);
		background-color: white;
		border-radius:
			5px;
		box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08);
		padding: 20px;
	}

	@media (min-width: 1200px) {
		.container {
			max-width: 1199px;
		}
	}

	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}

	.offer-badge-offer:hover {

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
		transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out;
		/* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
		padding: 0px 0px 0px;
	}

	.feature-section-three .blocks-column .feature-block-five:nth-child(2n + 0) {
		transform: translateY(0px);
	}

	.news-section-two .blocks-column .column:nth-child(1) .news-block-four {
		margin-top: 0;

	}

	.bg-gradient-1.rounded-box {
		padding: 20px;
		background-color: white;
		border-radius: 20px;
	}

	/* Style the list items with more space and consistent padding */
	.custom-list li {
		margin-bottom: 15px;
		/* Increase space between list items */
		padding-left: 10px;
		color: white
	}

	/* Style the image with rounded corners */
	.rounded-image {
		border-radius: 20px;
	}

	.subject-container {
		background-color: #fff;
		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;

		padding: 20px;
		border-radius: 10px;
	}

	.subject-image {
		border-radius: 50%;
		max-width: 100%;
		height: auto;
	}

	.subject-list-box {
		background: rgb(0, 127, 193);
		background: linear-gradient(281deg, rgba(0, 127, 193, 0.5718662464985995) 11%, rgba(71, 199, 204, 1) 60%, rgba(0, 127, 193, 1) 100%);
		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
		padding: 20px;
		border-radius: 15px;

	}







	.subject-list {
		list-style: none;
		padding-left: 0;
	}

	.subject-list li {
		margin-bottom: 10px;
		font-size: 16px;
		color: white;
	}

	.subject-list li i {
		color: white;
		margin-right: 8px;
	}
</style>

<style>
	.topspaceheader {
		padding-top: 10px; 
	}
	.topspaceheader2 {
		padding-top: 50px; 
	}

	@media (min-width: 992px) { 
		.topspaceheader {
			padding-top: 70px; 
		}
		.topspaceheader2 {
			padding-top: 70px; 
		}
	}
</style>
	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">
					<!-- <li><a href="/">Home</a></li>
					<li>Math Assignment</li> -->
				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center">Get Expert Logic Homework Help | Logic Assignment Help for Students
						</h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Rating</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
			@include('formsection')
			</section>


		<section class="news-section-two py-3 mt-3">
		<div class="auto-container">
			<div class="row clearfix">
				<div class="col-md-12 col-md-offset-2">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center my-4">How do Our Logic Homework and Assignment Help Service Work?</h2>
					<!-- <p class="textCommon text-center">How Our Quality Assignment Writing Services Work  in Assignment ?</p> -->
				</div>
				<div class="blocks-column col-lg-12 col-md-12 col-sm-12 mt-2">
					<div class="inner-column">
						<div class="row clearfix p-2">
							<div class="column col-lg-4 col-md-4 col-sm-12 ">
								<div class="news-block-four mt-0">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/shopping-list.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Submit Your Order</a></h3>
										<div class="text">Fill in the 'order now' form, mention your basic information and specific requirements that you want us to meet.</div>
										
									</div>
								</div>
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="150ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 150ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/secure-payment.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Make Secure Payment</a></h3>
										<div class="text">Pay an affordable price for the assignment help provided to you via our secure payment gateway that is fully protected from privacy infringements.</div>
									</div>
								</div>
								
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/sharing.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Receive Your Paper</a></h3>
										<div class="text">
											Get a high-quality assignment writing services by our expert writers within the given deadline and score better than your expectations.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/Offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Our Writer -->
 @if($data['expert']->isEmpty())
    
@else
    <!-- Case: Experts are available -->
    <section class="testimonial-section-three py-0">
        <div class="color-layer"></div>
        <div class="auto-container">
            <div class="sec-title">
                <div class="section-color-layer"></div>
                <h2 style="font-weight:500; font-size: 30px; color:black">
                Our Writer For  Logic Homework and   Assignment help
                </h2>
            </div>
            <div class="testimonial-carousel-three owl-carousel owl-theme">
                @foreach($data['expert'] as $expert)
                    <!-- Testimonial Block Three -->
                    <div class="testimonial-block-three">
                        <div class="inner-box">
                            <div class="image-outer">
                                <div class="image">
                                    <img src="{{$expert->image}}" alt="Expert Image" />
                                </div>
                                <div class="quote flaticon-left-quote"></div>
                            </div>
                            <h6>{{$expert->name}}</h6>
                            <div class="designation" style="
                                color: blue !important;
                                margin: 0 auto;
                                text-align: center;
                                width: auto;
                                padding: 5px 15px;
                                border-radius: 20px;
                                font-size: 20px;
                                font-weight: 700;">
                                {{$expert->service}}
                            </div>
                            <div class="text" style="text-align: justify; margin-top: 10px;">
                                <span class="short-content">
                                    {{ Str::limit($expert->content, 150) }}
                                </span>
                                <span class="full-content" style="display: none;">
                                    {{$expert->content}}
                                </span>
                                <button class="btn-toggle" onclick="toggleContent(this)" style="
                                    margin-top: 5px;
                                    border: none;
                                    background-color: transparent;
                                    color: #007BFF;
                                    cursor: pointer;">
                                    ...
                                </button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="lower-text">Click the button for slide</div>
        </div>
    </section>
@endif

	<script>
    function toggleContent(button) {
        const textContainer = button.parentElement;
        const shortContent = textContainer.querySelector('.short-content');
        const fullContent = textContainer.querySelector('.full-content');

        if (shortContent.style.display === 'none') {
            shortContent.style.display = '';
            fullContent.style.display = 'none';
            button.textContent = '...';
        } else {
            shortContent.style.display = 'none';
            fullContent.style.display = '';
            button.textContent = 'Less';
        }
    }
</script>

    <!-- Online Logic Homework Help Services For Students -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class=" my-4">Online Logic Homework and Assignment Help For Students</h2>
                             <p>At Assignment In Need, we are committed to providing top-notch logic homework help to students worldwide, including those in Chelmsford, Chester, London, and many more places. Our dedicated team of experts is here to assist you with your logic assignments, ensuring academic excellence and helping you meet deadlines with ease. Let us guide you towards success with tailored support that meets your needs and exceeds your expectations.
                             </p>
                            </div>
					</div>
				</div>
			</div>
		</div>
	</section>
       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our Logic Homework and Assignment Help today and enjoy a special discount!</h2>
							<p>Get help with your assignments easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>

    <!-- Professional Logic Essay Assistance for Academic Excellence -->
        <section>
            <div class="auto-container">
                <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Professional Logic Essay Assistance for Academic Excellence
                            </h2>
                             <p>We offer professional logic essay assistance that is designed to help students achieve academic excellence. For more advanced support, our logic dissertation help ensure expert guidance on complex logic problems, enabling our writers to produce high-quality essays that meet university standards.
                             </p>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </section>

        <!-- Top Reasons to Get Expert Help with Your Logic Homework -->
         <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Top Reasons to Get Expert Help with Your Logic Homework</h2>
                                   <p>Seeking expert logic essay help with your logic homework offers many benefits, including improved grades and reduced stress. For more complex assignments, our logic dissertation help is designed to assist with critical thinking, problem-solving, and a deep understanding of theories. Our team of experts is equipped with the knowledge and skills to handle even the most challenging tasks, helping you save time and focus on other important academic activities.
                                   </p>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
         </section>


         <!-- Affordable and Tailored International Law Assignment Help -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Cost-Effective Logic Assignment Help Customized to Your Requirements</h2>
                                <p>At Assignment In Need, we understand that students have tight budgets. That's why we offer cost-effective <a href="https://www.assignnmentinneed.com/philosophy-assignment-writing-help"><b>philosophy assignment help</b></a>  tailored to your specific needs. We provide quality assistance at affordable prices, ensuring that all students can access the logic essay help they need without breaking the bank. No matter your budget, we have a solution that works for you.
                                </p>
                                </div>

                        </div>
                    </div>
                </div>
            </div>
          </section>


          <!-- Why Is Assignment in Need Is the Best Choice for Logic Homework Support? -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Is Assignment in Need Is the Best Choice for Logic Homework Support?</h2>
                                  <p>Assignment In Need stands out as the best choice for logic homework support due to our team of experienced professionals, quick turnaround times, and commitment to quality. For more in-depth assistance, consider our logic research paper help. We focus on providing personalized assistance, ensuring that <a href="https://www.assignnmentinneed.com/assignment-writing-help-services"><b>assignment writing help</b></a> is addressed according to your unique requirements.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>


          <!-- Advantages of Utilizing Our Logic Homework Help Services -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Advantages of Utilizing Our Logic Homework Help Services </h2>
                                  <p>Using our <a href="https://www.assignnmentinneed.com/homework-writing-help-services"><b>homework help</b></a>  services offers a range of advantages. You get to work with skilled experts who know the subject inside out, helping you grasp complex concepts more easily. Additionally, our services are quick, affordable, and confidential, allowing you to submit your homework on time without compromising on quality.</p>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>

          <!--Why Is Logic Homework Assistance Essential for Today's Learners? -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Is Logic Homework Assistance Essential for Today's Learners?</h2>
                                   <p>In today's fast-paced academic environment, logic homework assistance is crucial for students. For more complex tasks, our logic research paper help provide the guidance needed to complete assignments accurately and efficiently. Logic assignments often involve abstract reasoning, and many students struggle with the complexity of the subject.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>


          <!-- How do Students Benefit from Our Logic Homework Writing Services? -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">How do Students Benefit from Our Logic Homework Writing Services?</h2>
                                 <p>Students benefit from our logic homework writing services in numerous ways. For more advanced support, our logic dissertation helps provide professional expertise, timely delivery, and high-quality work that aligns with academic standards. Our services help students understand logic better, improve their grades, and reduce the stress of completing assignments.
                                 </p>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>


          

      <!-- new section -->

	 <section class="py-4" style="background-color:#BFECFF;"  >
	            <div class="auto-container">
                    <div class="row clearfix">

			<!-- Content Column -->
			  <div class="content-column col-lg-6 col-md-12 col-sm-12">
				 <div class="inner-column">
					<h2 class="py-3" style="font-weight:500; font-size: 30px; color:black">Assignment in Need help Logic Homework and Assignment Help for Students in the World  </h2>
					  <div class="text">
					   <p>Solve complex problems with our Logic homework help services at Assignment in Need. Trusted by students in the UK, Canada, UAE, Australia, Malaysia, Spain, and beyond, we offer step-by-step guidance on arguments, propositional logic, and symbolic reasoning. With 9/10 students reporting better grades, our team ensures your assignment stands out.
                       </p>
                    </div>
					 
			          <a href="/upload-your-assignment"> <button style="background: #37AFE1;  color:black; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >Order Now</button> </a>	 
			     </div>
			 </div>

			<!-- Image Column -->
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">
					 <div class="image titlt"  style="mix-blend-mode: multiply;">
						<img src="images2\resource\unnamed (5).png  " alt="">  
					</div>        
				</div>
			</div>

		</div>
	</div>
            </section>

            <!-- end new section -->
 
	    <!-- FAQs Question  section for Expert Assignment Writing Help -->
 
	        
		<section class="faq-section bg-light">
	    	<div class="auto-container">
			<div class="row ">
				<div class="titel-column col-lg-12 col-md-12 col-sm-12">  
				    <div class="title-box text-center">
						<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4"><b>Frequently Asked Questions For Logic Homework and Assignment Help </b></h2> 
					 </div>
					<div class="row"> 
					 		 
				<div class="column col-lg-6 col-md-6 col-sm-12 ">
					 
					<ul class="accordion-box ">
					       <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">1. What Is Logic Homework Help?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <p>Logic homework help provides expert assistance with logic assignments, including problem-solving and essay writing.
                                           </p>
										
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">2. Why Should I Seek Help with My Logic Homework?

                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>You should seek logic assignment help to improve your understanding, save time, and achieve better grades.
                                          </p>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            
                  	</ul>
					
				</div>
			
				<div class="column col-lg-6 col-md-6 col-sm-12">
					 
					<ul class="accordion-box">
                    <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">3. How Do I Get Logic Homework Help from Your Service?
                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Simply visit our website, submit your assignment details, and our experts will get started.
                                          are ready to dive into these areas with you.   </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">4. Is Your Logic Homework Help Affordable?
                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Yes, our services are affordable and cater to various student budgets.
                                          </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">5. What Topics Do Your Experts Cover in Logic Homework Help?
                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>We cover topics like logical reasoning, set theory, symbolic logic, and more.
                                          </p>
										</div>
                                    </div>
                                </div>
                            </li>
					</ul>
					
				</div>
				 
				 
			     </div>
				   <div class="title-box text-center">
				   <button style="background: #37AFE1;  color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >View More FAQs</button>
				   </div> 

				</div> 
				 
 			</div>
			  
		</div>
		 
   </section> 

	   
@endsection