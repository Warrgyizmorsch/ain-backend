   
@extends('frontend-layouts.app')

@section('content')


<style>
		.text {
			color: #0c0d24;
			line-height: 1.8em;
			font-size: 16px;
		}
		.text-black{
			color: black;
			
		}
		.banner-section-three .content-column .inner-column {
			padding-top: 5px;
		}
		
	</style>
	<style>
		.iti {
			position: relative;
			display: inline-block;
			width: 100%;
		}
	</style>

	<style>
		.header-section 
		{
			background: rgb(255,255,255);
			background: linear-gradient(170deg, rgba(255,255,255,1) 6%, rgba(135,166,219,0.4009978991596639) 72%, rgba(135,166,219,0.5690651260504201) 91%, rgba(126,137,221,0.865983893557423) 100%);
		}

		h1 {
			font-size: 35px;
			font-weight: 600;
			color: black
			}

		p {
			position: relative;
			line-height: 1.8em;
			font-size: large;
			color:black;
			text-align: justify;
		}
		.place-order 
		{
			background:#d7f0fd; 
			color:black;
			padding: 10px 20px;
			border-radius: 5%;
			margin: 10px;
		}
		.place-now
		{
			background:#77bfe5; 
			color:black;
			padding: 20px 80px;
			border-radius: 3%;
			margin: 10px;
			font-weight: 500;
			font-size: 20px;
		}
		.place-order:hover
		{
			background:#7e89dd;
			color:white ;

		}
		.place-now:hover
		{
			box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;			
			color: white;
			transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */

		}
		.order-now		
		{
			font-size: 25px;
			font-weight: 500;	
			color: black;
		}

		.offer-badge {
		    position: absolute;
			top: -65px;
			right: -30px;
			color: white;
			font-weight: bold;
			border-radius: 10%;
			font-size: 17px;
			z-index: 0;
		}
		.banner-stats-title
		{
			font-size: 30px;
			font-weight: 600;
			color: black;
		}
		.banner-stats-container {
			display: flex;
			justify-content: space-between;
			text-align: center;
		}

		.banner-stat {
			flex: 1;
			padding: 0 10px; /* Adjust the space between elements */
		}

		.banner-stats-text {
			font-size: 1em;
			margin-top: 5px;
		}
		
		ul 
		{
			font-size: 17px;
			color: black;
		}

		h3 
		{
			font-size: 21px;
			font-weight: 500;
			color: black;
		}

		@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

			.image-container {
				width: 50%;
			}

			.text-content {
				width: 50%;
				margin-left: 40px;
			}

			.text-content h2 {
				font-size: 2rem;
			}
		}

		.current_offer
		{
			font-weight: bold;
			font-size: 35px;
		}

		.offer-container
		{
			background: rgb(221,245,245);
			background: -moz-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: -webkit-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5",endColorstr="#6ebae7",GradientType=1);
						background-color: white; 
			border-radius: 
			5px; 
			box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); 
			padding: 20px;
		}

		@media (min-width: 1200px) {
    .container {
        max-width: 1199px;
    }
}
	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}
	.offer-badge-offer:hover{

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
				transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
    padding: 0px 0px 0px;
}
      /* Assignment Writing */
	</style>
	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">
					<!-- <li><a href="/">Home</a></li>
					<li>Math Assignment</li> -->
				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center">Reliable Managerial Accounting Assignment Help | Managerial Accounting Homework Help Services
						</h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Rating</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
				
			@include('formsection')
			</section>


		<section class="news-section-two py-3 mt-3">
		<div class="auto-container">
			<div class="row clearfix">
				<div class="col-md-12 col-md-offset-2">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center my-4">How do Our Managerial Accounting Assignment Help Service Work?</h2>
					<!-- <p class="textCommon text-center">How Our Quality Assignment Writing Services Work  in Assignment ?</p> -->
				</div>
				<div class="blocks-column col-lg-12 col-md-12 col-sm-12 mt-2">
					<div class="inner-column">
						<div class="row clearfix p-2">
							<div class="column col-lg-4 col-md-4 col-sm-12 ">
								<div class="news-block-four mt-0">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/shopping-list.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Submit Your Order</a></h3>
										<div class="text">Fill in the 'order now' form, mention your basic information and specific requirements that you want us to meet.</div>
										
									</div>
								</div>
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="150ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 150ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/secure-payment.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Make Secure Payment</a></h3>
										<div class="text">Pay an affordable price for the assignment help provided to you via our secure payment gateway that is fully protected from privacy infringements.</div>
									</div>
								</div>
								
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/sharing.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Receive Your Paper</a></h3>
										<div class="text">
											Get a high-quality assignment writing services by our expert writers within the given deadline and score better than your expectations.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/Offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Our Writer -->
 @if($data['expert']->isEmpty())
    
@else
    <!-- Case: Experts are available -->
    <section class="testimonial-section-three py-0">
        <div class="color-layer"></div>
        <div class="auto-container">
            <div class="sec-title">
                <div class="section-color-layer"></div>
                <h2 style="font-weight:500; font-size: 30px; color:black">
                Our Writer For  Managerial Accounting  Assignment help
                </h2>
            </div>
            <div class="testimonial-carousel-three owl-carousel owl-theme">
                @foreach($data['expert'] as $expert)
                    <!-- Testimonial Block Three -->
                    <div class="testimonial-block-three">
                        <div class="inner-box">
                            <div class="image-outer">
                                <div class="image">
                                    <img src="{{$expert->image}}" alt="Expert Image" />
                                </div>
                                <div class="quote flaticon-left-quote"></div>
                            </div>
                            <h6>{{$expert->name}}</h6>
                            <div class="designation" style="
                                color: blue !important;
                                margin: 0 auto;
                                text-align: center;
                                width: auto;
                                padding: 5px 15px;
                                border-radius: 20px;
                                font-size: 20px;
                                font-weight: 700;">
                                {{$expert->service}}
                            </div>
                            <div class="text" style="text-align: justify; margin-top: 10px;">
                                <span class="short-content">
                                    {{ Str::limit($expert->content, 150) }}
                                </span>
                                <span class="full-content" style="display: none;">
                                    {{$expert->content}}
                                </span>
                                <button class="btn-toggle" onclick="toggleContent(this)" style="
                                    margin-top: 5px;
                                    border: none;
                                    background-color: transparent;
                                    color: #007BFF;
                                    cursor: pointer;">
                                    ...
                                </button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="lower-text">Click the button for slide</div>
        </div>
    </section>
@endif

	<script>
    function toggleContent(button) {
        const textContainer = button.parentElement;
        const shortContent = textContainer.querySelector('.short-content');
        const fullContent = textContainer.querySelector('.full-content');

        if (shortContent.style.display === 'none') {
            shortContent.style.display = '';
            fullContent.style.display = 'none';
            button.textContent = '...';
        } else {
            shortContent.style.display = 'none';
            fullContent.style.display = '';
            button.textContent = 'Less';
        }
    }
</script>

    <!-- Online Managerial Accounting Assignment Writing Help Services -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class=" my-4">Online Managerial Accounting Assignment Writing Help Services</h2>
                              <p>At Assignment In Need, we provide expert managerial accounting assignment help to students. Our services are designed to support students with complex accounting concepts and ensure that they excel in their academic journey. we are here to assist you.</p>
                            </div>
					</div>
				</div>
			</div>
		</div>
	</section>
       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our Managerial Accounting Assignment Help today and enjoy a special discount!</h2>
							<p>Get help with your assignments easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>

    <!-- Expert Managerial Accounting Assignment Help for Students -->
        <section>
            <div class="auto-container">
                <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Expert Managerial Accounting Assignment Help for Students</h2>
                            <p>We offer specialized <a href="https://www.assignnmentinneed.com/accounting-assignment-writing-help"><b>accounting assignment help</b></a> for students. Our team of qualified professionals ensures that you receive accurate solutions tailored to your specific academic requirements.</p>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </section>

        <!-- Affordable Managerial Accounting Assignment Help – Boost Your Grades -->
         <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Affordable Managerial Accounting Assignment Help - Boost Your Grades</h2>
                                   <p>At Assignment In Need, we understand the financial constraints that students often face. That's why our <a href="https://www.assignnmentinneed.com/assignment-writing-help-services"><b>assignment writing help</b></a> is affordably priced to suit every student's budget.

                                   </p>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
         </section>


         <!-- Top-Rated Managerial Accounting Assignment Help from Professionals -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Top-Rated Managerial Accounting Assignment Help from Professionals</h2>
                                  <p>Our team consists of highly skilled professionals with years of experience in the field of Managerial Accounting. For more personalized support, consider our management accounting homework help. We are proud of the positive feedback from our clients and the excellent academic results they achieve.
                                  </p>
                                </div>

                        </div>
                    </div>
                </div>
            </div>
          </section>


          <!-- Get High-Quality Managerial Accounting Help for Your Assignments -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Get High-Quality Managerial Accounting Help for Your Assignments</h2>
                                <p>Quality is our top priority at Assignment In Need. We ensure that every Managerial Accounting assignment we deliver meets high academic standards. For additional support, our management accounting homework help provides precise, detailed, and well-researched solutions that help you grasp complex topics and score high grades on your assignments.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>


          <!-- Managerial Accounting Assignment Assistance – Improve Your Understanding -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Managerial Accounting Assignment Assistance - Improve Your Understanding  </h2>
                                <p>We provide more than just assignment solutions. Our managerial accounting homework assistance is designed to help you understand key concepts, including cost analysis, budgeting, and decision-making processes.
                                </p>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>

          <!--Reliable Managerial Accounting Help for Complex Assignments -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Reliable Managerial Accounting Help for Complex Assignments</h2>
                                <p>Managerial Accounting can be complex, and we specialize in providing reliable help for even the most challenging assignments. For additional assistance, our management accounting homework help covers everything from variance analysis to cost management. Our experts are always ready to guide you through the toughest topics, ensuring your success.</p>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>

		  <section class="admission-section py-0">
            
            <div class="auto-container">
                <div class="row clearfix">
                    
                    
                    <!-- Content Column -->
                    <div class="content-column col-lg-12 col-md-12 col-sm-12 bg-light">
                        <div class="inner-column">
                            <div class="sec-title-three">
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center py-4">Benefits of Our Managerial Assignment Help For Students</h2>
                            </div>
							<div class="row clearfix">
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:50px" class="fa fa-clock-o"></span></div>
                                        <h3>Expert Professionals at Your Service</h3>
										Get assistance from highly qualified experts to deliver top-notch solutions.
                                    </div>
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="far fa-edit"></span></div>
                                        <h3>Customized Help Tailored to Your Needs</h3> 
										Receive personalized support designed specifically to meet your unique requirements.
                                    </div> 
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="fa fa-history "></span></div>
                                        <h3>100% Accurate and Error-Free Work</h3> 
										We ensure complete accuracy with thoroughly checked and error-free assignments.
                                    </div>
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="fa fa-ban"></span></div>
                                        <h3>On-Time Delivery, Every Time</h3>    
										Never miss a deadline with our reliable and punctual assignment delivery.
                                    </div>
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="fa fa-line-chart"></span></div>
                                        <h3>Boost Your Confidence and Skills</h3>
                                        Enhance your knowledge and problem-solving skills with expert guidance.

                                    </div>
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner"><div class="icon"><span style="font-size:45px" class="fas fa-headset"></span></div>
                                        <h3>Affordable Services for Every Student</h3>
										Get high-quality services at prices that fit every student's budget.
									  </div>
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="fas fa-chalkboard-teacher"></span></div>
                                        <h3>Unlimited Revisions for Complete Satisfaction</h3>
										We offer free revisions until your assignment meets your expectations perfectly.
                                    </div>
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="fa fa-support"></span></div>
                                        <h3>Improve Your Grades Effortlessly</h3>
										Achieve better grades with professionally crafted assignments designed for success.
									    </div>
                                </div>
								<div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="fa fa-adjust"></span></div>
                                         <h3>24/7 Support Whenever You Need It</h3> 
										 Our team is available round the clock to assist you with your queries and concerns.
										</div>
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="fas fa-user-alt"></span></div>
                                           <h3>Guaranteed Privacy and Confidentiality</h3>
										   Your personal and academic information is kept completely safe and secure.
										
										</div>
                                </div>
                            </div>
							  
                             
                            

                            
                        </div>
						 <div class="title-box text-center py-4">
				             <button style="background: #37AFE1;  color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " > <a class="text-white" href="https://www.assignnmentinneed.com/benefits-of-assignments">View More Benefits</a></button>
				          </div> 
                    </div>
					 
                </div>
            </div>
        </section> 
          <!-- Expert Help with Managerial Accounting Assignments – Achieve Academic Success -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Expert Help with Managerial Accounting Assignments - Achieve Academic Success  </h2>
                                  <p>We are committed to helping students achieve academic success by providing expert help with managerial accounting homework. Our team's expertise ensures that your assignments are completed efficiently and effectively, giving you the best chance of achieving top grades.
                                  </p>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>

          <!-- Comprehensive Managerial Accounting Assignment Help for All Topics -->
           <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4" >Comprehensive Managerial Accounting Assignment Help for All Topics</h2>
                                <p>No matter the topic, our team offers comprehensive managerial accounting assignment help. We cover a wide range of topics such as cost behaviour, budgeting, financial planning, and more. Whatever your requirements are, we ensure that our solutions are tailored to meet your needs and exceed your expectations.
                                </p>      
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           </section>

           <!-- Timely and Accurate Managerial Accounting Homework Help -->
            <section>
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="title-column col-lg-12 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <div class="title-box">
                                    <div class="section-color-layer"></div>
                                    <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Timely and Accurate Managerial Accounting Homework Help</h2>
                                    <p>We understand the importance of deadlines in academia, which is why we prioritize timely delivery for all assignments. You can rely on us for accurate and punctual managerial accounting homework help. Our experts work diligently to ensure that you receive your completed work on time.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
          
            <!-- Master Managerial Accounting with Our Expert Assignment Help -->
             <section>
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="title-column col-lg-12 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <div class="title-box">
                                    <div class="section-color-layer"></div>
                                    <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Master Managerial Accounting with Our Expert Assignment Help</h2>
                                    <p>Our goal is to help you master <a href="https://www.assignnmentinneed.com/uk/accounting-assignment-writing-help-online"><b>accounting assignment help</b></a>. With our expert managerial accounting homework help, you'll gain a solid understanding of the subject and be well-prepared for exams. We focus on providing clear explanations, detailed solutions, and ongoing support to ensure your academic success.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             </section>
      <!-- new section -->

	 <section class="py-4" style="background-color:#BFECFF;"  >
	            <div class="auto-container">
                    <div class="row clearfix">

			<!-- Content Column -->
			  <div class="content-column col-lg-6 col-md-12 col-sm-12">
				 <div class="inner-column">
					<h2 class="py-3" style="font-weight:500; font-size: 30px; color:black">Assignment in Need Help With Managerial Accounting Assignment Help for Students Across the Global
                    </h2>
					  <div class="text">
					     <p>Master Managerial Accounting with Assignment in Need. Serving students in the UK, Canada, Malaysia, and more, our 3,000+ PhD experts provide personalized assistance on budgeting, cost analysis, and decision-making models. With a 4.5-star rating and a 98% recurring client base, we guarantee success in your Managerial Accounting assignments.
                         </p>
                    </div>
					 
			          <a href="/upload-your-assignment"> <button style="background: #37AFE1;  color:black; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >Order Now</button> </a>	 
			     </div>
			 </div>

			<!-- Image Column -->
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">
					 <div class="image titlt"  style="mix-blend-mode: multiply;">
						<img src="images2\resource\unnamed (5).png  " alt="">  
					</div>        
				</div>
			</div>

		</div>
	</div>
            </section>

            <!-- end new section -->
 
	    <!-- FAQs Question  section for Expert Assignment Writing Help -->
 
	        
		<section class="faq-section bg-light">
	    	<div class="auto-container">
			<div class="row ">
				<div class="titel-column col-lg-12 col-md-12 col-sm-12">  
				    <div class="title-box text-center">
						<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4"><b>Frequently Asked Questions For Managerial Accounting Assignment Help </b></h2> 
					 </div>
					<div class="row"> 
					 		 
				<div class="column col-lg-6 col-md-6 col-sm-12 ">
					 
					<ul class="accordion-box ">
					       <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">1. What Is Managerial Accounting?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <p>Managerial Accounting provides financial information and analysis for decision-making, covering topics like budgeting and cost analysis.
                                           </p>
										
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">2.Why Should I Seek Help with My Managerial Accounting Assignment?

                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Getting help improves your understanding, and grades, and provides guidance from experts. </p>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            
                  	</ul>
					
				</div>
			
				<div class="column col-lg-6 col-md-6 col-sm-12">
					 
					<ul class="accordion-box">
                    <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">3. What Topics in Managerial Accounting Can You Assist with?
                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>We assist with cost analysis, budgeting, performance evaluation, variance analysis, and more. </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">4.How Can I Get Help with My Managerial Accounting Assignment?
                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Visit our website, fill out the order form with your assignment details, and our experts will assist you. </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">5. Is Your Managerial Accounting Assignment Help Affordable?
                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Yes, our services are affordable and tailored to student budgets while maintaining quality. </p>
										</div>
                                    </div>
                                </div>
                            </li>
					</ul>
					
				</div>
				 
				 
			     </div>
				   <div class="title-box text-center">
				   <button style="background: #37AFE1;  color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >View More FAQs</button>
				   </div> 

				</div> 
				 
 			</div>
			  
		</div>
		 
   </section> 

	   
@endsection