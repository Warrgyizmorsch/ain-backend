@extends('frontend-layouts.app')

@section('content')


<style>
		.text {
			color: #0c0d24;
			line-height: 1.8em;
			font-size: 16px;
		}
		.text-black{
			color: black;
			
		}
		.banner-section-three .content-column .inner-column {
			padding-top: 5px;
		}
		
	</style>
	<style>
		.iti {
			position: relative;
			display: inline-block;
			width: 100%;
		}
	</style>

	<style>
		.header-section 
		{
			background: rgb(255,255,255);
			background: linear-gradient(170deg, rgba(255,255,255,1) 6%, rgba(135,166,219,0.4009978991596639) 72%, rgba(135,166,219,0.5690651260504201) 91%, rgba(126,137,221,0.865983893557423) 100%);
		}

		h1 {
			font-size: 35px;
			font-weight: 600;
			color: black
			}

		p {
			position: relative;
			line-height: 1.8em;
			font-size: large;
			color:black;
			text-align: justify;
		}
		.place-order 
		{
			background:#d7f0fd; 
			color:black;
			padding: 10px 20px;
			border-radius: 5%;
			margin: 10px;
		}
		.place-now
		{
			background:#77bfe5; 
			color:black;
			padding: 20px 80px;
			border-radius: 3%;
			margin: 10px;
			font-weight: 500;
			font-size: 20px;
		}
		.place-order:hover
		{
			background:#7e89dd;
			color:white ;

		}
		.place-now:hover
		{
			box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;			
			color: white;
			transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */

		}
		.order-now		
		{
			font-size: 25px;
			font-weight: 500;	
			color: black;
		}

		.offer-badge {
		    position: absolute;
			top: -65px;
			right: -30px;
			color: white;
			font-weight: bold;
			border-radius: 10%;
			font-size: 17px;
			z-index: 0;
		}
		.banner-stats-title
		{
			font-size: 30px;
			font-weight: 600;
			color: black;
		}
		.banner-stats-container {
			display: flex;
			justify-content: space-between;
			text-align: center;
		}

		.banner-stat {
			flex: 1;
			padding: 0 10px; /* Adjust the space between elements */
		}

		.banner-stats-text {
			font-size: 1em;
			margin-top: 5px;
		}
		
		ul 
		{
			font-size: 17px;
			color: black;
		}

		h3 
		{
			font-size: 21px;
			font-weight: 500;
			color: black;
		}

		@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

			.image-container {
				width: 50%;
			}

			.text-content {
				width: 50%;
				margin-left: 40px;
			}

			.text-content h2 {
				font-size: 2rem;
			}
		}

		.current_offer
		{
			font-weight: bold;
			font-size: 35px;
		}

		.offer-container
		{
			background: rgb(221,245,245);
			background: -moz-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: -webkit-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5",endColorstr="#6ebae7",GradientType=1);
						background-color: white; 
			border-radius: 
			5px; 
			box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); 
			padding: 20px;
		}

		@media (min-width: 1200px) {
    .container {
        max-width: 1199px;
    }
}
	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}
	.offer-badge-offer:hover{

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
				transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
    padding: 0px 0px 0px;
}
      /* newcode */
      
	.subject-container {
		background-color: #fff;
		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;

		padding: 20px;
		border-radius: 10px;
		margin-bottom: 20px;
		 
	}

	.subject-image {
		border-radius: 50%;
		max-width: 100%;
		height: auto;
	}

	.subject-list-box {
		background: rgb(0, 127, 193);
		background: linear-gradient(281deg, rgba(0, 127, 193, 0.5718662464985995) 11%, rgba(71, 199, 204, 1) 60%, rgba(0, 127, 193, 1) 100%);
		/* box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px; */
		padding: 40px;
		border-radius: 15px;

	}

    

	.subject-list {
		list-style: none;
		padding-left: 0;
	}

	.subject-list li {
		margin-bottom: 10px;
		font-size: 16px;
		color: white;
	}

	.subject-list li i {
		color: white;
		margin-right: 8px;
	}

	 /* endnewcode */
      /*Get The Best Law Assignment Help With Industry Experts */
	</style>
  
  <style>
	.popular-subjects-section {
  background-color: #f9f9f9;
  padding: 40px 20px;
}

.popular-subjects-section .container {
  max-width: 1200px;
  margin: 0 auto;
}

/* Heading Styles */
.popular-subjects-section .heading {
  font-size: 2rem;
  font-weight: 700;
  color: #222;
  margin-bottom: 20px;
}

/* Description Styles */
.popular-subjects-section .description {
  font-size: 1.1rem;
  color: #555;
  margin-bottom: 30px;
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;
}

/* Subject List Styling */
.popular-subjects-section .subject-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  list-style: none;
  padding: 0;
  margin: 0;
  gap: 15px;
}

.popular-subjects-section .subject-list li {
  margin: 5px;
  display: inline-block;
  padding: 10px 20px;
  background-color: #007bff;
  color: #fff;
  text-decoration: none;
  border-radius: 30px;
  font-size: 1rem;
  transition: background-color 0.3s ease;
  
}

.popular-subjects-section .subject-list li a {
	text-decoration: none;
	color: #fff;

}

.popular-subjects-section .subject-list li a:hover {
  /* background-color: #0056b3; */
}

/* Button Styling */
.popular-subjects-section .show-more-btn {
  display: inline-block;
  margin-top: 30px;
  padding: 10px 20px;
  font-size: 1rem;
  color: #007bff;
  background-color: #fff;
  border: 2px solid #007bff;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.popular-subjects-section .show-more-btn:hover {
  background-color: #007bff;
  color: #fff;
}
</style>

	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">
				
				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center">Get The Best Online Law Assignment Help | Law Homework Help With Legal Experts
						</h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Rating</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
				
			@include('formsection')
			</section>
			<section class="news-section-two py-3 mt-3">
		<div class="auto-container">
			<div class="row clearfix">
				<div class="col-md-12 col-md-offset-2">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center my-4">How Our Law Assignment and Homework Help Services Work For Students?</h2>
					<!-- <p class="textCommon text-center">How Our Quality Assignment Writing Services Work  in Assignment ?</p> -->
				</div>
				<div class="blocks-column col-lg-12 col-md-12 col-sm-12 mt-2">
					<div class="inner-column">
						<div class="row clearfix p-2">
							<div class="column col-lg-4 col-md-4 col-sm-12 ">
								<div class="news-block-four mt-0">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/shopping-list.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Submit Your Order</a></h3>
										<div class="text">Complete the Order Now form with your details and specific assignment requirements. Provide clear instructions to ensure we meet your expectations perfectly.</div>
										
									</div>
								</div>
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="150ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 150ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/secure-payment.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Make a Secure Payment</a></h3>
										<div class="text">Pay an affordable price through our secure payment gateway, designed to protect your information and ensure complete privacy.</div>
									</div>
								</div>
								
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/sharing.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a> Receive Your Assignment</a></h3>
										<div class="text">
										Get a professionally written assignment before your deadline, crafted to perfection by our expert writers, and achieve the grades you deserve.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/Offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Our Writer -->
 
    <!-- Case: Experts are available -->
    <section class="testimonial-section-three py-0">
        <div class="color-layer"></div>
        <div class="auto-container">
            <div class="sec-title">
                <div class="section-color-layer"></div>
                <h2 style="font-weight:500; font-size: 30px; color:black">
                  Our Writer For Online Geography  Assignment Help Service
                </h2>
            </div>
            <div class="testimonial-carousel-three owl-carousel owl-theme">
                @foreach($data['expert'] as $expert)
                    <!-- Testimonial Block Three -->
                    <div class="testimonial-block-three">
                        <div class="inner-box">
                            <div class="image-outer">
                                <div class="image">
                                    <img src="{{$expert->image}}" alt="Expert Image" />
                                </div>
                                <div class="quote flaticon-left-quote"></div>
                            </div>
                            <h6>{{$expert->name}}</h6>
                            <div class="designation" style="
                                color: blue !important;
                                margin: 0 auto;
                                text-align: center;
                                width: auto;
                                padding: 5px 15px;
                                border-radius: 20px;
                                font-size: 20px;
                                font-weight: 700;">
                                {{$expert->service}} Writing Help
                            </div>
                            <div class="text" style="text-align: justify; margin-top: 10px;">
                                <span class="short-content">
                                    {{ Str::limit($expert->content, 150) }}
                                </span>
                                <span class="full-content" style="display: none;">
                                    {{$expert->content}}
                                </span>
                                <button class="btn-toggle" onclick="toggleContent(this)" style="
                                    margin-top: 5px;
                                    border: none;
                                    background-color: transparent;
                                    color: #007BFF;
                                    cursor: pointer;">
                                    ...
                                </button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="lower-text">Click the button for slide</div>
        </div>
    </section>

	<script>
    function toggleContent(button) {
        const textContainer = button.parentElement;
        const shortContent = textContainer.querySelector('.short-content');
        const fullContent = textContainer.querySelector('.full-content');

        if (shortContent.style.display === 'none') {
            shortContent.style.display = '';
            fullContent.style.display = 'none';
            button.textContent = '...';
        } else {
            shortContent.style.display = 'none';
            fullContent.style.display = '';
            button.textContent = 'Less';
        }
    }
</script>

    <!--Assignment Writing Help In Law -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Online Law Assignment Writing Help Services For Students</h2>
                             <p>It's a no-brainer that even the smartest students struggle with submitting a perfect Law assignment when it comes to court cases, contracts, analyzing legislation, negotiations, and writing memos. It is completely normal to seek law assignment help, considering all the reading and the time you spend in libraries.</p>
							 <p>Law is an extensive field that covers a huge number of areas, this is one of the reasons that makes law assignments online challenging. We at Assignment in Need understand the complexity of these assignments, and that's why we've provided affordable law assignment services including online assistance with essays, law dissertation services, papers, and various law homework help.</p>
                              
                              
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our Law Assignment Writing Services today and enjoy a special discount!</h2>
							<p>Get help with your law assignment writing service easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>

	<section class="popular-subjects-section">
  <div class="container text-center">
    <h2 class="heading">Best Subjects We Cover for Students Law Assignment Help and Law Homework Help</h2>
    <p class="description">
	We cover all areas of law and provide clear, detailed guidance. With 98% of orders arriving on time, you can depend on us for your legal assignments help and homework help


    </p>
    <ul class="subject-list">
      <li><a href="https://www.assignnmentinneed.com/criminal-law-assignment-help">Criminal Law Assignment Help</a></li>
	  <li><a href="https://www.assignnmentinneed.com/civil-law-assignment-help">Civil Law Assignment Help</a></li>
	  <li>Taxation Law Assignment Help</li>
	  <li>Labor Law Assignment Help</li>
	  <li><a href="https://www.assignnmentinneed.com/corporate-law-assignment-help">Corporate Law Assignment Help</a></li>
	  <li>Human Rights Law Assignment Help</li>
    </ul>
    <button class="show-more-btn" id="more-subject">Show More</button>
  </div>
</section>

<script>
  document.getElementById("more-subject").addEventListener("click", function () {
    const subjectList = document.querySelector(".subject-list");
    const showMoreBtn = document.getElementById("more-subject");

    const moreSubjects = [
     
      '<li>Constitutional Law Assignment Help</li>',
      '<li>Intellectual Property Law Assignment Help</li>',
      '<li>International Law Assignment Help</li>',
      '<li>Family Law Assignment Help</li>',
	  '<li>Environmental Law Assignment Help</li>',
      '<li>Contract Law Assignment Help</li>'
    ];

    if (showMoreBtn.textContent === "Show More") {
      subjectList.innerHTML += moreSubjects.join("");
      showMoreBtn.textContent = "Show Less";
    } else {
      const currentSubjects = subjectList.querySelectorAll("li");
      // Remove the extra subjects
      for (let i = currentSubjects.length - 1; i >= 6; i--) {
        currentSubjects[i].remove();
      }
      showMoreBtn.textContent = "Show More";
    }
  });
</script>


	<!--Why Choose Our Law Assignment Services? -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Choose Our Law Assignment Services?</h2>
                            
                       <p>So why choose us? Primarily because for many students, law assignments can be challenging and we at Assignment in Need provide specialized law assignment help with our advanced law assignment writers who have advanced law degrees. Our law assignment writers strive to meet the highest academic standards with each assignment they do, including areas like <a href="https://www.assignnmentinneed.com/assignment-writing-help-services"><b>assignment writing help</b></a> and Law Dissertation Services. Below are a few more reasons why you should choose our law assignment service:</p>
                     <p><b>Top-Quality Law Assignments Tailored to Your Needs: </b> We at Assignment in Need are always here as your trusted business law assignment helper. We promise to deliver top quality law assignments that meet your specific needs and requirements. With our professional writers, you get error-free authentic law assignment services. </p>
                     <p><b>Expert Legal Writers with Extensive Experience: </b> With Assignment in Need you don't have to worry about getting anything less than what you paid for. Our law experts have expertise and deep knowledge in legal subjects which ensures each assignment meets academic standards and your specific needs.</p>
                     <p><b>Timely Delivery and 24/7 Customer Support: </b> Our customer support team is available round-the-clock anytime you need assistance from our law assignment writers. To quickly address any questions or concerns we guarantee timely delivery.</p>
                </div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
    <!--Our Range of Law Assignment Help Services -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Our Range of Law Assignment Help Services</h2>
                           <p>Need law assignment service in different law fields? Check out some of the fields we cater to:</p>
                        <p><b>Criminal Law Assignment Help: </b> If you need help in criminal law assignments, our experts are here to help you understand diverse case studies on behaviors that affect society. Just fill out our online form to get started and our team of experts will help you understand different legal systems. </p>
                        <p><b>Contract Law Assignment Help: </b>Count on us for top-notch help whenever you need contract <a href="https://www.assignnmentinneed.com/uk/law-assignment-writing-help-online"><b>law assignment help</b></a> because running a business means dealing with contracts and our team of law assignment writers ensures you understand contract law inside out, so your business agreements are rock-solid. </p>
                        <p><b>Constitutional Law Assignment Help: </b>Writing about constitutional law is all about diving into topics and building strong arguments. One great way to ace this field is by focusing on specific issues and backing up your points with legislative references. If you are confused about where to start, then our law assignment service experts are here to help. </p>
                        <p><b>International Law Assignment Help: </b>Our international law understands the complexities of the area and can help you in doing international law assignments online that involve multiple countries. Whether it's a big research project or detailed analysis, we at Assignment in Need got your back! </p>
					   
				   

					 <!-- <div class="container"> -->
		<div class="row justify-content-center">
			<div class="col-lg-9">
				<div class="headingstyle-1 mb-5">
					<!-- <h2 style="font-weight:500; font-size: 30px; color:black">
					These are just a few of the areas where you can get our expert's help, some other areas include business law writing assignment as well as:	
				    </h2> -->
				</div>
				 
			</div>
		</div>
		<div class="subject-container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-4 text-center">
					<img src="https://bestclasshelpaustralia.com/assets/lp/images/img4.webp" alt="Happy Woman"
						class="subject-image">
				</div>
				<div class="col-lg-8">
					<div class="subject-list-box">
						<div class="row">
							<div class="col-md-4">
								<ul class="subject-list">
									 
									<li><i class="fas fa-caret-right"></i> Real Estate Law  </li>
									<li><i class="fas fa-caret-right"></i> Taxation Law </li>
									<li><i class="fas fa-caret-right"></i> Health Law </li>
									<li><i class="fas fa-caret-right"></i> Corporate Law  </li>
									<li><i class="fas fa-caret-right"></i> Contract Law  </li>
									<li><i class="fas fa-caret-right"></i> Company Law  </li>
									<li><i class="fas fa-caret-right"></i> Environmental Law  </li>
								</ul>
							</div>
							<div class="col-md-4">
								<ul class="subject-list">
								     
									<li><i class="fas fa-caret-right"></i> Labor Law  </li>
									<li><i class="fas fa-caret-right"></i> Criminal Law   </li>
									<li><i class="fas fa-caret-right"></i> Tort Law  </li>
									<li><i class="fas fa-caret-right"></i> Common Law  </li>
									<li><i class="fas fa-caret-right"></i> Immigration Law  </li>
									<li><i class="fas fa-caret-right"></i> International Law  </li>
									<li><i class="fas fa-caret-right"></i> Administrative Law  </li>

								</ul>
							</div>
							<div class="col-md-4">
								<ul class="subject-list">
								    
									<li><i class="fas fa-caret-right"></i> Commercial Law </li>
									<li><i class="fas fa-caret-right"></i> Employment Law  </li>
									<li><i class="fas fa-caret-right"></i> Civil Law  </li>
									<li><i class="fas fa-caret-right"></i> Criminal Law  </li>
									 <li><i class="fas fa-caret-right"></i> Family Law  </li>
									<li><i class="fas fa-caret-right"></i>  Insurance Law  </li>
									<li><i class="fas fa-caret-right"></i> Intellectual Property Law  </li>
									

								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- </div> -->
                     <!-- endnewcode -->
                    <div></div>
                
                </div>
					</div>
				</div>
			</div>
		</div>
	</section>
   
    <!--How Our Law Assignment Help Works-->



	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">How Law Relates to Other Disciplines and Spheres</h2>
                           
                        <p>Law is the bedrock of justice, government, and society. It governs the interrelation of individuals, organizations, and the state, providing a legal framework to settle disputes and the protection of rights. However, knowledge of the law doesn't stop at the level of texts and case study. It is very intrinsically linked with the rest of the academic worlds and gives a more significant dimension to its application and implications.</p>

                        <h3>History: Understanding Legal System Evolution</h3>
                        <p> <a href="https://www.assignnmentinneed.com/history-assignment-writing-help"><b>History assignment help</b></a> enrich the study of Law by giving context to the evolution of legal systems and the foundations of legal principles. Legal systems have evolved over centuries, influenced by cultural, political, and social changes. By examining historical legal documents, landmark cases, and constitutional developments, students gain a deeper understanding of how modern legal systems were shaped. History is helpful to students in that it helps them understand the social inputs that led to the formulation of law and changes in legal thinking throughout history.</p>
                        <h3>Sociology: Understanding the Social Dimensions of Law</h3>
                        <p>In law and society, the <a href="https://www.assignnmentinneed.com/sociology-assignment-writing-help"><b>sociology assignment help</b></a> discusses the relationship between the law and how societal behavior shapes and is shaped by legal systems. It further argues on the position of law in regulating social order with issues of inequality, discrimination, and issues of justice. Sociology explores the ways in which law affects different groups within society, including questions related to race, gender, and class, and how laws can either enforce or abolish social norms. Understanding the intersection of law and sociology helps students appreciate the real-world implications of legal decisions on diverse communities.</p>
                        	</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="admission-section">
            
            <div class="auto-container">
                <div class="row clearfix">
                    
                    
                    <!-- Content Column -->
                    <div class="content-column col-lg-12 col-md-12 col-sm-12 bg-light">
                        <div class="inner-column">
                            <div class="sec-title-three">
                                <h2 class ="py-4 text-center"style="font-weight:500; font-size: 30px;; color:black">Benefits of Our Geography Assignment Writing Help For Students</h2>
                            </div>
                            <div class="row clearfix ">
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:50px" class="fa fa-clock-o"></span></div>
                                        <h3>Plagiarism-Free Assignments</h3>
										Every assignment we deliver undergoes thorough plagiarism checks. You'll receive a unique paper crafted by our experts. We respect other authors' work and ensure proper citations if we include external sources
                                    </div>
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="far fa-edit"></span></div>
                                        <h3>Affordable Pricing Plans</h3>
                                        Designed with students in mind Our prices are affordable so that you can Avoid costly services and opt for high-quality assignments at the best prices.
                                    </div>
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="fas fa-headset"></span></div>
                                        <h3>Confidentiality and Security</h3>
										We ensure strict confidentiality and use secure systems to safeguard your information throughout our services because your privacy is our priority.
                                    </div>
                                </div>
                                <div class="feature-column col-lg-6 col-md-6 col-sm-12 mb-2">
                                    <div class="feature-inner">
                                        <div class="icon"><span style="font-size:45px" class="fa fa-ban"></span></div>
                                        <h3>Revisions Until Your Law Assignment Is Perfect</h3>    
                                        We offer unlimited revisions to ensure your law assignment meets your expectations perfectly, leaving no room for errors or dissatisfaction.
                                    </div>
                                </div>
                           
                            </div>
                       </div>

					   <div class="title-box text-center py-4">
						<button  style="background: #37AFE1; color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;">
						<a class="text-white" href="https://www.assignnmentinneed.com/benefits-of-assignments">View More Benefits</a></button>
					</div>
                    </div>
                    
                </div>
            </div>
        </section>


	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">How Our Law Assignment Experts Help You Achieve Top Grades</h2>
                              <p>All our experts clarify legal ideas and provide well-researched, highly organized work consistent with your academic level. When you order <a href="https://www.assignnmentinneed.com/homework-writing-help-services"><b>law homework help</b></a> from us, you can complete your homework assignments and submit them for the best grades.</p>    
                           	</div>
					</div>
				</div>
			</div>
		</div>
	</section>


		<section class=" py-0">
			<div class="auto-container ">
				<div class="row clearfix">
					<div class="title-column col-lg-12 col-md-12 col-sm-12">
						<div class="inner-column">
							<div class="title-box">
								<div class="section-color-layer"></div>
								<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Why Do Students Turn to Law Assignment Writing Services?</h2>
							<p>Due to the difficulty, time, and volume of work involved in legal learning, learners often seek assistance. Our <a href="https://www.assignnmentinneed.com/coursework-writing-help"><b>law coursework help</b></a> students manage time, complex ideas, and citations, thereby enhancing their academic performance.</p>     
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class=" py-0">
			<div class="auto-container ">
				<div class="row clearfix">
					<div class="title-column col-lg-12 col-md-12 col-sm-12">
						<div class="inner-column">
							<div class="title-box">
								<div class="section-color-layer"></div>
								<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">What Motivates Students to Pursue Our Law Coursework Writing Help?</h2>
							   <p>Students seek our services because of the professional legal writers we hire, full solutions for the task, and reasonable prices. When you hire us for your law coursework writing service, you can devote time to your practical training without worrying about your assignments.</p>
							 </div>
						</div>
					</div>
				</div>
			</div>
		</section>
  
		<section class="instructor-section">
	<div class="auto-container">
		<div class="row clearfix">
			<div class="instructor-column col-lg-6 col-md-12 col-sm-12">
				<h2 style="font-weight:500; font-size: 30px; color:black" class="text-start my-4">
					Get Well-Written Assignments in 3 Simple Steps
				</h2>
				<div class="inner-column wow fadeInRight animated" data-wow-delay="0ms" data-wow-duration="1500ms"
					style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInRight;">
					<div class="feature-inner">
						<div class="row">
							<div class="col-2 mt-4">
								<div class="icon"
									style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
									<span
										style="font-size: 39px; color: #04aef3; border: 3px dashed #04aef3; border-radius: 50%; padding: 10px; display: inline-block; text-align: center; width: 50px; height: 50px;">
										1
									</span>
								</div>
							</div>
							<div class="col-10">
								<h3 style="margin: 10px 0; font-size: 20px; font-weight: bold;">Explore Assignment Samples</h3>
								<p style="margin: 0; line-height: 1.6; font-size: 16px; color: black;">
									Explore a variety of free academic samples to understand the quality of work we provide. Each sample showcases the level of detail and research that goes into our assignments.
								</p>
							</div>
						</div>
 
						<div class="row">
							<div class="col-2 mt-4">
								<div class="icon"
									style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
									<span
										style="font-size: 39px; color: #04aef3; border: 3px dashed #04aef3; border-radius: 50%; padding: 10px; display: inline-block; text-align: center; width: 50px; height: 50px;">
										2
									</span>
								</div>
							</div>
							<div class="col-10">
								<h3 style="margin: 10px 0; font-size: 20px; font-weight: bold;">Get Popular Subjects for Math Assignment Help And Math Homework Help</h3>
								<p style="margin: 0; line-height: 1.6; font-size: 16px; color: black;">
									Pick the sample that best matches your assignment type and subject. This will give you a clear idea of how we approach different topics and formats.
								</p>
							</div> 
						</div>
   
						<div class="row">
							<div class="col-2 mt-4">
								<div class="icon"
									style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
									<span
										style="font-size: 39px; color: #04aef3; border: 3px dashed #04aef3; border-radius: 50%; padding: 10px; display: inline-block; text-align: center; width: 50px; height: 50px;">
										3
									</span>
								</div>
							</div>
							<div class="col-10">
								<h3 style="margin: 10px 0; font-size: 20px; font-weight:bold">Download Your Sample</h3>
								<p style="margin: 0; line-height: 1.6; font-size: 16px; color: black;">
									Click the download button to get your chosen sample in PDF instantly. You can review it at your own pace and use it as a reference for your assignment.
								</p>
							</div>
						</div>
					</div>
				</div>
				<div style="text-center" class="mt-4">
					<a href="/upload-your-assignment"><button class=" place-now " style="padding: 10px 20px; color:white">Order Assignment</button></a>
				</div>
			</div>

			<div class="instructor-column col-lg-6 col-md-12 col-sm-12">
				<h2 style="font-weight:500; font-size: 30px; color:black" class="text-start my-4">
					8000+ Samples Reflect the High Standard of Our Work
				</h2>
				@foreach ($data['sample'] as $sample )
				<div class="inner-column wow fadeInRight animated" data-wow-delay="0ms" data-wow-duration="1500ms"
					style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInRight;">
				
					<div class="row">
						<div class="col-2 mt-4">
							<div class="icon"
								style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
								<a href="free-samples/{{$sample->categotyData->name}}/{{$sample->slug}}">
								<img src="images/image.png" style="width: 60px; height: 120px; box-shadow:rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px" alt="">
								</a>
							</div>
						</div>
						<div class="col-10 mb-4">
							<h3 style="margin: 10px 0; font-size: 20px; font-weight: bold;"><a style="color:black" href="free-samples/{{$sample->categotyData->name}}/{{$sample->slug}}">{{$sample->title}}</a></h3>
							<p style="margin: 0; line-height: 1; font-size: 15px; color: #0000008a; font-weight: 700; box-shadow:">
								#{{$sample->categotyData->name}}
							</p>
							@php
								$pageCount = ceil(str_word_count(strip_tags($sample->content)) / 250);
							@endphp
							<div><p class="samplefeature"><span>Number of pages: <b>{{$pageCount}}</b></span> <span>Total Words: <b>{{ str_word_count(strip_tags($sample->content)) }}</b></span></p></div>
						</div>
					</div>
				</div>
			
				@endforeach
				<div style="text-center" class="mt-4" >
					<a href="/free-samples"><button class=" place-now " style="padding: 10px 20px; color:white">View More Sample</button></a>
				</div>
			</div>
			
			</div>
		
	</div>
</section>

		<section class=" py-0">
			<div class="auto-container ">
				<div class="row clearfix">
					<div class="title-column col-lg-12 col-md-12 col-sm-12">
						<div class="inner-column">
							<div class="title-box">
								<div class="section-color-layer"></div>
								<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Need Help with a Law Essay? Get Professional Online Essay Writing Help</h2>
							   <p>As much as legal writing entails both critical thinking and research, a legal essay must comprise, among other things. <a href="https://www.assignnmentinneed.com/essay-writing-help-services"><b>Law essay help</b></a> guarantee properly structured, effective citations, and reasonable argumentation that meet legal academic standards</p>   
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class=" py-0">
			<div class="auto-container ">
				<div class="row clearfix">
					<div class="title-column col-lg-12 col-md-12 col-sm-12">
						<div class="inner-column">
							<div class="title-box">
								<div class="section-color-layer"></div>
								<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Premium Law Homework Help You Can Rely On</h2>
							   <p>At law homework help, all questions are solved in numbered steps making it easy to understand the answers and delivering within the agreed time. In computer science or health care, no homework is a problem for our team of professional writers.</p>   
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class=" py-0">
			<div class="auto-container ">
				<div class="row clearfix">
					<div class="title-column col-lg-12 col-md-12 col-sm-12">
						<div class="inner-column">
							<div class="title-box">
								<div class="section-color-layer"></div>
								<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Different Types of Law Assignment Services We Provide</h2>
							   <p>We offer a variety of specialized law assignment services to cater to different academic requirements. It broadly includes law dissertation service, business law homework help, law coursework help, law essay help etc.  Here’s a brief overview of the services we provide:</p>   

							   <h3>1. Law Academic Writing He</h3>
							   <p>Our writers create well-researched, a-prior knowledge-based papers that demonstrate knowledgeable legal analysis about your topic per your assignment's guidelines.</p>

							   <h3>2. Law Project Reports Writing Help</h3>
							   <p>We offer writing services that include preparing coherently formatted, argumentative, and evidence-based project reports on any legal issues for your coursework.</p>

							   <h3>3. Law Judgment Writing Help</h3>
							   <p>In writing judgments our team has unique ability to analyze the facts of the cases, to use legal logic, and to show how critical evaluation has been done.</p>

							   <h3>4. Law Case Studies Writing Help</h3>
							   <p>We offer case analyses with detailed solutions and discussions of the legal processes and court cases and the legal paradigms associated with them.</p>

							   <h3>5. Law Book Reviews Writing Help</h3>
							   <p>Our experts write comprehensive and analytical summaries of the contents of legal books, as well as assess the usefulness of such books to legal scholars.</p>

							   <h3>6. Law Thesis Writing Help</h3>
							   <p>We assist you in choosing your topic through the preparation of a robust, thesis-based thesis that epitomizes your academic performance from topic selection to submission.</p>

							   <h3>7. Law Dissertation Writing Help</h3>
							   <p>We produce original dissertations that are marked by professionalism, and research that meets strict academic standards for law dissertation proposal help for you excel in your law program.</p>

							   <p>Struggling with your law dissertation? Our <a href="https://www.assignnmentinneed.com/dissertation-writing-help-services"><b>law dissertation writing help</b></a> services are here to guide you through every step of the process. With our professional law dissertation writing services, you gain access to seasoned writers. For added convenience, we offer online law dissertation help, allowing you to connect with experts anytime, anywhere.</p>

							   <h3>8. Law PowerPoint Presentations Writing Help</h3>
							   <p>To those students, who require pretty and loaded slides, we create impressive diagrammatical works for legal materials and courses.</p>

							   <p>These services have been developed to guarantee that students get matching and all-around assistance to improve academic outcomes and improve understanding of the legal field.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
       


		<section class=" py-0">
			<div class="auto-container ">
				<div class="row clearfix">
					<div class="title-column col-lg-12 col-md-12 col-sm-12">
						<div class="inner-column">
							<div class="title-box">
								<div class="section-color-layer"></div>
								<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Why Choose Assignment in Need for Law Assignments?</h2>
							   <p>We offer our services to be the best academically, being punctual, unique, and devoted to the success of our clients. When it comes to law dissertation help online, business law homework help, and criminal justice homework help to mention a few, we give what you want based on your needs.</p>   
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>


        <!-- new section -->

		 <section class="py-4" style="background-color:#BFECFF;"  >
	            <div class="auto-container">
                    <div class="row clearfix">

			<!-- Content Column -->
			  <div class="content-column col-lg-6 col-md-12 col-sm-12">
				 <div class="inner-column">
					<h2 class="py-3" style="font-weight:500; font-size: 30px; color:black">Get the Best Online Law Assignment Writing Help Services Worldwide</h2>
					  <div class="text">
						 <p>At Assignment in Need, they offer law assignment writing help to students, with over 30,000 happy clients and 98.2% of orders arriving timely. Whether pursuing studies in Canada, Malaysia, Spain, Australia, the UAE, or the UK, students can rely on the expert team for support with every law assignment. Tackling complex legal topics can be challenging, and Assignment in Need is dedicated to providing reliable, affordable help. Experienced writers handle each assignment, with customer support available 24/7. Trusted payment methods offer extra security, and students can be confident that their assignments will be completed correctly and on time. For those seeking law assignment writing help, Assignment in Need ensures students achieve academic success while making their assignments less stressful.</p>
						</div>
					 
			          <a href="/upload-your-assignment"> <button style="background: #37AFE1;  color:black; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >Order Now</button> </a>	 
			     </div>
			 </div>

			<!-- Image Column -->
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">
					 <div class="image titlt"  style="mix-blend-mode: multiply;">
						<img src="images2\resource\unnamed (5).png  " alt="">  
					</div>        
				</div>
			</div>

		</div>
	</div>
            </section>

            <!-- end new section -->
        
    
 <!-- FAQs Question  section for Expert Assignment Writing Help -->
 
	        
 <section class="faq-section bg-light">
	    	<div class="auto-container">
			<div class="row ">
				<div class="titel-column col-lg-12 col-md-12 col-sm-12">
				    <div class="title-box text-center">
						<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4"><b>Frequently Asked Questions For Law Assignment Writing Help</b></h2> 
					 </div>
					<div class="row"> 
					 		 
				<div class="column col-lg-6 col-md-6 col-sm-12 ">
					 
					<ul class="accordion-box ">
					       <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">1. How do I submit my law assignment for help?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                        <P>You can submit your assignment either by clicking the submit button on our website or by emailing it with your specific requirements. In both cases, we'll respond to your assignment promptly.</P>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">2. What is Law Assignment Help?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                        <p>Law Assignment Help is a service where expert writers assist you with your law assignments. Whether it's criminal law, contract law, constitutional law, or international law, our professionals provide the guidance and support you need to excel.</p>
                                           
                                            
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">3. How Can I Place an Order for Law Assignment Help?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                         <P>Placing an order is easy! Just fill out our online form with your assignment details, get a quote, make a secure payment, and we'll assign your task to a qualified law expert.</P>
									</div>
                                    </div>
                                </div>
                            </li>
							 
						 
                  	</ul>
					
				</div>
			
				<div class="column col-lg-6 col-md-6 col-sm-12">
					 
					<ul class="accordion-box">
					       <li class="accordion block"> 
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">4. What Are the Qualifications of Your Law Assignment Writers?<div class="icon fa fa-angle-down"></div></div>
                                  <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                         <P>Our law assignment writers are highly qualified professionals with extensive knowledge and experience in various legal fields. They have advanced degrees in law and a track record of helping students succeed.</P>
										</div>
                                    </div>
                                  </div>
                            </li>
							<li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">5. Do you offer help with legal research and writing?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                         <P> Yes, we do! Our experts can assist with both legal research and writing, ensuring your assignments are well-researched, clearly written, and properly cited.</P>
										</div>
                                    </div>
                                </div>
                            </li>
							 
					</ul>
					
				</div>
				 
				 
			     </div>
				   <div class="title-box text-center">
				   <a href="https://www.assignnmentinneed.com/faqs/law-assignment-faqs" style="background: #37AFE1;  color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >View More FAQs</a>
				   </div> 

				</div> 
				 
 			</div>
			  
		</div>
		 
   </section> 
      
@endsection