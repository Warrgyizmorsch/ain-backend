<div class="review-container">
    <!-- Trustpilot -->
    <div class="review-box trustpilot-review">
        <a href="https://www.trustpilot.com/review/assignnmentinneed.com">
            <img src="/images/icons/Trustpilot_Logo.png" alt="Trustpilot Logo" class="review-logo">
        </a>
        <div class="star-rating-box">
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star half"><i class="fa fa-star-half-o"></i></span>
            <span class="rating-number">4.2</span>
        </div>
    </div>

    <!-- Assignment In Need -->
    <div class="review-box ain-review">
        <img src="/images/icons/Assignment-in-need.png" alt="Assignment In Need Logo" class="review-logo">
        <div class="star-rating-box">
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star half"><i class="fa fa-star-half-o"></i></span>
            <span class="rating-number">4.6</span>
        </div>
    </div>

    <!-- Google -->
    <div class="review-box google-review">
        <a href="https://g.co/kgs/GxVHYni">
            <img src="/images/icons/google-logo.png" alt="Google Logo" class="review-logo">
        </a>
        <div class="star-rating-box">
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star filled"><i class="fa fa-star"></i></span>
            <span class="star half"><i class="fa fa-star-half-o"></i></span>
            <span class="rating-number">4.4</span>
        </div>
    </div>
</div>
<style>
    .Trusted-paragraph {
        margin-top: 1rem;
        font-size: 1rem;
        font-weight: 500;
    }

    .review-container {
        display: flex;
        flex-wrap: nowrap;
        gap: 1rem;
        margin-top: 1rem;
        overflow-x: auto;
        padding-bottom: 10px;
        scroll-snap-type: x mandatory;
    }

    .review-box {
        background: #fff;
        padding: 12px 16px;
        border-radius: 12px;
        flex: 0 0 auto;
        width: 180px;
        scroll-snap-align: start;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    }

    .review-logo {
        width: 100%;
        max-width: 120px;
        margin-bottom: 8px;
        transition: transform 0.3s ease-in-out;
    }

    .review-logo:hover {
        transform: scale(1.1);
    }

    .star-rating-box {
        display: flex;
        align-items: center;
        gap: 4px;
        flex-wrap: nowrap;
    }

    .fa {
        font-family: 'FontAwesome' !important;
    }

    .star {
        width: 18px;
        height: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        border-radius: 4px;
        color: white;
    }

    .rating-number {
        font-size: 1rem;
        font-weight: 600;
        margin-left: 6px;
        color: #333;
    }

    .trustpilot-review .star.filled {
        background-color: #00b67a;
    }

    .trustpilot-review .rating-number {
        color: #00b67a;
    }

    .ain-review .star.filled {
        background-color: #6B2FBF;
    }

    .ain-review .rating-number {
        color: #6B2FBF;
    }

    .google-review .star.filled {
        background-color: #4285F4;
    }

    .google-review .rating-number {
        color: #4285F4;
    }

    .star.half {
        background-color: #d3d3d3;
    }

    @media (max-width: 1024px){
        .review-container{
            flex-wrap: wrap;
        }
    } 

    @media (max-width: 600px) {
        .review-container {
            gap: 0.5rem;
            overflow: hidden;
            flex-wrap: wrap;
        }

        .review-box {
            width: 90px;
            padding: 7px 5px;
            background-color: none;
            box-shadow: none;
        }

        .review-logo {
            max-width: 100px;
            margin-bottom: 0;
        }

        .rating-number {
            font-size: 0.6rem;
        }
        .star {
        height: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 6px;
        border-radius: 4px;
        color: white;
    }
    }
</style>
