<style>
	.pricing-card1 {
		background: linear-gradient(180deg, #45119E, #0182CB);
		border-radius: 15px;
		text-align: center;
		display: flex;
		flex-direction: column;
		color: white;
		width: 100%;
		box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
		padding: 15px;
		position: relative;
	}

	.title {
		font-weight: bold;
		color: #fff;
		font-size: 2rem;
	}

	.contact-form {
		padding: 0 15px 15px 15px;
	}

	.form-header {
		padding: 20px 10px 10px 10px;
		text-align: center;
	}

	.pricing-card1 label {
		font-weight: 600;
		display: block;
		color: #ffffff;
		text-align: left;
		margin: 8px 0 4px;
		font-size: 15px;
		letter-spacing: 0.3px;
	}

	.pricing-card1 input,
	.pricing-card1 select {
		width: 100%;
		margin-bottom: 15px;
		border-radius: 8px;
		border: none;
		background-color: #ffffff;
		font-size: 16px;
		color: #333;
		padding: 10px;
		height: 47% !important;
		box-sizing: border-box;
	}

	.price-section {
		margin-top: 15px;
		font-size: 18px;
	}

	.estimated {
		font-weight: bold;
		font-size: 16px;
	}

	.original-price {
		text-decoration: line-through;
		opacity: 0.7;
		font-size: 16px;
		margin-left: 5px;
	}

	.discount {
		background: #28a745;
		color: white;
		padding: 4px 8px;
		border-radius: 4px;
		font-size: 14px;
	}

	.final-price {
		font-size: 36px;
		font-weight: bold;
		color: #FFD700;
		line-height: 40px;
		display: block;
		margin: 8px 0 15px;
	}

	.calculate-btn {
		width: 100%;
		padding: 12px;
		margin-top: 10px;
		background: #FFBD23;
		color: black;
		font-weight: bold;
		text-align: center;
		border: none;
		border-radius: 10px;
		cursor: pointer;
		transition: transform 0.3s ease, box-shadow 0.3s ease;
		font-size: 16px;
	}

	.calculate-btn:hover {
		transform: scale(1.01);
		box-shadow: 0px 0px 15px rgba(255, 189, 35, 0.8);
	}

	.discount-banner {
		text-align: center;
		margin-bottom: 1rem;
		animation: popIn 0.6s ease-out;
		position: absolute;
		top: -12px;
		left: 20%;
		transform: translateX(-50%);
	}

	@keyframes popIn {
		0% {
			transform: translateX(-50%) scale(0.8);
			opacity: 0;
		}

		100% {
			transform: translateX(-50%) scale(1);
			opacity: 1;
		}
	}

	.discount-banner img {
		width: 100px;
	}



	/* Responsive Design */
	@media screen and (max-width: 1024px) {
		.title {
			font-size: 1.8rem;
		}
	}

	@media screen and (max-width: 768px) {
		.pricing-card1 {
			padding: 10px;
		}

		.title {
			font-size: 1.5rem;
		}

		.final-price {
			font-size: 28px;
		}

		.price-section {
			font-size: 16px;
		}

		.calculate-btn {
			font-size: 14px;
			padding: 10px;
		}

		.discount-banner {
			top: -11px;
		}

		.pricing-card1 label {
			font-size: 12px;
		}

		.pricing-card1 input,
		.pricing-card1 select {
			font-size: 12px;
			margin-bottom: 5px;
		}

		.discount-banner img {
			width: 90px;
		}
	}

	@media screen and (max-width: 576px) {
		.title {
			font-size: 1.3rem;
		}

		.calculate-btn {
			font-size: 13px;
			padding: 9px;
		}
	}
</style>

<div class="pricing-card1">
	<div class="discount-banner">
		<img src="{{ url('/images/40%-off.png') }}" alt="40% OFF">
	</div>
	<form id="orderForm" enctype="multipart/form-data">
		<div class="form-header">
			<h2 class="title order-now">Pricing</h2>
		</div>
		<div class="contact-form">
			<div class="row">
				<div class="col-md-12">
					<label for="serviceSelect">Services</label>
					<select required id="serviceSelect" class="form-control">
						<option value="">Select Services</option>
						<option value="Assignment">Assignment</option>
						<option value="Dissertation">Dissertation</option>
						<option value="Thesis">Thesis</option>
						<option value="Research Project">Research Project</option>
					</select>
				</div>

				<div class="col-md-12 d-none">
					<label for="workTypeSelect">Work Type</label>
					<select id="workTypeSelect" class="form-control">
						<option value="">Select Work Type</option>
						<option selected value="Standard">Standard</option>
						<option value="FirstClass">First Class Work</option>
					</select>
				</div>

				<div class="col-md-12">
					<label for="subjectSelect">Subject</label>
					<select required id="subjectSelect" class="form-control">
						<option value="">Select Subject</option>
						<!-- Subject options -->
						<option value="Matlab">Matlab</option>
						<option value="Data Science">Data Science</option>
						<option value="Engineering">Engineering</option>
						<option value="App Development">App Development</option>
						<option value="Web Development">Web Development</option>
						<option value="Exam">Exam</option>
						<option value="Public Health">Public Health</option>
						<option value="Presentation">Presentation (PPT)</option>
						<option value="Portfolio">Portfolio</option>
						<option value="Research Report">Research Report</option>
						<option value="Business Management">Business Management</option>
						<option value="Project Management">Project Management</option>
						<option value="Essay">Essay</option>
						<option value="HRM">HRM</option>
						<option value="Economic">Economic</option>
						<option value="Other">Other</option>
					</select>
				</div>

				<div class="col-md-6">
					<label for="urgencySelect">Select Urgency</label>
					<select required id="urgencySelect" class="form-control">
						<option value="">Select Urgency</option>
						<!-- Options -->
						<option value="1">1 Day</option>
						<option value="2">2 Days</option>
						<option value="3">3 Days</option>
						<option value="4">4 Days</option>
						<option value="5">5 Days</option>
						<option value="6">6 Days</option>
						<option value="7">7 Days</option>
						<option value="8">8 Days</option>
						<option value="9">9 Days</option>
						<option value="10">10 Days</option>
						<option value="11">11 Days</option>
						<option value="12">12 Days</option>
						<option value="13">13 Days</option>
						<option value="14">14 Days</option>
						<option value="15">15 Days</option>
						<option value="16 to 20">16-20 Days</option>
						<option value="21+">21+ Days</option>
					</select>
				</div>

				<div class="col-md-6">
					<label for="wordCount">Word Count</label>
					<input required type="number" id="wordCount" class="form-control" min="250" value="250"
						placeholder="Enter Count">
				</div>

				<div class="col-md-12">
					<div class="price-section">
						<span class="estimated">Estimated Price:</span>
						<span class="basePrice original-price">£ 100</span>
						<span class="discount priceoff">40% OFF</span>
						<span class="final-price">£ <span class="offerPrice">75</span></span>
					</div>
				</div>

				<div class="col-md-12 text-center">
					<button class="calculate-btn" type="submit">Place Order</button>
				</div>
			</div>
		</div>
	</form>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
	$(document).ready(function () {
		function calculatePrice() {
			let wordCount = Math.max(parseInt($('#wordCount').val()) || 250, 250);
			let service = $('#serviceSelect').val();
			let type = $('#workTypeSelect').val();
			let urgency = $('#urgencySelect').val();

			let baseRate = 0.03 * wordCount;

			if (wordCount < 500) baseRate *= 2.67;
			else if (wordCount < 1000) baseRate *= 2.22;
			else if (wordCount < 2000) baseRate *= 1.94;
			else if (wordCount < 3000) baseRate *= 1.67;
			else if (wordCount < 4000) baseRate *= 1.3;
			else if (wordCount < 5000) baseRate *= 1.13;
			else baseRate *= 1.17;

			const serviceMultiplier = ['Dissertation', 'Thesis', 'Research Project'].includes(service) ? 1.1 : 1;
			const typeMultiplier = (type === 'FirstClass') ? 1.3 : 1;

			const urgencyMultipliers = {
				'1': 2.0, '2': 1.5, '3': 1.4, '4': 1.3, '5': 1.2, '6': 1.15,
				'7': 1.1, '8': 1.09, '9': 1.07, '10': 1.05, '11': 1.04,
				'12': 1.03, '13': 1.02, '14': 1.01, '15': 1.0,
				'16 to 20': 0.95, '21+': 0.9
			};
			const urgencyMultiplier = urgencyMultipliers[urgency] || 1;

			let price = baseRate * serviceMultiplier * typeMultiplier * urgencyMultiplier;

			let discountPercent = parseFloat($('.priceoff').text().replace('% OFF', '').trim()) || 0;
			let discountAmount = price * (discountPercent / 100);
			let finalPrice = price - discountAmount;

			$('.basePrice').text('£ ' + price.toFixed(2));
			$('.offerPrice').text(finalPrice.toFixed(2));
		}

		$('#serviceSelect, #workTypeSelect, #urgencySelect, #wordCount').on('change keyup', calculatePrice);
		calculatePrice();

		$('#orderForm').on('submit', function (e) {
			e.preventDefault();
			alert('Form submitted with total: £' + $('.offerPrice').text());
		});
	});
</script>