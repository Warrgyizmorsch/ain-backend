<div>
    @props(['title', 'subtitle'])

    <section class=" bg-hero">
        <div class="auto-container">
            <div class="row">
                <!-- Content Column -->
                <div class="content-column">
                    <h1 class="main-heading">{{ $title  }}</h1>
                    <p>{{ $subtitle }}</p>
                    <p>Trusted by over <span>5,000 students </span>for assignment help</p>

                    <!-- Review Section -->
                    @include('components.review-section')
                </div>

                <!-- Form Column -->
                <div class="form-column">
                    <div class="form-container">
                        @include('new-form')
                    </div>
                </div>
            </div>
        </div>

        <!-- Internal CSS with Animations -->
        <style>
            /* Background Image for Hero Section */
            .bg-hero {
                background: url(/images/background/home-bg.png);
                background-repeat: no-repeat;
                background-size: cover;
                background-attachment: fixed;
                position: relative;
                overflow: hidden;
                padding-bottom: 50px;
                box-shadow: rgba(0, 0, 0, 0.06) 0px 2px 4px 0px inset;
                /* animation: fadeIn 1.5s ease-in-out; */
            }

            .content-column {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                justify-content: center;
                padding: 2rem 1rem;
                text-align: left;
            }

            /* Animations */
            @keyframes slideInLeft {
                from {
                    opacity: 0;
                    transform: translateX(-50px);
                }

                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }

            @keyframes slideInRight {
                from {
                    opacity: 0;
                    transform: translateX(50px);
                }

                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }

            /* Responsive */
            @media (max-width: 768px) {
                .hero-content {
                    flex-direction: column;
                }
                .main-heading {
                    font-size: 3rem;
                }
                .content-paragraph p {
                    font-size: 1rem;
                    text-align: left;
                }
            }

            @media (max-width: 600px) {
                .bg-hero {
                    padding: 1.5rem 1rem;
                }
                .content-list-item {
                    flex-direction: column;
                }
                .main-heading {
                    font-size: 1.8rem;
                }
            }

            /* Fade-in Animation */
            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(-30px);
                }

                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            /* Content Slide-in Animation */
            .content-column {
                animation: slideInLeft 1.2s ease-in-out;
            }

            /* Form Slide-in Animation */
            .form-column {
                animation: slideInRight 1.2s ease-in-out;
            }

            /* Keyframes for Slide-in */
            @keyframes slideInLeft {
                from {
                    opacity: 0;
                    transform: translateX(-50px);
                }

                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }

            @keyframes slideInRight {
                from {
                    opacity: 0;
                    transform: translateX(50px);
                }

                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }

            /* Row Styling */
            .row {
                display: flex;
                align-items: center;
                justify-content: center;
                flex-wrap: wrap;
                margin: auto;
                margin-top: 50px;
            }

            .content-column {
                flex: 1;
                min-width: 50%;
            }

            .content-column:nth-child(2) {
                font-size: 14px;
            }

            .form-container {
                flex: 1;
                min-width: 50%;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            /* Banner Heading */
            .content-column h1 {
                background: linear-gradient(to bottom, #3F159A, #0E8FCE);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                font-size: 3rem;
                font-weight: 900;
                line-height: 1.3;
                text-align: left;
            }

            .content-column p {
                font-size: 18px;
                color: #333;
            }

            .content-column p:nth-of-type(2) {
                font-size: 14px;

            }

            .content-column span {
                font-weight: 900;
            }

            /* Banner Stats */
            .banner-stats-container {
                display: flex;
                gap: 20px;
                margin-top: 20px;
                width: 50%;
            }

            .banner-stat {
                /* background: linear-gradient(90deg, #0039a6, #0085ff); */
                padding: 15px;
                border-radius: 8px;
                text-align: center;
                width: 150px;
                color: #000;
                /* box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px; */
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }


            /* Hover Effect for Stats */
            .banner-stat:hover {
                transform: scale(1.05);
                box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.3);
            }

            .banner-stats-title {
                font-size: 20px;
                font-weight: 600;
            }



            @media (max-width: 1024px) {


                .content-column {
                    padding: 20px;
                    margin: auto;
                }

                .form-container {
                    min-width: 100%;
                    margin-top: 20px;
                }

                .content-column h1 {
                    font-size: 40px;
                }

                .content-column p {
                    font-size: 16px;
                }

                .row {
                    margin: auto;
                }

                .review-container {
                    align-items: center;
                }
            }

            @media (max-width: 768px) {
                .bg-hero {
                    padding: 40px 15px;
                    background-attachment: scroll;
                }

                .content-column h1 {
                    font-size: 32px;
                }

                .content-column p {
                    font-size: 14px;
                }


            }

            @media (max-width: 480px) {
                .content-column h1 {
                    font-size: 28px;
                }

                .content-column p {
                    font-size: 14px;
                }



            }

            /* ✅ Optimized for 320px Screens */
            @media (max-width: 320px) {
                .bg-hero {
                    padding: 30px 10px;
                }

                /* 🔹 Banner Stats Section */
                .banner-stats-container {
                    flex-direction: column;
                    gap: 10px;
                    width: 100%;
                }

                .banner-stat {
                    width: 100px;
                    padding: 10px;
                    font-size: 12px;
                }
            }
        </style>
    </section>



</div>