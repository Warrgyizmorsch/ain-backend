@extends('frontend-layouts.app')
@section('content')

@include('home.section.hero')



@include('home.section.about-us')


@include('home.section.how-it-works')

@include('home.section.expert-section')

@include('home.section.choose-us')

@include('home.section.numbers')

@include('home.section.writing-services')


@include('home.section.sample-guide')

@include('home.section.samples-demo')

@include('home.section.ticket')


@include('home.section.expert-testimonial')


@include('home.section.subjects')

@include('home.section.whatsapp')

@include('home.section.grades')

@include('home.section.video-testimonial')


@include('home.section.boost')

@include('home.section.blog')

@include('home.section.scrollable')

@include('home.section.faq-section')



@endsection