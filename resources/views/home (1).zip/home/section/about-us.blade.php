<!-- About Us Section -->
<section class="page-section about-us-section">
  <h2 class="section-title">About <span>Us</span></h2>

  <div class="about-content-wrapper">
    <div class="about-video">
      <div class="youtube-facade" data-video-id="tfpeB0-PEsA" onclick="loadYoutube(this)">
        <img
          src="https://img.youtube.com/vi/tfpeB0-PEsA/hqdefault.jpg"
          alt="Introduction Video"
          loading="lazy"
          fetchpriority="high"
        />
      </div>
    </div>

    <div class="about-text">
      <p>
        At <a href="/"><b>Assignment in Need</b></a>, our core strength lies in the collective experience and deep subject-matter expertise of our academic team. Established in 2018, we were founded on the principle of providing genuine educational support, not just task completion. Our network comprises over 3,000 professionals holding PhDs and master's degrees from leading universities across the UK and internationally. We are committed to matching you with an expert who not only understands your assignment but also the broader context of your studies, whether you are based in the UK or studying internationally.
      </p>
      <p>
        <a href="/what-we-are"><button class="expert-btn">About Us</button></a>
      </p>
    </div>
  </div>
</section>


<!-- CSS -->
<style>
.about-us-section {
  background-color: #f7f7f7;
  border-radius: 1rem;
  padding: 40px 20px;
  margin: 2rem auto ;
}

.about-content-wrapper {
  display: flex;
  flex-wrap: wrap;
  gap: 2rem;
  align-items: center;
  justify-content: center;
  max-width: 1200px;
  margin: auto;
}

.about-video {
  flex: 1 1 45%;
  min-width: 280px;
  aspect-ratio: 16 / 9;
  position: relative;
  width: 100%;
  max-width: 600px;
}

.youtube-facade {
  position: absolute;
  inset: 0;
  cursor: pointer;
  background: #000;
  border-radius: 1rem;
  overflow: hidden;
}

.youtube-facade img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 1rem;
}

.about-text {
  flex: 1 1 45%;
  min-width: 280px;
  color: #444;
  font-size: 1rem;
  line-height: 1.7;
  max-width: 600px;
}

.about-text p {
  margin-bottom: 1.2rem;
  text-align: justify;
}


/* Tablet and down */
@media (max-width: 1024px) {
  .about-content-wrapper {
    align-items: stretch;
    text-align: center;
  }

  .about-text {
    text-align: left;
  }
}

/* Phone-specific */
@media (max-width: 480px) {
  .about-text {
    font-size: 0.8rem;
    line-height: 1.6;
  }

  .expert-btn {
    font-size: 0.95rem;
    padding: 8px 16px;
  }
}</style>

<!-- JS -->
<script>
  function loadYoutube(el) {
    const videoId = el.getAttribute('data-video-id');
    const iframe = document.createElement('iframe');
    iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
    iframe.setAttribute('frameborder', '0');
    iframe.setAttribute('allowfullscreen', '');
    iframe.setAttribute(
      'allow',
      'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture'
    );
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    el.innerHTML = '';
    el.appendChild(iframe);
  }
</script>
