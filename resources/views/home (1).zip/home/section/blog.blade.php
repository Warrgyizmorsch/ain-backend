<section class="page-section blog-section">
    <div class="container">
        <div class="auto-container">
            <h2 class="section-title">Explore Our Blogs for <span>Assignment Help in the UK</span></h2>
            <p class="section-description">
                Stay ahead in your studies with expert writing tips, assignment strategies, and UK-specific academic advice for university students.
            </p>
            <div class="inner-container">
                <div class="owl-carousel owl-theme blog-carousel">
                    @foreach($data['blog'] as $blog)
                        <div class="testimonial-block-four">
                            <div class="blog-card">
                                <div class="blog-card-content">
                                    <h3 class="blog-title">
                                        <a href="blog/{{ $blog->slug }}">{{ $blog->tittle }}</a>
                                    </h3>
                                    <p class="blog-description">
                                        {{ \Illuminate\Support\Str::limit($blog->custom_content, 120) }}
                                    </p>
                                    <a href="blog/{{ $blog->slug }}" class="blog-button">Read More</a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>

                <!-- Custom Nav Buttons -->
                <div class="custom-blog-nav">
                    <button class="custom-blog-prev">Prev</button>
                    <button class="custom-blog-next">Next</button>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    .blog-card {
    background-color: #FCE7C8;
    border: 1px solid #eee;
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease-in-out;
    height: 100%;
}

.blog-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
}

.blog-card-content {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 100%;
}

.blog-title a {
    font-size: 14px;
    font-weight: 700;
    line-height: 1.5;
    color: #2d2d2d;
    text-decoration: none;
    text-align: left;
    display: inline-block;
}

.blog-description {
    font-size: 14px;
    color: #666;
    line-height: 1.5;
    text-align: left;
    margin: 10px 0 20px;
}

.blog-button {
    align-self: start;
    background-color: #6B4FA7;
    color: #fff;
    padding: 8px 16px;
    font-size: 13px;
    border: none;
    border-radius: 6px;
    text-decoration: none;
    transition: background-color 0.2s ease-in-out;
}

.blog-button:hover {
    background-color: #553393;
}

/* Custom Nav Buttons */
.custom-blog-nav {
    text-align: center;
}

.custom-blog-prev,
.custom-blog-next {
    background-color: #6B4FA7;
    color: white;
    border: none;
    padding: 10px 18px;
    font-size: 14px;
    border-radius: 5px;
    margin: 0 5px;
    cursor: pointer;
    transition: background-color 0.2s ease;
}

.custom-blog-prev:hover,
.custom-blog-next:hover {
    background-color: #553393;
}

</style>
<script>
    $(document).ready(function () {
        $(".blog-carousel").owlCarousel({
            items: 3,
            margin: 20,
            loop: false, // ✅ Disable infinite loop
            nav: false,  // We use custom buttons
            dots: false,
            responsive: {
                0: { items: 1 },
                600: { items: 2 },
                1000: { items: 3 }
            }
        });

        // Custom navigation
        $('.custom-blog-next').click(function () {
            $(".blog-carousel").trigger('next.owl.carousel');
        });

        $('.custom-blog-prev').click(function () {
            $(".blog-carousel").trigger('prev.owl.carousel');
        });
    });
</script>
