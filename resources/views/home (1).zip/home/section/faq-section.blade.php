<section class="page-section faq-section">
    <div class="container">
        <h2 class="section-title">Assignment in Need: <span>Frequently Asked Questions</span></h2>
        <div class="faq-container">
            <div class="faq-column">


                <div class="faq-item">
                    <button class="faq-question">
                        <span>1. Can you help with urgent assignment requests?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>Yes, we offer expedited services for urgent assignment requests. Whether you need help with
                            an assignment, homework, or a research paper on a tight deadline, our team is equipped to
                            handle quick turnarounds while maintaining quality.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <button class="faq-question">
                        <span>2.Can I communicate directly with the writer working on my assignment?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>Yes, our platform allows you to communicate directly with your writer. This ensures that you
                            can provide additional details, ask questions, and receive updates throughout the writing
                            process to ensure the final work meets your expectations.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>3. What is your refund policy if I'm not satisfied with the work?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>We offer a 120% money-back guarantee if we miss the delivery deadline or fail to meet your
                            expectations. Your satisfaction is our priority, and we ensure that you receive the highest
                            quality work or your money back.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>4.Do you offer discounts for multiple assignments or long-term projects?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>Yes, we offer discounts for multiple assignments and long-term projects. For example, place
                            five orders and get one free of cost. Contact us to learn more about our discount offers and
                            how we can support your ongoing academic needs.</p>
                    </div>
                </div>
            </div>
            <div class="faq-column">
                
                <div class="faq-item">
                    <button class="faq-question">
                        <span>5. How can students in different countries access your services?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>Students from various countries, including the UK, Australia, Spain, Canada, Malaysia, and
                            the UAE, can access our services online. Simply visit our website, choose your service, and
                            provide the necessary details to get started.</p>
                    </div>
                </div>

                <div class="faq-item">
                    <button class="faq-question">
                        <span>6. Can I hire someone to help with my case study?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>Yes, you can hire our expert writers to help with your case study assignment writing. Simply
                            visit our website, and provide the necessary details about your assignment, Our team is
                            dedicated to delivering high-quality, customized case study assignment help in every
                            subject.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">
                        <span>7. Do you offer help with writing a CV?</span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="faq-answer">
                        <p>Yes, we provide assistance with writing a professional CV that highlights your skills and
                            experiences. Our resume writing service helps to get the best job in any filled employer.
                        </p>
                    </div>
                </div>

            </div>
        </div>
        <a href="/faqs"> <button class="expert-btn">View More FAQs </button></a>
    </div>
</section>

<style>
    .faq-container {
        display: flex;
        justify-content: center;
        gap: 20px;
    }

    .faq-column {
        width: 45%;
    }

    .faq-item {
        margin-bottom: 10px;
        border: 2px solid #5e2ced;
        border-radius: 5px;
        overflow: hidden;
    }

    .faq-question {
        width: 100%;
        text-align: left;
        background: white;
        padding: 15px;
        cursor: pointer;
        font-size: 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border: none;
        font-weight: 500;
    }

    .faq-question i {
        transition: transform 0.3s ease-in-out;
        color: #5e2ced;
    }

    .faq-answer {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.4s ease-out, padding 0.4s ease-out;
        padding: 0 15px;
        background: #f9f9f9;
        font-size: 14px;
    }

    .faq-item.active .faq-answer {
        max-height: 150px;
        padding: 10px 15px;
    }

    .faq-item.active .faq-question i {
        transform: rotate(180deg);
    }

    @media (max-width: 768px) {
        .faq-container {
            flex-direction: column;
            align-items: center;
            width: 90%;
            margin: auto;
        }

        .faq-column {
            width: 100%;
        }
    }
</style>

<script>
    document.querySelectorAll(".faq-question").forEach((button) => {
        button.addEventListener("click", () => {
            const faqItem = button.parentElement;
            const faqAnswer = faqItem.querySelector(".faq-answer");

            // Close other open FAQs
            document.querySelectorAll(".faq-item").forEach((item) => {
                if (item !== faqItem) {
                    item.classList.remove("active");
                    item.querySelector(".faq-answer").style.maxHeight = null;
                }
            });

            // Toggle current FAQ
            faqItem.classList.toggle("active");
            if (faqItem.classList.contains("active")) {
                faqAnswer.style.maxHeight = faqAnswer.scrollHeight + "px";
            } else {
                faqAnswer.style.maxHeight = null;
            }
        });
    });
</script>