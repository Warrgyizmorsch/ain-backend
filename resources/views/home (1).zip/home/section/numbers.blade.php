<section class="page-section numbers-section">
    <div class="container">
      <h2 class="section-title">Our Success in Numbers – Why Students Trust Us for Exceptional <span>Assignment Help </span></h2>
      <p class="section-description">Real numbers, real results for UK and international students like you: Experience the difference quality makes. With over 7 years of dedicated service, our high client return rate and the positive feedback from students who've seen improved grades are a testament to our dedicated expertise.</p>
  
      <div class="stats-container">
        <div class="stat-card">
          <i class="fas fa-clipboard-check"></i>
          <div class="stat-number">45,000+</div>
          <p>Assignments successfully completed with our expert guidance</p>
        </div>
        <div class="stat-card">
          <i class="fas fa-smile"></i>
          <div class="stat-number">30,000+</div>
          <p>Students benefitted from completed projects</p>
        </div>
        <div class="stat-card">
          <i class="fas fa-redo"></i>
          <div class="stat-number">98%</div>
          <p>Recurring client return rate</p>
        </div>
        <div class="stat-card">
          <i class="fas fa-user-graduate"></i>
          <div class="stat-number">9/10</div>
          <p>Students Improve Grades after receiving our expert support</p>
        </div>
      </div>
    </div>
  </section>
  
<style>
.numbers-section {
    background: #E5D4FF;
    max-width: 100%;
}


.stats-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 30px;
}

.stat-card {
    background: white;
    color: #1f1f1f;
    width: 220px;
    padding: 25px 20px;
    border-radius: 10px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    border-bottom: 4px solid #5e2ced;
    text-align: center;
    transition: transform 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
}

.stat-card i {
    font-size: 36px;
    color: #5e2ced;
    margin-bottom: 15px;
}

.stat-number {
    font-size: 28px;
    font-weight: bold;
    color: #5e2ced;
    margin-bottom: 10px;
}

.stat-card p {
    font-size: 12px;
    font-weight: 500;
    line-height: 1.3;
    margin-bottom: 0 !important;
}

/* Responsive */
@media (max-width: 1024px){
    .stat-card {
        width: 48%;
    }
}
@media (max-width: 768px) {
    .stat-card {
        width: 45%;
    }
}

@media (max-width: 480px) {
    .stat-card {
        width: 100%;
    }

    .stat-card i {
        font-size: 28px;
    }

    .stat-number {
        font-size: 20px;
    }
}

</style>
