<section class="page-section subjects-section-boost">
    <h2 class="section-title">Boost Your <span>Academic Writing</span> Skills</h2>
    <div class="subjects-grid-boost">
        <div class="subjects-list-container-boost">
            <ul class="subjects-list">
                <li><a href="blog/how-to-write-a-reflective-essay-a-complete-guide"><span class="circle">E</span> Essay </a></li>
                <li><a href="blog/how-to-write-discussion-posts"><span class="circle">D</span> Discussion Posts</a></li>
                <li><a href="/blog/how-to-write-a-reflection-paper-tips-structure-and-examples"><span class="circle">R</span> Research Paper</a></li>
                <li><a ><span class="circle">R</span> Rhetorical Analysis Paper</a></li>
                <li><a href="/blog/how-to-write-an-assignment-on-the-first-page"><span class="circle">A</span> Assignment</a></li>
                <li><a href="/blog/how-to-write-marketing-assignments-like-a-pro"><span class="circle">M</span> Marketing Assignment</a></li>
                <li><a ><span class="circle">D</span> Dissertation </a></li>
                <li><a href="/blog/the-four-key-language-skills-definition-examples-and-how-to-improve-speaking-listening-reading-and-writing"><span class="circle">L</span> Language Skill</a></li>
                <li><a href="/blog/writing-an-abstract-made-easy-for-your-research-paper-tips-and-techniques"><span class="circle">A</span> Abstract Paper</a></li>
            </ul>
        </div>
      </div>
</section>

