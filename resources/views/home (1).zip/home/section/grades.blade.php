<section class="page-section graded-assignments">
    <div class="container">
        <h2 class="section-title"><span>Assignments </span>We've Done for Students</h2>
        <p class="section-description">
            We take pride in delivering high-quality, top-graded assignments across diverse subjects. Approved by students for publication, these assignments showcase academic excellence and precision.
            <span class="eye-icon">
                <i class="fa fa-eye">️</i>
                <span class="tooltip">Educational examples, with student consent. Student names, topics, and assignment details are always kept private.</span>
            </span>
        </p>

        <div class="assignments-container">
            <div class="assignment-card">
                <div class="assignment-header">
                    <h3>Mathematics</h3>
                    <span class="status-badge">Done</span>
                </div>
                <p class="assignment-type">Problem : Decoding Complex Equations</p>
                <p class="assignment-desc">Worked on: Step-by-step solutions for differentiation, integration,
                    probability distributions, and number theory.</p>
            </div>
            <div class="assignment-card">
                <div class="assignment-header">
                    <h3>Nursing</h3>
                    <span class="status-badge">Done</span>
                </div>
                <p class="assignment-type">Research Paper: ADHD Management
                </p>
                <p class="assignment-desc">Worked on: Clinical research, case evaluations, medical ethics, and
                    patient-centered care strategies.</p>
            </div>
            <div class="assignment-card">
                <div class="assignment-header">
                    <h3>Law</h3>
                    <span class="status-badge">Done</span>
                </div>
                <p class="assignment-type">Case Study: Criminal Justice Reform</p>
                <p class="assignment-desc">Worked on: Legal analysis, case law research, and structured argument
                    development.</p>
            </div>
            <div class="assignment-card">
                <div class="assignment-header">
                    <h3>Finance</h3>
                    <span class="status-badge">Done</span>
                </div>
                <p class="assignment-type">Project: Investment Risk Assessment</p>
                <p class="assignment-desc"> Worked on: Financial modeling, risk analysis, and strategic investment
                    planning.</p>
            </div>
            <div class="assignment-card">
                <div class="assignment-header">
                    <h3>Business & Marketing</h3>
                    <span class="status-badge">Done</span>
                </div>
                <p class="assignment-type">Marketing Plan: Consumer Behaviour & Digital Strategy</p>
                <p class="assignment-desc">Worked on: Market research, SWOT analysis, and strategic branding techniques.
                </p>
            </div>
            
            <div class="assignment-card help-card">
            <p class="help-text">Need help with your assignment?</p>
            <a href="/writers"><button class="help-button">Hire an expert</button></a>
        </div>
        </div>
       
    </div>
</section>

<style>
        .eye-icon {
            margin-left: 10px;
            cursor: pointer;
            display: inline-block;
            position: relative;
        }
        .eye-icon:hover .tooltip {
            visibility: visible;
            opacity: 1;
        }
        .tooltip {
            visibility: hidden;
            opacity: 0;
            transition: opacity 0.3s;
            position: absolute;
            left: 0;
            top: 30px;
            background-color: #f0f0f0;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            width: 250px;
        }
        @media (max-width: 600px) {
            .description {
                font-size: 14px;
            }
            .tooltip {
                width: 200px;
                font-size: 12px;
                left: 50%;
                transform: translateX(-50%);
            }
        }
    .assignments-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
    }

    .assignment-card {
        background: #fff;
        border-radius: 10px;
        padding: 20px;
        width: 350px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        text-align: left;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }


    .assignment-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
    }

    @media (min-width: 600px) {
    .assignment-card {
        flex: 1 1 calc(50% - 20px);
    }
    
}

@media (min-width: 900px) {
    .assignment-card {
        flex: 1 1 calc(33.33% - 20px);
    }
}

    .assignment-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .assignment-header h3 {
        font-size: 18px;
        font-weight: bold;
        color: #1a1a1a;
    }

    .status-badge {
        background-color: #4821c3;
        color: #fff;
        font-size: 12px;
        padding: 5px 10px;
        border-radius: 12px;
    }

    .assignment-type {
        font-size: 14px;
        color: #4821c3;
        margin: 5px 0;
    }

    .assignment-desc {
        font-size: 14px;
        color: #444;
        font-weight: 500;
    }

    .help-card {
        background: #fff7d4;
        border: 2px solid #ffd700;
        text-align: center;
        padding: 30px 20px;
        width: 280px;
        margin: 25px auto;
        border-radius: 10px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .help-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 12px rgba(255, 215, 0, 0.3);
    }

    .help-text {
        font-size: 16px;
        font-weight: bold;
        color: #333;
    }

    .help-button {
        background-color: #ffd700;
        border: none;
        padding: 10px 15px;
        font-size: 14px;
        font-weight: bold;
        color: #000;
        border-radius: 8px;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .help-button:hover {
        background-color: #e6c200;
        transform: scale(1.05);
    }
</style>
