<section class="page-section academic-services">
    <div class="container">
    <h2 class="section-title">Our Comprehensive Academic <span>Writing Services</span></h2>
    <p class="section-description">High-Quality, Original Academic Writing for All, from Students to Researchers, Across All Assignment Types.</p>
    
<div class="services-slider-wrapper">
  <div class="owl-carousel services-slider owl-theme m-auto">
    <div class="service-item">
      <a href="uk/essay-writing-help"><h3>Essay Help</h3></a>
      <p>We assist those seeking help with writing high-quality essays. Our writers ensure each essay is well-researched, properly structured, and plagiarism-free. We tailor every essay to your requirements, helping you present your ideas confidently.</p>
    </div>
    <div class="service-item">
      <a href="uk/reseach-paper-writing-help"><h3>Research Paper Help</h3></a>
      <p>Our research paper help service supports individuals in writing detailed and well-researched papers. We assist with topic selection, research, writing, and formatting to ensure your paper meets academic standards. Our writers deliver original content supported by credible sources.</p>
    </div>
    <div class="service-item">
      <a href="/uk/dissertation-writing-help-online"><h3>Dissertation Help</h3></a>
      <p>Struggling with your dissertation? Our expert writing service removes the overwhelm. We provide personalised support for crafting strong dissertation proposals, conducting thorough literature reviews, managing complex data collection, and producing high-quality writing. From choosing the right topic to final submission, we ensure your dissertation is well-structured, backed by solid research, and properly cited, adhering to all academic standards.</p>
    </div>
    <div class="service-item">
      <a href="uk/thesis-assignment-writing-help"><h3>Thesis Help</h3></a>
      <p>Getting a strong thesis doesn't need to be daunting. We provide patient, expert support for you to get through each step, from research planning to proofing. We emphasize clear writing and hands-on guidance, so your thesis is both academically valid and reader-friendly. Let us assist you in presenting your research with confidence, with a well-organised and properly referenced thesis that satisfies all academic criteria.</p>
    </div>
    <div class="service-item">
      <a href="/uk/coursework-writing-help"><h3>Coursework Help</h3></a>
      <p>We offer coursework help for individuals with demanding workloads. Our writers create customised content to meet your requirements. We ensure your coursework is well-organised, properly referenced, and delivered on time to support your academic skill development.</p>
    </div>
    <div class="service-item">
      <a href="/uk/case-study-writing-help"><h3>Case Study Help</h3></a>
      <p>Case Study Help Our case study helps service provide in-depth analysis and writing support for real-life scenarios. We identify key issues and offer well-researched solutions. Our writers craft clear, concise, and well-structured case studies to help you demonstrate analytical and problem-solving skills.</p>
    </div>
    <div class="service-item">
      <a href="/uk/homework-help-service"><h3>Homework Help</h3></a>
      <p>We provide homework help across subjects and fields. Our qualified writers deliver accurate and well-explained solutions to enhance your understanding of concepts. We ensure all homework are completed on time and meet high standards of quality and clarity.</p>
    </div>
  </div>
   <!-- Custom Nav Buttons -->
                <div class="custom-nav">
                    <button class="custom-prev">Prev</button>
                    <button class="custom-next">Next</button>
                </div>
</div>


</div>
</section>

<style>
/* Wrapper */
.services-slider-wrapper {
  position: relative;
  margin: 0 auto;
  max-width: 100%;
  padding: 10px 0 20px;
}

/* Service Item */
.service-item {
  background: white;
  border-radius: 10px;
  border: 2px solid rgb(63, 21, 154);
  box-shadow: 0 4px 8px rgba(63, 21, 154, 0.2);
  padding: 20px;
  text-align: center;
  height: 350px;
  overflow-y: auto;
  transition: transform 0.3s, box-shadow 0.3s;
}

.service-item:hover {
  transform: translateY(-5px);
  box-shadow: 0 6px 12px rgba(94, 44, 237, 0.3);
}

/* Scrollbar (Firefox) */
.service-item {
  scrollbar-width: thin;
  scrollbar-color: #5e2ced #f0f0f0;
}

/* Scrollbar (WebKit) */
.service-item::-webkit-scrollbar {
  width: 8px;
}
.service-item::-webkit-scrollbar-track {
  background: #f0f0f0;
}
.service-item::-webkit-scrollbar-thumb {
  background-color: #5e2ced;
  border-radius: 10px;
  border: 1.5px solid #f0f0f0;
}
.service-item::-webkit-scrollbar-thumb:hover {
  background-color: #35189f;
}

/* Headings & Paragraphs */
.service-item h3 {
  font-weight: bold;
  font-size: 20px;
  color: #5e2ced;
  margin-bottom: 10px;
}
.service-item p {
  text-align: left;
  font-weight: 500;
  font-size: 1rem;
}

/* Custom Nav Buttons */
.custom-nav {
  text-align: center;
  margin-top: 10px;
}
.custom-nav button {
  background: linear-gradient(135deg, #5e2ced, #4821c3);
  color: #fff;
  border: none;
  padding: 10px 20px;
  margin: 0 10px;
  border-radius: 30px;
  cursor: pointer;
  font-weight: bold;
  transition: background 0.3s, transform 0.3s;
}
.custom-nav button:hover {
  background: linear-gradient(135deg, #4821c3, #35189f);
  transform: translateY(-2px);
}

/* Owl Carousel Nav Buttons – hide built-in if not used */
.owl-nav {
  display: none !important;
}

/* Responsive */
@media (max-width: 1024px) {
  .service-item {
    height: 330px;
  }
}
@media (max-width: 768px) {
  .service-item {
    height: 300px;
  }
  .service-item h3 {
    font-size: 18px;
  }
}
@media (max-width: 480px) {
  .service-item {
    height: auto;
  }
  .service-item h3 {
    font-size: 16px;
  }
  .service-item p {
    font-size: 12px;
  }
}
</style>


<script>
  $(document).ready(function () {
    // Initialize Owl Carousel
    var serviceSlider = $(".services-slider").owlCarousel({
      loop: false,
      margin: 20,
      nav: false, // Disable default owl nav since using custom
      autoplay: true,
      autoplayTimeout: 4000,
      autoplayHoverPause: true,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 2
        },
        1024: {
          items: 3
        }
      }
    });

    // Custom navigation
    $('.custom-next').click(function () {
      serviceSlider.trigger('next.owl.carousel');
    });

    $('.custom-prev').click(function () {
      serviceSlider.trigger('prev.owl.carousel');
    });
  });
</script>
