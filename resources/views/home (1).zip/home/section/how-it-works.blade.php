<section class="page-section how-it-works">
  <div class="container">
    <h2 class="section-title">
      How Does Our Expert <span>Online Assignment</span> Help Works in Uk?
    </h2>

    <div class="content-wrapper">
      <!-- Left Side: YouTube Video -->
      <div class="video-column">
        <iframe
            src="https://www.youtube.com/embed/_TDbpVaGHVU?si=ecaPEaMEz6EYzlnq" 
            title="How It Works Video"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen>
        </iframe>
      </div>

      <!-- Right Side: All Steps -->
      <div class="steps-column">
        <div class="step">
          
          <h3><span class="step-number">1. </span> Enter Your Details</h3>
          <p>Fill in the 'order now' form and mention your basic information and specific requirements that you want us to meet.</p>
        </div>

        <div class="step">
          
          <h3><span class="step-number">2. </span> Make Secure Payment</h3>
          <p>Pay an affordable price for the assignment help via our secure payment gateway that protects your privacy.</p>
        </div>

        <div class="step">
        
          <h3>   <span class="step-number">3. </span> Receive Your Learning Resource</h3>
          <p>Receive a well-researched learning resource crafted by our academic guides within your deadline to aid your understanding.</p>
        </div>

        <a href="https://www.assignnmentinneed.com/upload-your-assignment">
          <button class="place-order-btn">Place Order</button>
        </a>
      </div>
    </div>
  </div>
</section>

<style>
.how-it-works {
  padding: 2rem 1.5rem;
  background: #fff;
  text-align: center;
}

/*  */

/* Main 2-column layout */
.content-wrapper {
  display: flex;
  gap: 40px;
  align-items: flex-start;
  justify-content: center;
  flex-wrap: wrap;
}

/* Video section */
.video-column {
  flex: 1;
  min-width: 300px;
  max-width: 600px;
  text-align: center;
}
.video-column iframe {
  width: 100%;
  height: 315px;
  border-radius: 12px;
}

/* Steps section */
.steps-column {
  flex: 1;
  max-width: 600px;
  text-align: left;
}

.step {
  margin-bottom: 30px;
}

.step-number {
  font-size: 28px;
  color: #5e2ced;
  font-weight: bold;
  display: inline-block;
  margin-bottom: 8px;
}

.step h3 {
  font-size: 22px;
  margin: 8px 0;
  color: #333;
}

.step p {
  font-size: 16px;
  color: #555;
  line-height: 1.6;
}

/* Button Styling */
/*  */

/* Responsive Design */
@media (max-width: 768px) {
  .content-wrapper {
    flex-direction: column;
    align-items: stretch;
    gap: 20px;
  }
  .step-number {
    font-size: 24px;
  }

  .step h3 {
    font-size: 20px;
  }

  .step p {
    font-size: 14px;
  }


  .video-column iframe {
    height: 250px;
  }
}

@media (max-width: 480px) {
  .step-number {
    font-size: 20px;
  }

  .step h3 {
    font-size: 18px;
  }

  .step p {
    font-size: 13px;
  }

  .place-order-btn {
    width: 200px;
    font-size: 13px;
    padding: 8px;
  }

  .video-column iframe {
    height: 200px;
  }
}
</style>
