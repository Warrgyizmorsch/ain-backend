<section class="page-section why-choose-us">
    <div class="container">
        <h2 class="section-title">Key Features & Benefits of Our<span> Assignment Help</span> for UK & International
            Students</h2>
        <p class="section-description">Unlock the key benefits of our assignment help with the security of our <a
                href="GuaranteedPolicy ">guarantees</a> designed for your academic success.</p>
        <div class="features-grid">
            <!-- Feature Box 1 -->
            <div class="feature-box" data-aos="fade-up">
                <div class="feature-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <div class="heading-text">
                    <h3>24/7 Assignment Assistance</h3>
                </div>
                <div class="paragraph-text">
                    <p>Our trained support agents are on standby 24/7 to assist you, whether you're studying in the UK
                        or internationally. No matter the hour, real-time help is just a message away.</p>
                </div>
            </div>
            <!-- Feature Box 2 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="100">
                <div class="feature-icon">
                    <i class="fa fa-check-circle"></i>
                </div>
                <div class="heading-text">
                    <h3>Plagiarism-Free Content</h3>
                </div>
                <div class="paragraph-text">
                    <p>Our experts provide completely original, custom-tailored assignment support according to the
                        students' needs. Every resource is built from scratch and checked with premium plagiarism tools
                        to ensure 100% originality.
                    </p>
                </div>
            </div>

            <!-- Feature Box 3 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="200">
                <div class="feature-icon">
                    <i class="fa fa-truck"></i>
                </div>
                <div class="heading-text">
                    <h3>On-Time Submissions</h3>
                </div>
                <div class="paragraph-text">
                    <p>We never miss deadlines. Our professional writers are trained to deliver your completed
                        assignments early — giving you enough time for personal review and revision. Reliability and
                        punctuality are key to our service promise.</p>
                </div>
            </div>

            <!-- Feature Box 4 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="300">
                <div class="feature-icon">
                    <i class="fa fa-refresh	"></i>
                </div>
                <div class="heading-text">
                    <h3>Free Unlimited Revisions</h3>
                </div>
                <div class="paragraph-text">
                    <p>If you need any changes after delivery, we’ve got you covered. We offer unlimited revision
                        support — completely free — until your final draft aligns with your academic goals and personal
                        satisfaction.</p>
                </div>
            </div>

            <!-- Feature Box 5 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="400">
                <div class="feature-icon">
                    <i class="fa fa-money"></i>
                </div>
                <div class="heading-text">
                    <a href="/pricing">
                        <h3>Student-Friendly Pricing</h3>
                    </a>
                </div>
                <div class="paragraph-text">
                    <p>Quality support shouldn’t cost a fortune. We offer budget-conscious pricing, exclusive discounts
                        for first-timers and returning users, and flexible plans to ensure academic help remains
                        affordable for all students.</p>
                </div>
            </div>

            <!-- Feature Box 6 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="500">
                <div class="feature-icon">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div class="heading-text">
                    <a href="/PrivacyPolicy">
                        <h3>Full Privacy and Confidential</h3>
                    </a>
                </div>
                <div class="paragraph-text">
                    <p>We strictly safeguard your data. Every detail — from your personal info to your assignment brief
                        — stays confidential. Our data protection practices meet global standards for student privacy
                        and online trust.
                    </p>
                </div>
            </div>
            <!-- Feature Box 7 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="500">
                <div class="feature-icon">
                    <i class="fas fa-edit"></i>
                </div>
                <div class="heading-text">
                    <a href="/writers">
                        <h3>Experienced Writers</h3>
                    </a>
                </div>
                <div class="paragraph-text">
                    <p>Our team features UK academic professionals and international experts, all equipped with deep
                        subject knowledge. Whether you follow UK university standards or study abroad, we’ve got the
                        expertise you need.
                    </p>
                </div>
            </div>
            <!-- Feature Box 8 -->
            <div class="feature-box" data-aos="fade-up" data-aos-delay="500">
                <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="heading-text">
                    <a href="/upload-your-assignment">
                        <h3>Secure & Flexible Payment</h3>
                    </a>
                </div>
                <div class="paragraph-text">
                    <p>We use trusted payment systems like PayPal, Stripe, and verified bank options. All transactions
                        are encrypted for safety, letting you choose the method that fits your convenience and keeps
                        your details secure.</p>
                </div>
            </div>
        </div>
</section>
<!-- ........mobile view  -->
<div class="mobile-slider">
    <div class="slider-track">
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fas fa-headset"></i>
            </div>
            <h3>24/7 Assignment Assistance </h3>
            <p>Our trained support agents are on standby 24/7 to assist you, whether you're studying in the UK or
                internationally. No matter the hour, real-time help is just a message away.</p>
        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fa fa-check-circle"></i>
            </div>
            <h3>Plagiarism-Free Content</h3>
            <p>Our experts provide completely original, custom-tailored assignment support according to the students
                needs. Every resource is built from scratch and checked with premium plagiarism tools to ensure 100%
                originality.</p>

        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fa fa-truck"></i>
            </div>
            <h3>On-Time Submissions</h3>
            <p>We never miss deadlines. Our professional writers are trained to deliver your completed assignments early
                — giving you enough time for personal review and revision. Reliability and punctuality are key to our
                service promise.</p>
        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fa fa-refresh	"></i>
            </div>
            <h3>Free Unlimited Revisions</h3>
            <p>If you need any changes after delivery, we’ve got you covered. We offer unlimited revision support —
                completely free — until your final draft aligns with your academic goals and personal satisfaction.</p>
        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fa fa-money"></i>
            </div>
            <a href="/pricing">
                <h3>Student-Friendly Pricing</h3>
            </a>
            <p>Quality support shouldn’t cost a fortune. We offer budget-conscious pricing, exclusive discounts for
                first-timers and returning users, and flexible plans to ensure academic help remains affordable for all
                students.
            </p>
        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fas fa-user-shield"></i>
            </div>
            <a href="/PrivacyPolicy">
                <h3>Full Privacy and Confidential</h3>
            </a>
            <p>We strictly safeguard your data. Every detail — from your personal info to your assignment brief — stays
                confidential. Our data protection practices meet global standards for student privacy and online trust.
            </p>

        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fas fa-edit"></i>
            </div>

            <a href="/writers">
                <h3>Experienced Writers</h3>
            </a>
            <p>Our team features UK academic professionals and international experts, all equipped with deep subject
                knowledge. Whether you follow UK university standards or study abroad, we’ve got the expertise you need.
            </p>

        </div>
        <div class="feature-box card-mobile-view">
            <div class="feature-icon">
                <i class="fas fa-shield-alt"></i>
            </div>
            <a href="/upload-your-assignment">
                <h3>Secure & Flexible Payment</h3>
            </a>
            <p>We use trusted payment systems like PayPal, Stripe, and verified bank options. All transactions are
                encrypted for safety, letting you choose the method that fits your convenience and keeps your details
                secure.</p>

        </div>
    </div>

    <!-- Navigation buttons -->
    <button class="slider-btn prev">&#10094;</button>
    <button class="slider-btn next">&#10095;</button>
</div>
<!-- ................................ -->

<style>
    /* ......................... */

    /* Hide mobile slider by default */

    .mobile-slider {
        display: none;
    }

    /* Mobile-only styles */
    @media (max-width: 767px) {
        .features-grid {
            display: none !important;
            /* Hide desktop grid on mobile */
        }

        .mobile-slider {
            display: block;
            position: relative;
            width: 100%;
            height: 400px;
            padding: 8px;
            overflow: hidden;
            /* Changed to hidden to prevent cards from overflowing */
        }

        .slider-track {
            margin-top: 35px;
            display: flex;
            transition: transform 0.3s ease-in-out;
            width: 100%;
            /* Ensure track takes full width */
        }

        .mobile-slider .feature-box {
            flex: 0 0 calc(100% - 20px);
            /* Account for margins */
            box-sizing: border-box;
            padding: 20px;
            background: linear-gradient(135deg, #3F159A, #0E8FCE);
            margin: 0 10px;
            /* 10px margin on each side */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        }

        .slider-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background-color: rgba(0, 0, 0, 0.6);
            color: white;
            border: none;
            padding: 12px 16px;
            font-size: 18px;
            border-radius: 50%;
            cursor: pointer;
            z-index: 10;
        }

        .slider-btn.prev {
            left: 10px;
        }

        .slider-btn.next {
            right: 10px;
            /* Adjusted to positive value to stay within bounds */
        }

        .feature-icon {
            max-width: 80px;
            height: 75px;
            font-size: 50px;
        }
    }

    /* .............................. */
    .feature-box h3 {
        font-size: 20px;
        margin-bottom: 10px;
        font-weight: bold;
        color: white;
    }

    .feature-box p {
        font-size: 14px;
    }

    .heading-text {
        margin-top: -50px;
    }

    .paragraph-text {
        margin-top: 5px;
        /* text-align: justify; */

    }

    /* General Section Styling */

    /* Features Grid */
    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 30px;
        max-width: 1150px;
        margin: 0 auto;
    }

    /* Feature Box */
    .feature-box {
        background: linear-gradient(135deg, #3F159A, #0E8FCE);
        color: white;
        padding: 15px;
        border-radius: 10px;
        text-align: center;
        transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        animation: fadeInUp 1s ease-in-out;
        margin-top: 20px;
    }

    .feature-box:hover {
        transform: translateY(-10px);
        box-shadow: 0px 15px 25px rgba(0, 0, 0, 0.2);
    }

    /* Feature Icon */
    .feature-icon {
        font-size: 30px;
        margin-bottom: 10px;
        background: white;
        color: rgb(30 0 90);
        display: inline-block;
        padding: 15px;
        border-radius: 100%;
        position: relative;
        top: -50px;
        width: 80px;
        height: 80px;
        background: #fffafa;
        border: 11px double;
    }

    /* Animations */
    

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @media (max-width: 1024px) {
        .features-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 768px) {
        .features-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .feature-box {
            padding: 20px;
        }

        .feature-icon {
            font-size: 25px;
            height: 80px;
            width: 80px;
        }

        .feature-box h3 {
            font-size: 18px;
        }

        .feature-box p {
            font-size: 14px;
        }
    }

    @media (max-width: 480px) {



            .feature-box {
                padding: 15px;
            }

            .feature-icon {
                font-size: 30px !important;

            }
       

        .feature-box h3 {
            font-size: 16px;
        }

        .feature-box p {
            font-size: 12px;
        }
    }
</style>

<!-- Include AOS (Animate on Scroll) for additional smooth animations -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true
    });
</script>


<!-- mobile view card javascript -->
<script>
    const sliderTrack = document.querySelector('.slider-track');
    const slides = document.querySelectorAll('.mobile-slider .feature-box');
    const nextBtn = document.querySelector('.slider-btn.next');
    const prevBtn = document.querySelector('.slider-btn.prev');

    let currentIndex = 0;

    function updateSlider() {
        if (slides.length === 0) return; // Prevent errors if no slides
        const slideWidth = slides[0].offsetWidth + 20; // Include margin (10px left + 10px right)
        sliderTrack.style.transform = `translateX(-${slideWidth * currentIndex}px)`;
    }

    // Initialize slider
    updateSlider();

    // Navigation
    nextBtn.addEventListener('click', () => {
        if (currentIndex < slides.length - 1) {
            currentIndex++;
            updateSlider();
        }
    });

    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updateSlider();
        }
    });

    // Recalculate on resize
    window.addEventListener('resize', updateSlider);
</script>
<!-- ...................................................... -->

</section>