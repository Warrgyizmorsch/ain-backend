


<div class="services-section">
    <div class="container">
    <h2 class="section-title">Assignment in Need – Your <span>Best Online Assignment </span> Help with Guaranteed Excellence!</h2>
    <p class="section-description">At Assignment in Need, we understand the daily struggles students face throughout their academic journey. It's not just about writing assignments; it's about managing exam preparations, part-time jobs, extracurricular activities, and so much more. These responsibilities often take away valuable time and leave little room for hobbies or personal interests.</p>
    <div class="services-slider-container">
        <button class="prev-btn" onclick="moveServiceSlide(-1)">&#10094;</button>
        <div class="services-slider" id="servicesSlider">
            @for ($i = 1; $i <= 13; $i++)
                <div class="service-card">
                    <img src="/images/service{{$i}}.jpg" alt="Service {{$i}}" class="service-img">
                    <h3 class="service-title">Service {{$i}}</h3>
                    <p class="service-description">High-quality service description goes here.</p>
                </div>
            @endfor
        </div>
        <button class="next-btn" onclick="moveServiceSlide(1)">&#10095;</button>
    </div>
</div>
</div>

<style>
    .services-section {
        text-align: center;
        padding: 50px 20px;
    }
    .services-slider-container {
        position: relative;
        max-width: 1000px;
        margin: auto;
        overflow: hidden;
    }
    .services-slider {
        display: flex;
        width: 1300%;
        transition: transform 0.5s ease-in-out;
    }
    .service-card {
        background: white;
        padding: 20px;
        margin: 10px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        flex: 0 0 20%;
        text-align: center;
    }
    .service-img {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        margin-bottom: 10px;
    }
    .prev-btn, .next-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
        border: none;
        padding: 10px;
        cursor: pointer;
    }
    .prev-btn { left: 10px; }
    .next-btn { right: 10px; }
    .prev-btn:hover, .next-btn:hover {
        background-color: black;
    }
</style>

<script>
    let serviceIndex = 0;
    function moveServiceSlide(step) {
        const slides = document.querySelectorAll(".service-card");
        const slider = document.getElementById("servicesSlider");
        serviceIndex = (serviceIndex + step + slides.length) % slides.length;
        slider.style.transform = `translateX(${-serviceIndex * 20}%)`;
    }
    setInterval(() => moveServiceSlide(1), 3000);
</script>
