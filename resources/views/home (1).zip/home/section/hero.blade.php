<section class="bg-hero">
    <div class="container-section">
        <div class="hero-content">
            <!-- Content Column -->
            <div class="content-column">
                <h1 class="main-heading">Online Assignment Help Services for UK & International Students</h1>
                <div class="content-paragraph">
                    <p>
                        UK university-standard assignment help - empowering students worldwide with confidence and
                        originality.
                    </p>
                </div>

                <div class="content-list-item">
                    <ul class="content-list">
                        <li>UK academic standards, trusted by students</li>
                        <li>24/7 expert support from UK-based writers</li>
                    </ul>
                    <ul class="content-list">
                        <li>Harvard, APA, MLA and OSCOLA referencing</li>
                        <li>UK grading & global academic alignment</li>
                    </ul>
                </div>

                <div class="Trusted-paragraph">
                    <p>Trusted by over <b>5,000&nbsp;students</b> for assignment help</p>
                </div>

                @include('components.review-section')
            </div>

            <!-- Form Column -->
            <div class="form-column">
                <div class="form-container">
                    @include('new-form')
                </div>
            </div>
        </div>
    </div>

    <!-- Internal CSS -->
    <style>
        .bg-hero {
            background: url(/images/background/home-bg.png) no-repeat center center;
            background-size: cover;
            padding: 3rem 2rem;
            box-shadow: rgba(0, 0, 0, 0.06) 0px 2px 4px inset;
        }

        .container-section {
            max-width: 1200px;
            margin: auto;
            padding: 0 1rem;
        }
        .form-container {
            margin: auto;
            display: flex;
            justify-content: center;
        }

        .hero-content {
            display: flex;
            flex-direction: row;
            gap: 2rem;
        }

        .content-column {
            animation-duration: 1.2s;
            animation-fill-mode: both;
        }

        .content-column {
            animation-name: slideInLeft;
        }

        .form-column {
            animation-name: slideInRight;
        }

        .main-heading {
            background: linear-gradient(to bottom, #3F159A, #0E8FCE);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-size: 3rem;
            font-weight: 900;
            line-height: 1.3;
        }

        .content-paragraph p {
            font-size: 1.1rem;
            text-align: justify;
            color: #000;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .content-list-item {
            display: flex;
            flex-direction: row;
            gap: .5rem;
        }

        .content-list {
            padding-left: 20px;
        }

        .content-list li {
            color: #333;
            list-style-type: square;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }

        .Trusted-paragraph {
            margin-top: 1rem;
            font-size: 1rem;
            font-weight: 500;
        }


        /* Animations */
        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-50px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(50px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        /* Responsive */
        @media (max-width: 768px) {

            .hero-content {
                flex-direction: column;
            }

            .main-heading {
                font-size: 3rem;
            }

            .content-paragraph p {
                font-size: 1rem;
                text-align: left;
            }
        }

        @media (max-width: 600px) {
            .bg-hero {
                padding: 1.5rem 1rem;
            }

            

            .content-list-item {
                flex-direction: column;
            }

            .main-heading {
                font-size: 1.8rem;
            }
        }
    </style>
</section>