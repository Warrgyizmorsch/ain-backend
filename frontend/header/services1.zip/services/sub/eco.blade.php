@extends('frontend-layouts.app')

@section('content')


<style>
		.text {
			color: #0c0d24;
			line-height: 1.8em;
			font-size: 16px;
		}
		.text-black{
			color: black;
			
		}
		.banner-section-three .content-column .inner-column {
			padding-top: 5px;
		}
		
	</style>
	<style>
		.iti {
			position: relative;
			display: inline-block;
			width: 100%;
		}
	</style>
	 <!-- new code of conclusion -->
       <style>
		.conclsn{
			padding: 70px 0px ;
            
		}
	   </style>
	  <!-- end new code of conclusion -->
	<style>
		.header-section 
		{
			background: rgb(255,255,255);
			background: linear-gradient(170deg, rgba(255,255,255,1) 6%, rgba(135,166,219,0.4009978991596639) 72%, rgba(135,166,219,0.5690651260504201) 91%, rgba(126,137,221,0.865983893557423) 100%);
		}

		h1 {
			font-size: 35px;
			font-weight: 600;
			color: black
			}

		p {
			position: relative;
			line-height: 1.8em;
			font-size: large;
			color:black;
			text-align: justify;
		}
		.place-order 
		{
			background:#d7f0fd; 
			color:black;
			padding: 10px 20px;
			border-radius: 5%;
			margin: 10px;
		}
		.place-now
		{
			background:#77bfe5; 
			color:black;
			padding: 20px 80px;
			border-radius: 3%;
			margin: 10px;
			font-weight: 500;
			font-size: 20px;
		}
		.place-order:hover
		{
			background:#7e89dd;
			color:white ;

		}
		.place-now:hover
		{
			box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;			
			color: white;
			transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */

		}
		.order-now		
		{
			font-size: 25px;
			font-weight: 500;	
			color: black;
		}

		.offer-badge {
		    position: absolute;
			top: -65px;
			right: -30px;
			color: white;
			font-weight: bold;
			border-radius: 10%;
			font-size: 17px;
			z-index: 0;
		}
		.banner-stats-title
		{
			font-size: 30px;
			font-weight: 600;
			color: black;
		}
		.banner-stats-container {
			display: flex;
			justify-content: space-between;
			text-align: center;
		}

		.banner-stat {
			flex: 1;
			padding: 0 10px; /* Adjust the space between elements */
		}

		.banner-stats-text {
			font-size: 1em;
			margin-top: 5px;
		}
		
		ul 
		{
			font-size: 17px;
			color: black;
		}

		h3 
		{
			font-size: 21px;
			font-weight: 500;
			color: black;
		}

		@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

			.image-container {
				width: 50%;
			}

			.text-content {
				width: 50%;
				margin-left: 40px;
			}

			.text-content h2 {
				font-size: 2rem;
			}
		}

		.current_offer
		{
			font-weight: bold;
			font-size: 35px;
		}

		.offer-container
		{
			background: rgb(221,245,245);
			background: -moz-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: -webkit-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5",endColorstr="#6ebae7",GradientType=1);
						background-color: white; 
			border-radius: 
			5px; 
			box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); 
			padding: 20px;
		}

		@media (min-width: 1200px) {
    .container {
        max-width: 1199px;
    }
}
	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}
	.offer-badge-offer:hover{

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
				transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
    padding: 0px 0px 0px;
}
</style>

<style>
	.popular-subjects-section {
  background-color: #f9f9f9;
  padding: 40px 20px;
}

.popular-subjects-section .container {
  max-width: 1200px;
  margin: 0 auto;
}

/* Heading Styles */
.popular-subjects-section .heading {
  font-size: 2rem;
  font-weight: 700;
  color: #222;
  margin-bottom: 20px;
}

/* Description Styles */
.popular-subjects-section .description {
  font-size: 1.1rem;
  color: #555;
  margin-bottom: 30px;
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;
}

/* Subject List Styling */
.popular-subjects-section .subject-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  list-style: none;
  padding: 0;
  margin: 0;
  gap: 15px;
}

.popular-subjects-section .subject-list li {
  margin: 5px;
  display: inline-block;
  padding: 10px 20px;
  background-color: #007bff;
  color: #fff;
  text-decoration: none;
  border-radius: 30px;
  font-size: 1rem;
  transition: background-color 0.3s ease;
  
}

.popular-subjects-section .subject-list li a {
	text-decoration: none;
	color: #fff;

}

.popular-subjects-section .subject-list li a:hover {
  /* background-color: #0056b3; */
}

/* Button Styling */
.popular-subjects-section .show-more-btn {
  display: inline-block;
  margin-top: 30px;
  padding: 10px 20px;
  font-size: 1rem;
  color: #007bff;
  background-color: #fff;
  border: 2px solid #007bff;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.popular-subjects-section .show-more-btn:hover {
  background-color: #007bff;
  color: #fff;
}
</style>
	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">

				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center"> Get Expert Online Economic Assignment Help | Economic Homework Help For Students Worldwide
						</h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Rating</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
				
			@include('formsection')
			</section>
			<section class="news-section-two py-3 mt-3">
		<div class="auto-container">
			<div class="row clearfix">
				<div class="col-md-12 col-md-offset-2">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center my-4">How Our Economic Assignment and Homework Help Services Work for Students?</h2>
					
				</div>
				<div class="blocks-column col-lg-12 col-md-12 col-sm-12 mt-2">
					<div class="inner-column">
						<div class="row clearfix p-2">
							<div class="column col-lg-4 col-md-4 col-sm-12 ">
								<div class="news-block-four mt-0">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/shopping-list.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Start Your Assignment</a></h3>
										<div class="text">Fill in the “Order Now” form, providing your key details and outlining exactly what you need from your assignment.</div>
										
									</div>
								</div>
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="150ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 150ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/secure-payment.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Process Your Payment Securely</a></h3>
										<div class="text">Pay a competitive price through our advanced payment system, designed to keep your details confidential.
										</div>
									</div>
								</div>
								
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/sharing.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Get the Assignment Done</a></h3>
										<div class="text">
										Get a well-crafted assignment, delivered on time by our experienced writers, ensuring results that surpass your expectations.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>



	<!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/Offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Our Writer -->

	<!-- Our Writer -->
	  @if($data['expert']->isEmpty())
    
@else
    <!-- Case: Experts are available -->
    <section class="testimonial-section-three py-0">
        <div class="color-layer"></div>
        <div class="auto-container">
            <div class="sec-title">
                <div class="section-color-layer"></div>
                <h2 style="font-weight:500; font-size: 30px; color:black">
                  Our Writer For Online Economic Assignment Help Service<
                </h2>
            </div>
            <div class="testimonial-carousel-three owl-carousel owl-theme">
                @foreach($data['expert'] as $expert)
                    <!-- Testimonial Block Three -->
                    <div class="testimonial-block-three">
                        <div class="inner-box">
                            <div class="image-outer">
                                <div class="image">
                                    <img src="{{$expert->image}}" alt="Expert Image" />
                                </div>
                                <div class="quote flaticon-left-quote"></div>
                            </div>
                            <h6>{{$expert->name}}</h6>
                            <div class="designation" style="
                                color: blue !important;
                                margin: 0 auto;
                                text-align: center;
                                width: auto;
                                padding: 5px 15px;
                                border-radius: 20px;
                                font-size: 20px;
                                font-weight: 700;">
                                {{$expert->service}} Writing Help
                            </div>
                            <div class="text" style="text-align: justify; margin-top: 10px;">
                                <span class="short-content">
                                    {{ Str::limit($expert->content, 150) }}
                                </span>
                                <span class="full-content" style="display: none;">
                                    {{$expert->content}}
                                </span>
                                <button class="btn-toggle" onclick="toggleContent(this)" style="
                                    margin-top: 5px;
                                    border: none;
                                    background-color: transparent;
                                    color: #007BFF;
                                    cursor: pointer;">
                                    ...
                                </button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="lower-text">Click the button for slide</div>
        </div>
    </section>
@endif

	<script>
    function toggleContent(button) {
        const textContainer = button.parentElement;
        const shortContent = textContainer.querySelector('.short-content');
        const fullContent = textContainer.querySelector('.full-content');

        if (shortContent.style.display === 'none') {
            shortContent.style.display = '';
            fullContent.style.display = 'none';
            button.textContent = '...';
        } else {
            shortContent.style.display = 'none';
            fullContent.style.display = '';
            button.textContent = 'Less';
        }
    }
</script>


    <!--Assignment Writing Help In  Economic -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Online Economic Assignment Writing Help Services For Students</h2>
                           <p> Are you someone who needs economics assignment help? Is it because you struggle with your economics classes which makes it difficult for you to tackle your homework and assignments?
                           </p>
							 <p>The focus of economics on how people and business behave in an economy makes it an important part of social sciences. And it is really important for students to develop logical, theoretical, and analytical skills to understand such complex economics concepts and topics. 
                             </p>
                            <p>But sometimes traditional classroom teaching alone isn't enough. That's where Assignment In Need comes in. Who are we? We are an educational platform that helps students excel in subjects like economics. Our team of economics experts prioritizes your academic success. Whether you need assistance with assignments or are struggling to understand tough concepts, We are here to help you succeed with economics assignment help.</p>
                            
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our Economic Assignment Writing service today and enjoy a special discount!</h2>
							<p>Get help with your economic assignments writing easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>
	<!--Why You Need Economic Assignment Help -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why You Need Economic Assignment Help</h2>
                           
                          <p>With part-time jobs to cover living expenses, balancing work, studies, and other responsibilities can be tough and stressful for any student in today's day and age. And it is normal to look for economics assignment help when managing coursework deadlines and the fast paced life seems a little difficult.</p>
							 <p>Additionally when you take expert economics assignment help online, you also get quality assurance, personalized support , and a deeper understanding of the world of economics. This can boost your academic confidence, learning pace, and even academic success. </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
    <!--Our Economic Assignment Help Services -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Benefits Of Our Economic Assignment Help Services For Students</h2>
                           
                           <p>We at Assignment In Need have made sure that you get the best possible economic assignment help online. This is the reason why we have made significant investments in recruiting top economic experts from worldwide to ensure that every assignment is crafted and customized based on your needs.</p>
						   <p>But we don't just stop at that, each and every assignment goes through multiple quality checks and reviews by our quality control team in economics. The assignment gets approved only after it meets all criteria.</p>
						   <p>Some of our economic assignment help services include:</p>
						   <p><b>Custom Economic Assignment Writing:</b> Every economics assignment is specifically tailored to meet your needs by our team of expert writers. We at Assignment In Need provide well-researched and original content of highest academic quality be it an essay, research paper or just a case study.</p>
						   <p><b>Economic Assignment Editing and Proofreading: </b>We have a rigorous editing and proofreading process where we focus on structure, grammar, and formatting to improve clarity and coherence to make sure your assignments are error-free and polished.</p>
                           <p><b>24/7 Economic Assignment Support: </b> We have a dedicated support team who are available 24/7 to answer all of your questions and “someone please do my economics assignment” moments because we understand that deadlines can be stressful. We provide updates on your assignments, and offer assistance whenever you need it.</p>

                        
 
  
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

    <!-- How Our Economic Assignment Help Stands Out -->
    <section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">How Our Economic Assignment Help Stands Out</h2>
                            <p>If you ever think, 'I need someone to write my economics assignment,' then our economics assignment help online is here for you. But why choose us? Here's why:</p>
                           <p><b>Experienced Economic Assignment Help Experts: </b> Our team consists of experienced professionals who know economics inside out. They ensure your assignments not only meet academic standards but also show a strong grasp of economic concepts.</p>

                           <p><b>Affordable Economic Assignment Help Online: </b>  Worried about burning a hole in your pocket? Don't worry, we offer budget-friendly prices and exciting offers for our <a href="https://www.assignnmentinneed.com/assignment-writing-help-services"><b>assignment writing help</b></a>. Currently, we are offering 40% off to new users. You can check for more such offers here at <a href="https://www.assignnmentinneed.com/"><b>Assignment in Need Offers</b></a>.
						   </p>

                           <p><b>Timely Delivery of Economic Assignments Help: </b>  Don't worry about missing deadlines, we understand how important deadlines can be. This is the reason why our assignment expert economics dissertation helps make sure to deliver your economic assignments on time, no matter how tight the deadline or complex the task may be	.
						   </p>
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="popular-subjects-section">
  <div class="container text-center">
    <h2 class="heading">Most Popular Subjects We Handle for Economics Assignment Help and Economics Homework Help</h2>
    <p class="description">
	Get expert help with Economics assignments and homework help. Our team of specialists ensures you grasp even the toughest concepts of economics. 98% of students report better grades after using our services.
    </p>
    <ul class="subject-list">
      <li><a href="https://www.assignnmentinneed.com/microeconomics-assignment-help">Microeconomics Assignment Help</a></li>
      <li><a href="https://www.assignnmentinneed.com/macroeconomics-assignment-help">Macroeconomics Assignment Help</a></li>
      <li>International Economics Assignment Help</li>
	  <li>Development Economics Assignment Help</li>
	  <li>Public Economics Assignment Help</li>
	  <li>Behavioral Economics Assignment Help</li>
    </ul>
    <button class="show-more-btn" id="more-subject">Show More</button>
  </div>
</section>

<script>
  document.getElementById("more-subject").addEventListener("click", function () {
    const subjectList = document.querySelector(".subject-list");
    const showMoreBtn = document.getElementById("more-subject");

    const moreSubjects = [
     
      '<li>Environmental Economics Assignment Help</li>',
      '<li>Labor Economics Assignment Help</li>',
      '<li>Health Economics Assignment Help</li>',
      '<li>Financial Economics Assignment Help</li>',
	  '<li><a href="https://www.assignnmentinneed.com/econometrics-assignment-help">Econometrics Assignment Help</a></li>',
      '<li>Agricultural Economics Assignment Help</li>'
    ];

    if (showMoreBtn.textContent === "Show More") {
      subjectList.innerHTML += moreSubjects.join("");
      showMoreBtn.textContent = "Show Less";
    } else {
      const currentSubjects = subjectList.querySelectorAll("li");
      // Remove the extra subjects
      for (let i = currentSubjects.length - 1; i >= 6; i--) {
        currentSubjects[i].remove();
      }
      showMoreBtn.textContent = "Show More";
    }
  });
</script>
       
    <!-- What Makes Us A Reliable Economics Assignment Writing Service? -->
    <section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">What Makes Assignment in Need A Reliable Economics Assignment Help Service in the World?</h2>
                           
                            <p>Even with years of study economics can be quite complex. Our assignment expert economics at Assignment In Need provides unique economic assignment help online that can help you understand core concepts. Below are some of the few reasons why you should choose us for your economics homework help and assignment help
							</b></p>
                
                             <p><b>Originality Guarantee: </b> A cornerstone of our online economics assignment help is originality. Our experts use their deep subject knowledge and experience to ensure each assignment is unique and is written from scratch. </p>
                             <p><b>Plagiarism-Free Work: </b> Assignment In Need knows how important originality is in academic work. So, every economics assignment that we deliver is written from scratch, ensuring it's 100% unique and according to your requirements. Our team uses advanced plagiarism detection tools to double-check all the details so that you can submit your assignment with confidence. Academic integrity is always our top priority.</p>
                             <p><b>High-Quality Assignments: </b> Our writing standards are exceptional and have helped countless students. Your economic assignment undergoes rigorous checks to ensure it is clear, impactful, informative, and flawless</p>
          
							 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

     <!--How to Get Started with Economic Assignment Help -->
     <section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">How to Get Started with Economic Assignment Help</h2>

							 <p> Submitting your assignment is quick and easy with our user-friendly website. If you need help with an economic assignment, simply upload your requirements on our site. Once submitted, we will review it and provide you with a price quote that fits your budget, based on your specific needs and the assignment's complexity.                 
                             </p>

                             <p> Next, we will match your assignment with one of our highly qualified economic experts who specializes in your field to ensure you receive the best assistance possible. The expert will then create a customized, step-by-step solution or detailed explanation tailored to your assignment needs. 
                             </p>

                             <p> If you require further assistance, we offer one-on-one tutoring sessions and additional resources to help you understand the concepts better and improve your economic skills.
                             </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


	<section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Top-Notch Economics Essay Writing Help For Students</h2>

							<p>Choosing our economics essay help online means more than just finishing your essay. It helps you truly understand how economics works. We’re here to help if you ever find yourself thinking, "I need someone to write my economics assignment,"</p>

                            <p>We aim to help you not only achieve short-term academic success but also develop a deep appreciation for economics dissertation help. Whether you're dealing with basic concepts or advanced topics, our services are personalized to meet your specific learning needs.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">ECONOMICS ASSIGNMENT HELP: Your Gateway to Top-Quality Online Economics Assignment Help</h2>
                            
							<p>Mathematical models, intricate theories, and practical applications make economics homework challenging. It frequently takes a great deal of time and effort to comprehend these ideas. Without the right support, taking microeconomics classes or writing an economics dissertation might be frightening.</p>
							<p>Expert guidance provides direction and makes complex topics easier to grasp. Your coursework, dissertations, and other economics-related projects can be helped by experts. This assistance might improve your academic performance as well as your comprehension of the material.</p>
							<p>Professional assistance gives you access to excellent materials that are suited to your academic requirements.</p>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">How Economics Connects to Other Subjects and Fields</h2>
                            
							<p>Economics is concerned with the forces that mold markets, influence policies, and direct resource allocation in societies. The study of how choices are made and resources are distributed forms the framework for understanding complex modern economies. Economics, being highly interlinked with other subjects, makes a multidisciplinary approach toward solving real-world challenges.</p>
							<h3>Statistics: Enhancing Quantitative Analysis in Economics</h3>
							<p>Quantitative analysis forms the core of economics and concepts from <a href="https://www.assignnmentinneed.com/statistics-assignment-writing-help"><b>Statistics assignment help</b></a> have a significant role to play in the interpretation of data and modelling of economic behavior. Starting from analyzing consumer trends to forecasting market movements, statistical tools help economists make decisions that are evidence-based. Techniques like regression analysis, probability, and hypothesis testing become indispensable in developing precise predictions and strategies for economics.</p>
								<h3>Business: Exploring Market Strategies and Organizational Dynamics</h3>
								<p>Economics finds practical application in business. The insight gained through <a href="https://www.assignnmentinneed.com/business-assignment-writing-help"><b>business assignment help</b></a> enriches the study of market strategies, organizational behavior, and financial management. Business depends on economic principles for optimizing its operations, predicting consumer behavior, and assessing the influence of market trends. A combination of economics with business studies would provide students with a more profound understanding of how economic theories translate into real strategies in the corporate world.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
  
	<section class="instructor-section">
	<div class="auto-container">
		<div class="row clearfix">
			<div class="instructor-column col-lg-6 col-md-12 col-sm-12">
				<h2 style="font-weight:500; font-size: 30px; color:black" class="text-start my-4">
					Get Well-Written Assignments in 3 Simple Steps
				</h2>
				<div class="inner-column wow fadeInRight animated" data-wow-delay="0ms" data-wow-duration="1500ms"
					style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInRight;">
					<div class="feature-inner">
						<div class="row">
							<div class="col-2 mt-4">
								<div class="icon"
									style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
									<span
										style="font-size: 39px; color: #04aef3; border: 3px dashed #04aef3; border-radius: 50%; padding: 10px; display: inline-block; text-align: center; width: 50px; height: 50px;">
										1
									</span>
								</div>
							</div>
							<div class="col-10">
								<h3 style="margin: 10px 0; font-size: 20px; font-weight: bold;">Explore Assignment Samples</h3>
								<p style="margin: 0; line-height: 1.6; font-size: 16px; color: black;">
									Explore a variety of free academic samples to understand the quality of work we provide. Each sample showcases the level of detail and research that goes into our assignments.
								</p>
							</div>
						</div>
 
						<div class="row">
							<div class="col-2 mt-4">
								<div class="icon"
									style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
									<span
										style="font-size: 39px; color: #04aef3; border: 3px dashed #04aef3; border-radius: 50%; padding: 10px; display: inline-block; text-align: center; width: 50px; height: 50px;">
										2
									</span>
								</div>
							</div>
							<div class="col-10">
								<h3 style="margin: 10px 0; font-size: 20px; font-weight: bold;">Get Popular Subjects for Math Assignment Help And Math Homework Help</h3>
								<p style="margin: 0; line-height: 1.6; font-size: 16px; color: black;">
									Pick the sample that best matches your assignment type and subject. This will give you a clear idea of how we approach different topics and formats.
								</p>
							</div> 
						</div>
   
						<div class="row">
							<div class="col-2 mt-4">
								<div class="icon"
									style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
									<span
										style="font-size: 39px; color: #04aef3; border: 3px dashed #04aef3; border-radius: 50%; padding: 10px; display: inline-block; text-align: center; width: 50px; height: 50px;">
										3
									</span>
								</div>
							</div>
							<div class="col-10">
								<h3 style="margin: 10px 0; font-size: 20px; font-weight:bold">Download Your Sample</h3>
								<p style="margin: 0; line-height: 1.6; font-size: 16px; color: black;">
									Click the download button to get your chosen sample in PDF instantly. You can review it at your own pace and use it as a reference for your assignment.
								</p>
							</div>
						</div>
					</div>
				</div>
				<div style="text-center" class="mt-4">
					<a href="/upload-your-assignment"><button class=" place-now " style="padding: 10px 20px; color:white">Order Assignment</button></a>
				</div>
			</div>

			<div class="instructor-column col-lg-6 col-md-12 col-sm-12">
				<h2 style="font-weight:500; font-size: 30px; color:black" class="text-start my-4">
					8000+ Samples Reflect the High Standard of Our Work
				</h2>
				@foreach ($data['sample'] as $sample )
				<div class="inner-column wow fadeInRight animated" data-wow-delay="0ms" data-wow-duration="1500ms"
					style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInRight;">
				
					<div class="row">
						<div class="col-2 mt-4">
							<div class="icon"
								style="display: flex; align-items: center; justify-content: flex-start; margin-bottom: 10px;">
								<a href="free-samples/{{$sample->categotyData->name}}/{{$sample->slug}}">
								<img src="images/image.png" style="width: 60px; height: 120px; box-shadow:rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px" alt="">
								</a>
							</div>
						</div>
						<div class="col-10 mb-4">
							<h3 style="margin: 10px 0; font-size: 20px; font-weight: bold;"><a style="color:black" href="free-samples/{{$sample->categotyData->name}}/{{$sample->slug}}">{{$sample->title}}</a></h3>
							<p style="margin: 0; line-height: 1; font-size: 15px; color: #0000008a; font-weight: 700; box-shadow:">
								#{{$sample->categotyData->name}}
							</p>
							@php
								$pageCount = ceil(str_word_count(strip_tags($sample->content)) / 250);
							@endphp
							<div><p class="samplefeature"><span>Number of pages: <b>{{$pageCount}}</b></span> <span>Total Words: <b>{{ str_word_count(strip_tags($sample->content)) }}</b></span></p></div>
						</div>
					</div>
				</div>
			
				@endforeach
				<div style="text-center" class="mt-4" >
					<a href="/free-samples"><button class=" place-now " style="padding: 10px 20px; color:white">View More Sample</button></a>
				</div>
			</div>
			
			</div>
		
	</div>
</section>

	<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Key Areas of Economics Assignments and Homework Where We Offer Expert Help for Students</h2>
                             <p>The vast areas of economics often require specialized knowledge and skills to understand thoroughly.</p>
							  <p>Below are the main topics in economics assignments where expert help can ensure academic success.</p>
							 <h3>Microeconomics Assignment Help</h3>
							 <p>Microeconomics homework help focuses on studying individual agents such as households, companies, and industries within an economy. It looks at how these agents interact with each other. The key areas include analyzing supply and demand. Additionally, it explores consumer behavior and how these elements interact. For students who are having trouble understanding concepts like elasticity, utility, or cost functions, professional assistance may provide clarity and ensure well-researched, well-structured papers.</p>
							 <h3>Macroeconomics Assignment Help</h3>
							  <p>Students can better understand the larger economy by using macroeconomics assignment aid. It addresses issues including fiscal policy, unemployment, inflation, and national income. These subjects can be complex for many students. However, with the right guidance, mastering these concepts becomes much easier. This support helps in creating coursework that blends theoretical ideas with practical aspects of economic policy. It ensures a deeper understanding and builds confidence in tackling challenging macroeconomic topics.</p>
							 <h3>Managerial Economics Assignment Help</h3>
							 <p>Managerial economics focuses on applying economic theories to business decision-making processes. It helps in understanding how companies decide on pricing, production, and competitiveness in the market. One key aspect of managerial economics homework solver is analyzing these decision-making processes in depth. Students often seek guidance to grasp how economic principles are used in real-world scenarios. Expert assistance can provide valuable insights, helping students gain a competitive edge in their coursework and better understand practical applications.</p>
							 <h3>Econometrics Assignment Help</h3>
							 <p>Econometrics involves using statistics, economics, and mathematics to analyze economic data. This field often requires understanding complex methods like regression analysis and hypothesis testing. Students working on econometrics assignments may face challenges with these statistical techniques. Seeking expert assistance can provide valuable guidance for handling data analysis. Specialists can help simplify the process, ensuring students achieve accurate results. This support can be crucial for understanding complex topics and improving assignment quality.</p>
							 <h3>Development Economics Assignment Help</h3>
							 <p>Improving the economic situation in developing nations is the primary objective of development economics. Its main goal is to identify strategies for reducing poverty and strengthening economies. Students often struggle with complex concepts in this field. These include globalization, poverty, inequality, and economic growth. These topics are complex and require thorough analysis and guidance. With the assistance of professionals, students can gain a deeper comprehension of these concepts and write superior papers that explore answers to economic issues in developing countries.</p>
							 <h3>International Economics Assignment Help</h3>
							  <p>Understanding how nations engage with one another through trade, investment, and policy requires an understanding of international economics help. This field revolves around issues including exchange rate regimes, international trade theories, and comparative advantage. Writing persuasive essays and research papers on international economic subjects requires students to be able to analyze global economic processes, which can be facilitated by expert assistance when wondering to write my economics essay.</p>
							 <h3>Environmental Economics Assignment Help</h3>
							 <p>Environmental economics examines the financial effects of sustainability, natural resource usage, and environmental regulations by fusing economic analysis with environmental concerns. Expert guidance in environmental economics helps students understand difficult ideas like carbon taxes, externalities, and market-based environmental solutions, resulting in comprehensive and perceptive projects.</p>
							 <h3>Labor Economics Assignment Help</h3>
							  <p>Labor economics focuses on studying labor markets, wages, and employment. Labor economics helps examine how government policies impact working conditions. This branch of economics explores the relationship between employers and employees. It also analyzes how labor supply and demand influence wages and workplace conditions. Professional coaching helps students understand labor economics theories better. It allows them to apply these concepts to real-world problems effectively during their education.</p> 
							</div>
					</div>
				</div>
			</div>
		</div>
	</section>
        

	<section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Assignment in Need Stands Out as the Best Academic Research Paper Help and Essay Help Platform</h2>
                            
							<p>When it comes to academic support, economics homework help online is made easy with Assignment in Need. We are one of the top platforms for students seeking assistance in economics. Our services stand out because we focus on delivering high-quality support tailored to individual needs. Students trust us for a variety of reasons. Whether you need economics research paper help, economics essay help, or general guidance, we provide reliable solutions.</p>
                              <p>No matter the size of your project, Assignment in Need will handle it with great care. Whether it's big or small, we ensure the highest standards.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


	<section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Economics Coursework Help Designed for Your Academic Success</h2>
                            
							<p>It can be difficult to navigate through economics coursework help because it frequently calls for comprehending intricate economic ideas and using them in practical contexts. You may simplify your coursework and generate high-quality work with professional aid, regardless of whether you are having trouble with theoretical frameworks, statistical analysis, or writing an extensive essay.</p>
						    <p>By choosing economics coursework help, you are investing in your academic success. Our experts simplify complex economic principles for you. They ensure you understand the basics and build a strong foundation. This support helps you achieve excellent results and boosts your confidence. With their guidance, tackling coursework becomes more manageable and rewarding.</p>	
						  	</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Get Top-Quality Economics Homework Help from PhD Experts</h2>
                            
							 <p>We at Assignment in Need offer trustworthy economics homework help.   We have specialists with PhDs on our team. Numerous students have benefited from these professionals' assistance in completing their academic work. They cover various economics topics to ensure top-quality assistance.</p>
							 <p>We are here to help whether you need macroeconomics homework help or microeconomics homework help. Our professionals provide concise, detailed assistance to make difficult subjects easier to understand. With their help, you can understand even the most difficult economics concepts. Let us help you achieve academic success with personalized guidance.</p>
							</div>
					</div>
				</div>
			</div>
		</div>
	</section>


	<section class="py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Choose Our PhD Experts for Online Homework Help?</h2>
                            <p>Selecting our economics homework help puts you in contact with highly skilled experts who can tackle even the most challenging issues. We are here to help, whether you need economics hw help, economics essay help, or econ homework help.  Our professionals provide trustworthy and customized advice to satisfy your academic requirements. With our help, handling complex economics topics becomes easier. We provide the right tools to help you succeed in your studies. Let us make economics more manageable and help you excel.</p>
							<p>Although it can be very difficult, economics is an interesting subject. It might be overwhelming to comprehend ideas and apply them to actual issues. Completing assignments in this field may require extra support. This is where Assignment in Need can help</p>
							<p>Don't let economics assignments overwhelm you. Get individualized help that meets your needs. We offer prompt and high-quality assistance to ensure your academic success. Our team is ready to support you in tackling complex concepts and completing assignments efficiently.</p>
							</div>
					</div>
				</div>
			</div>
		</div>
	</section>



     <!-- new code of conclusion -->
  
	 <!-- new section -->

	 <section class="py-4" style="background-color:#BFECFF;"  >
	            <div class="auto-container">
                    <div class="row clearfix">

			<!-- Content Column -->
			  <div class="content-column col-lg-6 col-md-12 col-sm-12">
				 <div class="inner-column">
					<h2 class="py-3" style="font-weight:500; font-size: 30px; color:black">Economic Assignment Writing Help Services Online By Assignment in Need Worldwide</h2>
					  <div class="text">
						 <p>At Assignment in Need, the focus is on providing exceptional economic assignment writing help to students. With 45,000+ assignments delivered and 98.2% of orders arriving timely, the platform ensures reliability and quality. Whether students are in Canada, the UAE, the UK, Malaysia, Spain, or Australia, each assignment is crafted with careful attention to meet academic requirements. A team of experienced economics experts delivers well-researched, original content that aligns with academic standards. Understanding the pressures of tight deadlines and other tasks, Assignment in Need offers 24/7 support to assist students whenever needed. For reliable, affordable, and timely economics assignment help, they are a trusted partner in achieving academic success.</p>
						</div>
					 
			          <a href="/upload-your-assignment"> <button style="background: #37AFE1;  color:black; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >Order Now</button> </a>	 
			     </div>
			 </div>

			<!-- Image Column -->
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">
					 <div class="image titlt"  style="mix-blend-mode: multiply;">
						<img src="images2\resource\unnamed (5).png  " alt="">  
					</div>        
				</div>
			</div>

		</div>
	</div>
            </section>

           
       
 <!-- FAQs Question  section for Expert Assignment Writing Help -->
 
	        
 <section class="faq-section bg-light">
	    	<div class="auto-container">
			<div class="row ">
				<div class="titel-column col-lg-12 col-md-12 col-sm-12">
				    <div class="title-box text-center">
						<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4"><b>Frequently Asked Questions For Economic Assignment Writing Help</b></h2> 
					 </div>
					<div class="row"> 
					 		 
				<div class="column col-lg-6 col-md-6 col-sm-12 ">
					 
					<ul class="accordion-box ">
					       <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">1. What is Economic Assignment Help?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                         <P>Economic assignment help is support for students in topics like international economics, microeconomics, macroeconomics, and others. It helps students understand these subjects better and complete their assignments on time.</P>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">2. Why should I choose your Economic Assignment Help services?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                         <P>We provide original content by tailoring each assignment and thoroughly checking for plagiarism. You can select your expert based on their qualifications and area of expertise. You'll work directly with your expert to customize your assignment precisely. Our thorough editing process ensures your work is clear, logical, and well-structured. Plus, we offer unlimited revisions to make sure the final product meets your academic requirements perfectly.</P>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">3. How do I request Economic Assignment Help?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <P>You can request economics assignment help online through our email <b>INFO@ASSIGNNMENTINNEED.COM</b>  or by clicking the submit button on our website.</P>
										</div>
                                    </div>
                                </div>
                            </li>
							 
						 
                  	</ul>
					
				</div>
			
				<div class="column col-lg-6 col-md-6 col-sm-12">
					 
					<ul class="accordion-box">
					       <li class="accordion block"> 
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">4. What types of economic assignments can you help with?<div class="icon fa fa-angle-down"></div></div>
                                  <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Assignment In Need helps with different areas of economics. We cover International Economics (trade between nations and global policies), Microeconomics (individual consumer and firm behavior), Macroeconomics (big economic factors like inflation and unemployment), Developmental Economics (growth in low-income countries), Environmental Economics (impact of environmental policies), Health Economics (healthcare systems and funding), and Labor Economics (employment trends and wages).</p>
										</div>
                                    </div>
                                  </div>
                            </li>
							<li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">5. How long does it take to get my economic assignment completed?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <P>Our main goal is to complete your assignment as quickly as possible. We typically deliver it a day before your deadline. In cases where deadlines are tight, such as a 3-day delivery, you can expect to receive your work on either the second or third day.</P>
										</div>
                                    </div>
                                </div>
                            </li>
							<li class="accordion block">
                                <div class="acc-btn bg-white border" style="font-weight:500; font-size: 20px;; color:black">6. How can I contact you for further questions about Economic Assignment Help?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                         <p>You can contact us in three different ways, first by email INFO@ASSIGNNMENTINNEED.COM . Call us on +44 2037695831, or just WhatsApp Number +44 7435256433.</p>
										</div>
                                    </div>
                                </div>
                            </li>
						
					 
						 
					
					</ul>
					
				</div>
				 
				 
			     </div>
				   <div class="title-box text-center">
				   <a href="https://www.assignnmentinneed.com/faqs/economics-assignment-faqs" style="background: #37AFE1;  color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >View More FAQs</a>
				   </div> 

				</div> 
				 
 			</div>
			  
		</div>
		 
   </section> 
          
@endsection