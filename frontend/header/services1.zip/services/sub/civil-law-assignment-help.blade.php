  
 @extends('frontend-layouts.app')

@section('content')


<style>
		.text {
			color: #0c0d24;
			line-height: 1.8em;
			font-size: 16px;
		}
		.text-black{
			color: black;
			
		}
		.banner-section-three .content-column .inner-column {
			padding-top: 5px;
		}
		
	</style>
	<style>
		.iti {
			position: relative;
			display: inline-block;
			width: 100%;
		}
	</style>

	<style>
		.header-section 
		{
			background: rgb(255,255,255);
			background: linear-gradient(170deg, rgba(255,255,255,1) 6%, rgba(135,166,219,0.4009978991596639) 72%, rgba(135,166,219,0.5690651260504201) 91%, rgba(126,137,221,0.865983893557423) 100%);
		}

		h1 {
			font-size: 35px;
			font-weight: 600;
			color: black
			}

		p {
			position: relative;
			line-height: 1.8em;
			font-size: large;
			color:black;
			text-align: justify;
		}
		.place-order 
		{
			background:#d7f0fd; 
			color:black;
			padding: 10px 20px;
			border-radius: 5%;
			margin: 10px;
		}
		.place-now
		{
			background:#77bfe5; 
			color:black;
			padding: 20px 80px;
			border-radius: 3%;
			margin: 10px;
			font-weight: 500;
			font-size: 20px;
		}
		.place-order:hover
		{
			background:#7e89dd;
			color:white ;

		}
		.place-now:hover
		{
			box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;			
			color: white;
			transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */

		}
		.order-now		
		{
			font-size: 25px;
			font-weight: 500;	
			color: black;
		}

		.offer-badge {
		    position: absolute;
			top: -65px;
			right: -30px;
			color: white;
			font-weight: bold;
			border-radius: 10%;
			font-size: 17px;
			z-index: 0;
		}
		.banner-stats-title
		{
			font-size: 30px;
			font-weight: 600;
			color: black;
		}
		.banner-stats-container {
			display: flex;
			justify-content: space-between;
			text-align: center;
		}

		.banner-stat {
			flex: 1;
			padding: 0 10px; /* Adjust the space between elements */
		}

		.banner-stats-text {
			font-size: 1em;
			margin-top: 5px;
		}
		
		ul 
		{
			font-size: 17px;
			color: black;
		}

		h3 
		{
			font-size: 21px;
			font-weight: 500;
			color: black;
		}

		@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

			.image-container {
				width: 50%;
			}

			.text-content {
				width: 50%;
				margin-left: 40px;
			}

			.text-content h2 {
				font-size: 2rem;
			}
		}

		.current_offer
		{
			font-weight: bold;
			font-size: 35px;
		}

		.offer-container
		{
			background: rgb(221,245,245);
			background: -moz-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: -webkit-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5",endColorstr="#6ebae7",GradientType=1);
						background-color: white; 
			border-radius: 
			5px; 
			box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); 
			padding: 20px;
		}

		@media (min-width: 1200px) {
    .container {
        max-width: 1199px;
    }
}
	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}
	.offer-badge-offer:hover{

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
				transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
    padding: 0px 0px 0px;
}
      /* Assignment Writing */
	</style>
	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">
					<!-- <li><a href="/">Home</a></li>
					<li>Math Assignment</li> -->
				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center">Get the Best Civil Law Homework Help | Civil Law Online </h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Ratting</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
				
			@include('formsection')
			</section>


		<section class="news-section-two py-3 mt-3">
		<div class="auto-container">
			<div class="row clearfix">
				<div class="col-md-12 col-md-offset-2">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center my-4">How Our do Civil Law Assignment Help Service Work?</h2>
					<!-- <p class="textCommon text-center">How Our Quality Assignment Writing Services Work  in Assignment ?</p> -->
				</div>
				<div class="blocks-column col-lg-12 col-md-12 col-sm-12 mt-2">
					<div class="inner-column">
						<div class="row clearfix p-2">
							<div class="column col-lg-4 col-md-4 col-sm-12 ">
								<div class="news-block-four mt-0">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/shopping-list.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Submit Your Order</a></h3>
										<div class="text">Fill in the 'order now' form, mention your basic information and specific requirements that you want us to meet.</div>
										
									</div>
								</div>
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="150ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 150ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/secure-payment.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Make Secure Payment</a></h3>
										<div class="text">Pay an affordable price for the assignment help provided to you via our secure payment gateway that is fully protected from privacy infringements.</div>
									</div>
								</div>
								
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/sharing.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Receive Your Paper</a></h3>
										<div class="text">
											Get a high-quality assignment writing services by our expert writers within the given deadline and score better than your expectations.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/Offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Our Writer -->
 @if($data['expert']->isEmpty())
    
@else
    <!-- Case: Experts are available -->
    <section class="testimonial-section-three py-0">
        <div class="color-layer"></div>
        <div class="auto-container">
            <div class="sec-title">
                <div class="section-color-layer"></div>
                <h2 style="font-weight:500; font-size: 30px; color:black">
                Our Writer For Civil Law Assignment help
                </h2>
            </div>
            <div class="testimonial-carousel-three owl-carousel owl-theme">
                @foreach($data['expert'] as $expert)
                    <!-- Testimonial Block Three -->
                    <div class="testimonial-block-three">
                        <div class="inner-box">
                            <div class="image-outer">
                                <div class="image">
                                    <img src="{{$expert->image}}" alt="Expert Image" />
                                </div>
                                <div class="quote flaticon-left-quote"></div>
                            </div>
                            <h6>{{$expert->name}}</h6>
                            <div class="designation" style="
                                color: blue !important;
                                margin: 0 auto;
                                text-align: center;
                                width: auto;
                                padding: 5px 15px;
                                border-radius: 20px;
                                font-size: 20px;
                                font-weight: 700;">
                                {{$expert->service}}
                            </div>
                            <div class="text" style="text-align: justify; margin-top: 10px;">
                                <span class="short-content">
                                    {{ Str::limit($expert->content, 150) }}
                                </span>
                                <span class="full-content" style="display: none;">
                                    {{$expert->content}}
                                </span>
                                <button class="btn-toggle" onclick="toggleContent(this)" style="
                                    margin-top: 5px;
                                    border: none;
                                    background-color: transparent;
                                    color: #007BFF;
                                    cursor: pointer;">
                                    ...
                                </button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="lower-text">Click the button for slide</div>
        </div>
    </section>
@endif

	<script>
    function toggleContent(button) {
        const textContainer = button.parentElement;
        const shortContent = textContainer.querySelector('.short-content');
        const fullContent = textContainer.querySelector('.full-content');

        if (shortContent.style.display === 'none') {
            shortContent.style.display = '';
            fullContent.style.display = 'none';
            button.textContent = '...';
        } else {
            shortContent.style.display = 'none';
            fullContent.style.display = '';
            button.textContent = 'Less';
        }
    }
</script>
    <!-- Online Civil Law Assignment Help Services For Students -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Online Civil Law Assignment Help Services For Students</h2>
                             <p><a href="https://www.assignnmentinneed.com"><b>Assignment in Need</b></a> focuses on civil law assignment help for students in the UK. We offer support on many civil law topics. For extra assistance, civil law homework help is available to ensure you succeed in your studies.</p>
                            </div>
					</div>
				</div>
			</div>
		</div>
	</section>
       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our Civil Law Assignment Help today and enjoy a special discount!</h2>
							<p>Get help with your assignments easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>


    <!-- Expert Assistance for Your Civil Law Assignments Online -->
       <section>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12 ">
                    <div class="inner-column">
                        <div class="titlebox">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Expert Assistance for Your Civil Law Assignments Online</h2>
                            <p>Need help with civil law assignments? We are here for you. Understanding complex ideas can be tough, but we make it simpler. For those needing extra support, civil law help is available to ensure success. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       </section>

       <!-- How to Find Trustworthy Help for Civil Law Assignments? -->
        <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">How to Find Trustworthy Help for Civil Law Assignments?</h2>
                                <p>Choosing good help can be tricky. You need a service that has reliable professionals. Many students talk about our commitment to getting work done well and on time. For those seeking more personalized guidance, civil legal advice is available to ensure clarity in complex legal matters.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Why Opt for Our Civil Law Homework Assistance? -->
         <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Opt for Our Civil Law Homework Assistance?</h2>
                                <p>Choosing our help means you get great work. Service comes tailored just for you, and deadlines matter to us. We take care of that too. For additional support, law homework help is available to ensure your success.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </section>

         <!-- Secure Top Grades with Professional Civil Law Assignment Support -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Secure Top Grades with Professional Civil Law Assignment Support</h2>
                                <p>Experts on our team assist you in getting high grades. They provide solutions that meet all needs for your <a href="https://www.assignnmentinneed.com/law-assignment-writing-help"><b>law assignment help</b></a> . For additional support, civil law help is available to guide you through every step.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </section>

          <!-- Key Civil Law Topics Covered by Our Experts -->
           <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Key Civil Law Topics Covered by Our Experts</h2>
                                <p>Experts on our team handle many civil law topics. Whatever your assignment is, we've got the knowledge to support you. For deeper understanding, civil law case study help is available to guide you through complex cases and scenarios.</p>
                                <h3>Contract Law </h3>
                                <p>In-depth help on contract law comes from our experts. Key concepts such as formation, performance, and enforcement of contracts get full attention. Understanding these topics can feel overwhelming, but we are here for you.</p>
                                <h3>Tort Law</h3>
                                <p>Help with tort law assignments is what we provide. Understanding the ins and outs of tort law can be tricky. For those needing further assistance, civil law help is available to make these concepts clearer.</p>
                                <h3>Property Law</h3>
                                <p>Property law includes many topics. You find issues like property rights, ownership, and laws about land here. Our expert assistance makes things clearer. For more in-depth understanding, civil legal advice is available to guide you through these complex concepts.</p>
                                <h3>Family Law</h3>
                                <p>Family law touches on legal issues with marriage, divorce, child custody, and the like. You might find these topics complicated, but that's where we step in. For those needing more detailed assistance, civil law case study help is available to navigate these complex situations. </p>
                                <h3>Commercial Law</h3>
                                <p>Commercial law covers the rules for businesses. Understanding these rules can get complicated. For additional guidance, civil law help is available to ensure a deeper understanding of these complex areas.</p>
                                <h3>Employment Law</h3>
                                <p>Need help with employment law assignments? We are here to assist you. Topics include worker rights, contracts, and labor disputes. For further clarity, civil legal advice is available to help you navigate these complex areas of law.</p>
                                <h3>Consumer Protection</h3>
                                <p>Experts on our team help you understand consumer protection laws.  Many find these regulations confusing, but we clarify them. For deeper insights, civil law case study help is available to guide you through the complexities of these laws</p>
                                <h3>Trusts and Estates</h3>
                                <p>Managing assets after someone passes away? That's what trusts and estates are all about. Confused about all the legal stuff? Our team helps students make sense of it. </p>
                                <h3>Human Rights Law</h3>
                                <p>Human rights law aims to protect freedoms and rights of individuals. Many find this area important but complex. For those needing further assistance, civil law case study help is available to guide you through real-life applications of these principles.</p>
                                <h3>International Civil Law</h3>
                                <p>International civil law deals with legal matters that go beyond one country's borders. Issues like trade, treaties, and international disputes fall under this umbrella. </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           </section>
	  
           <!-- Advantages of Choosing Our Civil Law Homework Services -->
            <section>
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="title-column col-lg-12 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <div class="title-box">
                                    <div class="section-color-layer"></div>
                                    <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Advantages of Choosing Our Civil Law Homework Services</h2>
                                    <p>Choosing our civil law homework services gives you many benefits. Professional help makes a big difference in your work. You receive content that is 100% original, so no worries about plagiarism. For additional assistance, civil law homework help is available to ensure the highest quality in your assignments.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Why Is Civil Law Homework Help Essential for Modern Students? -->
             <section>
                <div class="auto-container">
                    <div class="row learfix">
                        <div class="title-column col-lg-12 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <div class="title-box">
                                    <div class="section-color-layer"></div>
                                    <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Is Civil Law Homework Help Essential for Modern Students?</h2>
                                    <p>Need help with civil law homework? It's essential for students to keep up with complex legal concepts. With our expert support, civil law homework help is available to ensure you stay on track and succeed.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             </section>

             <!-- Why Students Trust Our Civil Law Homework Writing Help Services? -->
              <section>
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="title-column col-lg-12 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <div class="title-box">
                                    <div class="section-color-layer"></div>
                                    <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Students Trust Our Civil Law Homework Writing Help Services?</h2>
                                    <p>Students rely on our services because we have a strong track record. Trust comes from working with qualified experts who know their stuff. Commitment to delivering quality work drives us every day. For those needing extra assistance, civil law homework help is available to ensure success in every assignment.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              </section>



      <!-- new section -->

	 <section class="py-4" style="background-color:#BFECFF;"  >
	            <div class="auto-container">
                    <div class="row clearfix">

			<!-- Content Column -->
			  <div class="content-column col-lg-6 col-md-12 col-sm-12">
				 <div class="inner-column">
					<h2 class="py-3" style="font-weight:500; font-size: 30px; color:black">Assignment in Need Help With Civil Law Assignment Help and Homework Help For Students Worldwide </h2>
					  <div class="text">
					  <p>Tackle your civil law assignments with confidence! Assignment In Need offers comprehensive Civil Law Assignment Help, covering tort law, contract disputes, and property laws for students across the UK, Canada, Australia, Malaysia, UAE, Spain and more. With 3,000+ PhD experts and a reputation for delivering 45,000+ assignments, we ensure accurate, timely solutions that boost your grades. Whether you're dealing with case studies or theoretical challenges, we are here to simplify your learning experience. </p>
                    </div>
					 
			          <a href="/upload-your-assignment"> <button style="background: #37AFE1;  color:black; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >Order Now</button> </a>	 
			     </div>
			 </div>

			<!-- Image Column -->
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">
					 <div class="image titlt"  style="mix-blend-mode: multiply;">
						<img src="images2\resource\unnamed (5).png  " alt="">  
					</div>        
				</div>
			</div>

		</div>
	</div>
            </section>

            <!-- end new section -->
 
	    <!-- FAQs Question  section for Expert Assignment Writing Help -->
 
	        
		<section class="faq-section bg-light">
	    	<div class="auto-container">
			<div class="row ">
				<div class="titel-column col-lg-12 col-md-12 col-sm-12">  
				    <div class="title-box text-center">
						<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4"><b>Frequently Asked Questions For Civil Law Assignment Help </b></h2> 
					 </div>
					<div class="row"> 
					 		 
				<div class="column col-lg-6 col-md-6 col-sm-12 ">
					 
					<ul class="accordion-box ">
					       <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">1. What Is Civil Law Assignment Help?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <p>We offer expert assistance just for that. Students can find high-quality solutions here. Research plays a big role in understanding complex topics. </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">2. Who Are the Experts Providing Assistance?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Our team includes qualified professionals who know civil law well. Experience shapes their understanding and skills. </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            
                  	</ul>
					
				</div>
			
				<div class="column col-lg-6 col-md-6 col-sm-12">
					 
					<ul class="accordion-box">
                    <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">3. Can I Get Help with Urgent Assignments?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>We provide support to meet your deadlines. Timely delivery is our goal. No one likes to stress out over late submissions. </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">4. Are Your Services Plagiarism-Free?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Yes, every assignment we deliver is 100% original. You can rest assured knowing your work is unique. We create all content from scratch.</p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">5. What Topics Do You Cover in Civil Law Assignment Help?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Looking for help with various legal topics? We cover contract law, tort law, and property law. Family law also gets our attention, along with commercial la </p>
                                        </div>
                                    </div>
                                </div>
                            </li>
					</ul>
					
				</div>
				 
				 
			     </div>
				   <div class="title-box text-center">
				   <button style="background: #37AFE1;  color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >View More FAQs</button>
				   </div> 

				</div> 
				 
 			</div>
			  
		</div>
		 
   </section> 

	   
@endsection