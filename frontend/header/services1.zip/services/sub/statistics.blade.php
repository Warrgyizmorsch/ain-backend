@extends('frontend-layouts.app')

@section('content')


<style>
		.text {
			color: #0c0d24;
			line-height: 1.8em;
			font-size: 16px;
		}
		.text-black{
			color: black;
			
		}
		.banner-section-three .content-column .inner-column {
			padding-top: 5px;
		}
		
	</style>
	<style>
		.iti {
			position: relative;
			display: inline-block;
			width: 100%;
		}
	</style>

	<style>
		.header-section 
		{
			background: rgb(255,255,255);
			background: linear-gradient(170deg, rgba(255,255,255,1) 6%, rgba(135,166,219,0.4009978991596639) 72%, rgba(135,166,219,0.5690651260504201) 91%, rgba(126,137,221,0.865983893557423) 100%);
		}

		h1 {
			font-size: 35px;
			font-weight: 600;
			color: black
			}

		p {
			position: relative;
			line-height: 1.8em;
			font-size: large;
			color:black;
			text-align: justify;
		}
		.place-order 
		{
			background:#d7f0fd; 
			color:black;
			padding: 10px 20px;
			border-radius: 5%;
			margin: 10px;
		}
		.place-now
		{
			background:#77bfe5; 
			color:black;
			padding: 20px 80px;
			border-radius: 3%;
			margin: 10px;
			font-weight: 500;
			font-size: 20px;
		}
		.place-order:hover
		{
			background:#7e89dd;
			color:white ;

		}
		.place-now:hover
		{
			box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;			
			color: white;
			transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */

		}
		.order-now		
		{
			font-size: 25px;
			font-weight: 500;	
			color: black;
		}

		.offer-badge {
		    position: absolute;
			top: -65px;
			right: -30px;
			color: white;
			font-weight: bold;
			border-radius: 10%;
			font-size: 17px;
			z-index: 0;
		}
		.banner-stats-title
		{
			font-size: 30px;
			font-weight: 600;
			color: black;
		}
		.banner-stats-container {
			display: flex;
			justify-content: space-between;
			text-align: center;
		}

		.banner-stat {
			flex: 1;
			padding: 0 10px; /* Adjust the space between elements */
		}

		.banner-stats-text {
			font-size: 1em;
			margin-top: 5px;
		}
		
		ul 
		{
			font-size: 17px;
			color: black;
		}

		h3 
		{
			font-size: 21px;
			font-weight: 500;
			color: black;
		}

		@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

			.image-container {
				width: 50%;
			}

			.text-content {
				width: 50%;
				margin-left: 40px;
			}

			.text-content h2 {
				font-size: 2rem;
			}
		}

		.current_offer
		{
			font-weight: bold;
			font-size: 35px;
		}

		.offer-container
		{
			background: rgb(221,245,245);
			background: -moz-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: -webkit-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5",endColorstr="#6ebae7",GradientType=1);
						background-color: white; 
			border-radius: 
			5px; 
			box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); 
			padding: 20px;
		}

		@media (min-width: 1200px) {
    .container {
        max-width: 1199px;
    }
}
	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}
	.offer-badge-offer:hover{

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
				transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
    padding: 0px 0px 0px;
}
      
	</style>
	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">
					<li><a href="/">Home</a></li>
					<li>Statistics</li>
				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center"> Statistics Assignment help</h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Ratting</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
			@include('formsection')
			</section>
			<section class="news-section-two py-3 mt-3">
		<div class="auto-container">
			<div class="row clearfix">
				<div class="col-md-12 col-md-offset-2">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center my-4">Our Procedure</h2>
					<p class="textCommon text-center">How Our Quality Assignment Writing Services Work  in Assignment ?</p>
				</div>
				<div class="blocks-column col-lg-12 col-md-12 col-sm-12 mt-2">
					<div class="inner-column">
						<div class="row clearfix p-2">
							<div class="column col-lg-4 col-md-4 col-sm-12 ">
								<div class="news-block-four mt-0">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/shopping-list.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Submit Your Order</a></h3>
										<div class="text">Fill in the 'order now' form, mention your basic information and specific requirements that you want us to meet.</div>
										
									</div>
								</div>
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="150ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 150ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/secure-payment.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Make Secure Payment</a></h3>
										<div class="text">Pay an affordable price for the assignment help provided to you via our secure payment gateway that is fully protected from privacy infringements.</div>
									</div>
								</div>
								
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/sharing.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Receive Your Paper</a></h3>
										<div class="text">
											Get a high-quality assignment writing services by our expert writers within the given deadline and score better than your expectations.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/Offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	 @if($data['expert']->isEmpty())
    
@else
    <!-- Case: Experts are available -->
    <section class="testimonial-section-three py-0">
        <div class="color-layer"></div>
        <div class="auto-container">
            <div class="sec-title">
                <div class="section-color-layer"></div>
                <h2 style="font-weight:500; font-size: 30px; color:black">
                  Our Writer For Online Physics Sociology  Help Service
                </h2>
            </div>
            <div class="testimonial-carousel-three owl-carousel owl-theme">
                @foreach($data['expert'] as $expert)
                    <!-- Testimonial Block Three -->
                    <div class="testimonial-block-three">
                        <div class="inner-box">
                            <div class="image-outer">
                                <div class="image">
                                    <img src="{{$expert->image}}" alt="Expert Image" />
                                </div>
                                <div class="quote flaticon-left-quote"></div>
                            </div>
                            <h6>{{$expert->name}}</h6>
                            <div class="designation" style="
                                color: blue !important;
                                margin: 0 auto;
                                text-align: center;
                                width: auto;
                                padding: 5px 15px;
                                border-radius: 20px;
                                font-size: 20px;
                                font-weight: 700;">
                                {{$expert->service}} Writing Help
                            </div>
                            <div class="text" style="text-align: justify; margin-top: 10px;">
                                <span class="short-content">
                                    {{ Str::limit($expert->content, 150) }}
                                </span>
                                <span class="full-content" style="display: none;">
                                    {{$expert->content}}
                                </span>
                                <button class="btn-toggle" onclick="toggleContent(this)" style="
                                    margin-top: 5px;
                                    border: none;
                                    background-color: transparent;
                                    color: #007BFF;
                                    cursor: pointer;">
                                    ...
                                </button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="lower-text">Click the button for slide</div>
        </div>
    </section>
@endif

	<script>
    function toggleContent(button) {
        const textContainer = button.parentElement;
        const shortContent = textContainer.querySelector('.short-content');
        const fullContent = textContainer.querySelector('.full-content');

        if (shortContent.style.display === 'none') {
            shortContent.style.display = '';
            fullContent.style.display = 'none';
            button.textContent = '...';
        } else {
            shortContent.style.display = 'none';
            fullContent.style.display = '';
            button.textContent = 'Less';
        }
    }
</script>


    <!-- Introduction -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class="  my-4">Introduction
                            </h2>
                             <p>In the academic world, statistics assignment help is particularly important to students who are striving for excellence. Statistics play an essential role in different fields and it is important for students to acquire their knowledge of statistics as a fundamental subject. However, statistics assignments can be challenging, leading many students to seek professional assistance. The importance of professional statistics assignment writing help for students, detailing its scope, application and benefits from expert advice is highlighted in this article.
                             </p>	 
							  
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our assignment service today and enjoy a special discount!</h2>
							<p>Get help with your assignments easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>
         
    <!-- What is Statistics? -->
     <section class='py-0'>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                 <div class="inner-column">
                    <div class="title-box">
                        <div class="section-color-layer"></div>
                        <h2 style="font-weight:500; font-size:30px; color:black" class="my-4">What is Statistics?</h2>
                       <p>Statistics is a branch of mathematics in which the collection, analysis, interpretation and presentation of data are concerned. It helps us to understand complex data sets and make meaningful conclusions in a wide range of areas, thereby facilitating decision making processes.
                       </p>
                    </div>
                 </div>
                </div>
            </div>
        </div>
     </section>
     <!-- Definition and Scope of Statistics -->
      <section class="py-0">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size:30px; color:black" class="my-4">Definition and Scope of Statistics
                            </h2>
                            <p>A wide variety of methods and principles for the analysis of numeric data are included in statistics. The scope includes descriptive statistics, which summarise the data and inferential statistics, which make estimates and inferences concerning a population based on sample size. This discipline is vital in various research and professional fields, enhancing data-driven decision-making.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>
      <!-- Application Areas of Statistics Assignment Help in Various Fields -->
      <section class="py-0">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                 <div class="inner-column">
                    <div class="title-box">
                        <div class="section-color-layer"></div>
                        <h2 style="font-weight:500; font-size:30px; color:black"  class="my-4">Application Areas of Statistics Assignment Help in Various Fields</h2>
                        <h3>Business and Economics </h3>
                        <p>Statistics are used to analyse market trends, forecast economic conditions, and make informed business decisions in business and economics. Get Statistics assignment help for students in these areas ensures that students understand how to apply statistical methods to real world economic problems.
                        </p>
                        <h3>Healthcare and Medicine
                        </h3>
                        <p>By helping to design clinical studies, analysing patient data and improving public health policies, statistics play an important role in healthcare and medicine. Students can effectively handle complex medical data and contribute to the development of healthcare with the help of professional statistical assignment writing help.
                        </p>
                        <h3>Natural Sciences</h3>
                        <p>Statistical analysis of experimental data, validation of scientific theories, and study of environmental change are used in natural sciences. Statistics assignment experts assist students in understanding the concepts of statistics, enabling them to carry out rigorous scientific research.
                        </p>
                        <h3>Marketing and Advertising</h3>
                        <p>Statistical data are essential for measuring campaign effectiveness, understanding consumer behaviour and optimising strategies in the marketing and advertising sector. Best service stats assignment expert can assist students in mastering the statistical techniques essential for a successful career in marketing.
                        </p>
                    </div>
                 </div>
                </div>
            </div>
        </div>
      </section>
      <!-- How Do Statistics Experts Simplify Assignments for Students -->
       <section class="py-0">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size:30px; color:black" class="my-4">How Do Statistics Experts Simplify Assignments for Students</h2>
                         <p>Statistics experts make it easy to carry out tasks by providing concise explanations, step by step solutions and practical case studies. It helps students to understand complex concepts, use appropriate statistical tools and apply them correctly in the context of their assignments. These guidelines will strengthen students' ability to solve problems and increase their confidence in the handling of statistics studies.
                         </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       </section>

       <!-- Enhance Your Academic Journey with Our Statistics Assignment Help -->
       <section class="py-0">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style=" font-weight:500; font-size:30px; color:black" class="my-4">Enhance Your Academic Journey with Our Statistics Assignment Help
                            </h2>
                            <p>You can get statistics assignment help at Assignment In Need. Where we provide comprehensive statistics assignment help designed to support students throughout their studies. Our experts are well aware of the various methods of statistics and have been specially trained to assist students in attaining their academic goals. We make it possible for students to submit high quality assignments that meet their professor's expectations by providing personalised assistance.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       </section>

       <!-- Can You Do My Statistics Assignment For Me? -->
        <section class="py-0">
            <div class="auto-container">
                <div class="row clearfix">
                 <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size:30px; color:black" class="my-4">Can You Do My Statistics Assignment For Me?</h2>
                           <p>Yes, we can! We offer tailored statistics assignment help for students at Assignment In Need. We have a team of experts ready to handle your tasks, ensuring that they are completed in an accurate and timely manner. If you choose our services, you'll be able to focus on other studies while we're taking care of your statistical work.
                           </p>
                        </div>
                    </div>
                 </div>
                </div>
            </div>
        </section>

        <!-- Other Assignment Help Services Offered -->
         <section class="py-0">
            <div class="auto-container">
                <div class="row clearfix">
                  <div class="title-column col-lg-12 col-md-12 col-sm-12 ">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size:30px; color:black" class="my-4">Other Assignment Help Services Offered
                            </h2>
                            <h3>Mathematics
                            </h3>
                            <p>We offer a full range of assistance in the field of mathematics in addition to statistics. In order to ensure that students succeed in their studies, our expert teachers help them comprehend the complexities of mathematical concepts and resolve difficult problems.</p>
                            <h3>Economics
                            </h3>
                            <p>Our economics assignment help covers various topics, from microeconomics to macroeconomics. In order to help students understand the complexities of economic theory and applications, we provide detailed explanations and practical examples.
                            </p>
                        </div>
                    </div>
                  </div>
                </div>
            </div>
         </section>

	  <!-- new section -->

	  <section class="py-4" style="background-color:#BFECFF;"  >
	            <div class="auto-container">
                    <div class="row clearfix">

			<!-- Content Column -->
			  <div class="content-column col-lg-6 col-md-12 col-sm-12">
				 <div class="inner-column">
					<h2 class="py-3" style="font-weight:500; font-size: 30px; color:black">Statistics Assignment Writing Help Online For Students across the Globe</h2>
					  <div class="text">
						 <p>Statistics assignments can be a challenge, leaving many students in Malaysia, Canada, UAE, the UK, Spain, and Australia searching for reliable help. That’s where Assignment In Need steps in with its Statistics assignment writing help, offering comprehensive guidance and valuable resources. With a remarkable 98% recurring client rate and 98.2% of orders arriving on time, their team of skilled statisticians ensures students can master tricky concepts and methods. Each assignment is tailored to meet academic standards, whether it involves descriptive or inferential statistics, providing clear explanations and practical examples. By choosing their service, students gain professional support to handle statistics, balance other courses, and achieve academic success with ease.</p>
						</div>
					 
			          <a href="/upload-your-assignment"> <button style="background: #37AFE1;  color:black; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >Order Now</button> </a>	 
			     </div>
			 </div>

			<!-- Image Column -->
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">
					 <div class="image titlt"  style="mix-blend-mode: multiply;">
						<img src="images2\resource\unnamed (5).png  " alt="">  
					</div>        
				</div>
			</div>

		</div>
	</div>
            </section>

            <!-- end new section -->

      <!-- FAQs Question  section for statistics -->
        <section class="faq-section">
            <div class="auto-container">
                <div class="row clearfix">
                 <div class="column col-lg-12 col-md-12 col-sm-12">
                      <div class="title-box">
                        <h2 style="font-weight:500; font-size:30px; color:black" class="my-4"> Frequently Asked Questions
                        </h2>
                        <ul class="accordion-box">
                            <li class="accordion block">
                                <div class="acc-btn">1. What does Statistics assignments help include?
                                <div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>Statistics assignment help includes assistance with data collection, analysis, interpretation, and presentation. Experts can provide step by step solutions, explanations of statistical methods and instructions for use of statistical software.
                                            </p>
                                        </div>
                                    </div>
                                </div>                          
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn">2. What types of Statistics assignments can I get help with?
                                <div class="icon fa fa-angle-down"></div></div>
                                 <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                            <p>You can get help with various statistics assignments, including descriptive statistics, inferential statistics, probability theory, hypothesis testing, regression analysis, and more.
                                            </p>
                                        </div>
                                    </div>
                                 </div>
                        </li>
                         <li class="accordion block" >
                            <div class="acc-btn">3. How can Statistics assignments help services benefit me?
                            <div class="icon fa fa-angle-down"></div></div>
                             <div class="acc-content">
                                <div class="content">
                                    <div class="text">
                                        <p>Statistics assignment help for students provides a number of benefits, including better understanding of statistics concepts, increased problem solving skills and improved performance in the classroom. Expert advice ensures that you have the confidence and accuracy to deal with these complicated tasks. We offer- 120% Money-Back Guarantee: If We Miss the Delivery Deadline, Including Our Minimal Time Frame, You Get 120% of Your Money Back
                                        </p>
                                    </div>
                                </div>
                             </div>
                         </li>
                         <li class="accordion block">
                            <div class="acc-btn">4. What should I look for in a Statistics assignments help service provider?
                            <div class="icon fa fa-angle-down"></div></div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">
                                        <p>When choosing a statistics assignment help service provider, consider their expertise, experience, and reviews from other students. You will find providers who offer a personalised service, prompt delivery and detailed explanations of statistical methods. If you ask yourself, "Can I get my assignment help from experts?" the answer is yes. Our services are intended to meet all your academic requirements. 
                                        </p>
                                    </div>
                                </div>
                            </div>
                         </li>
                         <li class="accordion block">
                           <div class="acc-btn">5. How do online services provide Statistics assignments help?
                           <div class="icon fa fa-angle-down"></div></div>
                           <div class="acc-content">
                            <div class="content">
                                <div class="text">
                                    <p>Online services provide statistics assignment help via various means, including live tutoring sessions, detailed written solutions and interactive problem solving exercises. The aim of these services is to provide students with flexibility and convenience, irrespective of their geographical location. —---</p>
                                    <p>Assignment In Need is dedicated to providing high-quality, reliable statistics assignment help for students. We ensure that students achieve their academic objectives and become successful in the classroom by applying our expertise and commitment to excellence. </p>
                                     <p>Check out our assignment writing services to further enhance your learning experience for additional academic support.
                                     </p>
                                </div>
                            </div>
                           </div>
                         </li>
                        </ul>
                      </div>
                 </div>
                </div>
            </div>
        </section>

       	 
 
@endsection