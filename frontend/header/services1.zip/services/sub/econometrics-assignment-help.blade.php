  
 @extends('frontend-layouts.app')

@section('content')


<style>
		.text {
			color: #0c0d24;
			line-height: 1.8em;
			font-size: 16px;
		}
		.text-black{
			color: black;
			
		}
		.banner-section-three .content-column .inner-column {
			padding-top: 5px;
		}
		
	</style>
	<style>
		.iti {
			position: relative;
			display: inline-block;
			width: 100%;
		}
	</style>

	<style>
		.header-section 
		{
			background: rgb(255,255,255);
			background: linear-gradient(170deg, rgba(255,255,255,1) 6%, rgba(135,166,219,0.4009978991596639) 72%, rgba(135,166,219,0.5690651260504201) 91%, rgba(126,137,221,0.865983893557423) 100%);
		}

		h1 {
			font-size: 35px;
			font-weight: 600;
			color: black
			}

		p {
			position: relative;
			line-height: 1.8em;
			font-size: large;
			color:black;
			text-align: justify;
		}
		.place-order 
		{
			background:#d7f0fd; 
			color:black;
			padding: 10px 20px;
			border-radius: 5%;
			margin: 10px;
		}
		.place-now
		{
			background:#77bfe5; 
			color:black;
			padding: 20px 80px;
			border-radius: 3%;
			margin: 10px;
			font-weight: 500;
			font-size: 20px;
		}
		.place-order:hover
		{
			background:#7e89dd;
			color:white ;

		}
		.place-now:hover
		{
			box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;			
			color: white;
			transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */

		}
		.order-now		
		{
			font-size: 25px;
			font-weight: 500;	
			color: black;
		}

		.offer-badge {
		    position: absolute;
			top: -65px;
			right: -30px;
			color: white;
			font-weight: bold;
			border-radius: 10%;
			font-size: 17px;
			z-index: 0;
		}
		.banner-stats-title
		{
			font-size: 30px;
			font-weight: 600;
			color: black;
		}
		.banner-stats-container {
			display: flex;
			justify-content: space-between;
			text-align: center;
		}

		.banner-stat {
			flex: 1;
			padding: 0 10px; /* Adjust the space between elements */
		}

		.banner-stats-text {
			font-size: 1em;
			margin-top: 5px;
		}
		
		ul 
		{
			font-size: 17px;
			color: black;
		}

		h3 
		{
			font-size: 21px;
			font-weight: 500;
			color: black;
		}

		@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

			.image-container {
				width: 50%;
			}

			.text-content {
				width: 50%;
				margin-left: 40px;
			}

			.text-content h2 {
				font-size: 2rem;
			}
		}

		.current_offer
		{
			font-weight: bold;
			font-size: 35px;
		}

		.offer-container
		{
			background: rgb(221,245,245);
			background: -moz-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: -webkit-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5",endColorstr="#6ebae7",GradientType=1);
						background-color: white; 
			border-radius: 
			5px; 
			box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); 
			padding: 20px;
		}

		@media (min-width: 1200px) {
    .container {
        max-width: 1199px;
    }
}
	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}
	.offer-badge-offer:hover{

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
				transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
    padding: 0px 0px 0px;
}
      /* Assignment Writing */
	</style>
	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">
					<!-- <li><a href="/">Home</a></li>
					<li>Math Assignment</li> -->
				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center">Reliable Econometrics Homework Help | Econometrics Assignment Help for Students Academic Excellence
						</h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Ratting</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
			@include('formsection')
			</section>


		<section class="news-section-two py-3 mt-3">
		<div class="auto-container">
			<div class="row clearfix">
				<div class="col-md-12 col-md-offset-2">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center my-4">How Our do Econometrics Assignment Help Online Service Work?</h2>
					<!-- <p class="textCommon text-center">How Our Quality Assignment Writing Services Work  in Assignment ?</p> -->
				</div>
				<div class="blocks-column col-lg-12 col-md-12 col-sm-12 mt-2">
					<div class="inner-column">
						<div class="row clearfix p-2">
							<div class="column col-lg-4 col-md-4 col-sm-12 ">
								<div class="news-block-four mt-0">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/shopping-list.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Submit Your Order</a></h3>
										<div class="text">Fill in the 'order now' form, mention your basic information and specific requirements that you want us to meet.</div>
										
									</div>
								</div>
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="150ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 150ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/secure-payment.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Make Secure Payment</a></h3>
										<div class="text">Pay an affordable price for the assignment help provided to you via our secure payment gateway that is fully protected from privacy infringements.</div>
									</div>
								</div>
								
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/sharing.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Receive Your Paper</a></h3>
										<div class="text">
											Get a high-quality assignment writing services by our expert writers within the given deadline and score better than your expectations.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/Offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Our Writer -->
	<!-- Our Writer -->
 @if($data['expert']->isEmpty())
    
@else
    <!-- Case: Experts are available -->
    <section class="testimonial-section-three py-0">
        <div class="color-layer"></div>
        <div class="auto-container">
            <div class="sec-title">
                <div class="section-color-layer"></div>
                <h2 style="font-weight:500; font-size: 30px; color:black">
                Our Writer For  Econometrics  Assignment help
                </h2>
            </div>
            <div class="testimonial-carousel-three owl-carousel owl-theme">
                @foreach($data['expert'] as $expert)
                    <!-- Testimonial Block Three -->
                    <div class="testimonial-block-three">
                        <div class="inner-box">
                            <div class="image-outer">
                                <div class="image">
                                    <img src="{{$expert->image}}" alt="Expert Image" />
                                </div>
                                <div class="quote flaticon-left-quote"></div>
                            </div>
                            <h6>{{$expert->name}}</h6>
                            <div class="designation" style="
                                color: blue !important;
                                margin: 0 auto;
                                text-align: center;
                                width: auto;
                                padding: 5px 15px;
                                border-radius: 20px;
                                font-size: 20px;
                                font-weight: 700;">
                                {{$expert->service}}
                            </div>
                            <div class="text" style="text-align: justify; margin-top: 10px;">
                                <span class="short-content">
                                    {{ Str::limit($expert->content, 150) }}
                                </span>
                                <span class="full-content" style="display: none;">
                                    {{$expert->content}}
                                </span>
                                <button class="btn-toggle" onclick="toggleContent(this)" style="
                                    margin-top: 5px;
                                    border: none;
                                    background-color: transparent;
                                    color: #007BFF;
                                    cursor: pointer;">
                                    ...
                                </button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="lower-text">Click the button for slide</div>
        </div>
    </section>
@endif

	<script>
    function toggleContent(button) {
        const textContainer = button.parentElement;
        const shortContent = textContainer.querySelector('.short-content');
        const fullContent = textContainer.querySelector('.full-content');

        if (shortContent.style.display === 'none') {
            shortContent.style.display = '';
            fullContent.style.display = 'none';
            button.textContent = '...';
        } else {
            shortContent.style.display = 'none';
            fullContent.style.display = '';
            button.textContent = 'Less';
        }
    }
</script>

    <!-- Online Econometrics Assignment Help Services For Students -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class=" my-4">Online Econometrics Assignment Help Services For Students</h2>
                              <p>Econometrics mixes economics, math, and statistics in a unique way. This field studies data to tackle tough problems. Students often face challenges in grasping these concepts and turn to econometrics coursework help to manage their assignments better. At <a href="https://www.assignnmentinneed.com/"><b>Assignment in Need</b></a> , help is readily available. Our team of experts understands the needs of UK students. We aim to make learning easier and more enjoyable. With our support, academic success feels closer and stress tends to fade away. Students find comfort in knowing they are not alone in this journey. Balancing numbers and theories can be tricky, but a helping hand makes things smoother. We strive to empower learners through tailored assistance, including econometrics homework help.</p>
                            </div>
					</div>
				</div>
			</div>
		</div>
	</section>
       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our Econometrics Assignment Help Online today and enjoy a special discount!</h2>
							<p>Get help with your assignments easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>
	  
    <!-- Get Expert Help with Your Econometrics Homework Help for Academic Success -->
     <section>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4" >Get Expert Help with Your Econometrics Homework Help for Academic Success</h2>
                            <p>We focus on helping students with econometrics assignments. If you study at university or in higher education, we understand your specific requirements. Tutors here are ready to support your academic journey. They provide solutions that are well-researched. Quality matters. Every detail counts for your success, and that's why we offer econometrics homework help.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     </section>

     <!-- Who Can Benefit from Our Econometrics Homework Help Services? -->
      <section>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Who Can Benefit from Our Econometrics Homework Help Services?</h2>
                            <p>Struggling with tough econometrics concepts? Many students find themselves in this situation. Tight deadlines add more pressure, but econometrics coursework help can make all the difference. No need to worry, though. Our services fit your needs perfectly. Whether living in a bustling city or a quiet village in the UK, help is available. Achieving academic goals can feel difficult at times. With our economic homework help, you can navigate these challenges more easily. Finding support is key. Feel free to reach out anytime you need. You're not alone in this journey.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>

      <!-- Expert Econometrics Assignment Help to Boost Your Grades -->
       <section>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Expert Econometrics Assignment Help to Boost Your Grades</h2>
                            <p>Experienced tutors in our team know how to make tough econometrics topics easier. You will find that complex ideas become clearer with our support, especially with our econometrics assignment solutions. Understanding the subject better is just a step away. Grades in your coursework can improve with the right assistance. Why struggle when help is available? Dive into econometrics confidently, and watch your skills grow with econometrics assignment help.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       </section>

       <!-- Immediate Help from Econometrics Tutors for Your Assignments -->
        <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="inner-column">
                                    <div class="section-color-layer"></div>
                                    <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Immediate Help from Econometrics Tutors for Your Assignments</h2>
                                    <p>Tight deadlines can make students feel stressed. Our expert tutors recognize this challenge. Immediate help is what we offer, including econometrics exam help. You won't have to stress about late submissions anymore. Getting timely assistance can change everything. Whenever you feel the pressure building, just reach out. Our team stands ready to support you. Students can focus on learning while we handle the rest. No more sleepless nights over assignments. Finding solutions is easier when <a href="https://www.assignnmentinneed.com/economic-assignment-writing-help"><b>economic assignment help</b></a>  is close by.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Popular Econometrics Topics Covered in Our Assignment Help -->
         <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Popular Econometrics Topics Covered in Our Assignment Help</h2>
                                <p>We provide help for many topics in econometrics. Regression analysis is one area we focus on, and our econometrics assignment solutions are designed to guide you through these complex topics. Time series modeling is another topic included, and econometrics coursework help is available to guide you through these complex subjects. Panel data analysis also falls under our support. Whatever your needs are for school, we have solutions just for you. Simple and specific, our help fits your situation with econometrics assignment help.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </section>

         <!-- Why Students Turn to Us for Last-Minute Econometrics Coursework Help? -->
          <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                                 <div class="title-box">
                                    <div class="section-color-layer"></div>
                                    <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Why Students Turn to Us for Last-Minute Econometrics Coursework Help?</h2>
                                    <p>Students trust us for quick and dependable support. Last-minute help? That's our specialty. Our service works efficiently to meet your needs. Completing assignments becomes much easier with our assistance. Quality and accuracy? We focus on those too, even under pressure. You don't have to sacrifice anything when you ask for help. Students feel relieved knowing we're here. Help arrives right when it is needed most. Every moment counts, and we make it count for you. Whether it's assignments or econometrics exam help, rely on us to navigate those tricky challenges together.</p>
                                </div>
                          </div>
                    </div>
                </div>
            </div>
          </section>

          <!-- Your Go-To Online Econometrics Assignment Help Service -->
           <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-laye"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4">Your Go-To Online Econometrics Assignment Help Service </h2>
                                <p>Students choose us for online econometrics help, and we take pride in that. Whether you are in Chelmsford, Hereford, Liverpool, or anywhere else, our support is available, including econometrics coursework help to meet your needs. Quality and affordability drive our service, and with econometrics assignment solutions, we ensure that you get the best support for your needs. Many students across the UK trust us for their needs. Why look elsewhere when reliable econometrics assignment help is right here? Your success in econometrics matters to us.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           </section>





      <!-- new section -->

	 <section class="py-4" style="background-color:#BFECFF;"  >
	            <div class="auto-container">
                    <div class="row clearfix">

			<!-- Content Column -->
			  <div class="content-column col-lg-6 col-md-12 col-sm-12">
				 <div class="inner-column">
					<h2 class="py-3" style="font-weight:500; font-size: 30px; color:black">Assignment in Need Help With Econometrics Assignment and Homework Help For Students Worldwide </h2>
					  <div class="text">
					   <p>Struggling with econometrics? Assignment In Need is here to make things easier! Our Econometrics Assignment Help services cover complex topics like regression models, time-series analysis, and data forecasting, for students in the UK, Canada, Australia, Malaysia, UAE, Spain and more. With 3,000+ PhD experts, we've delivered 45,000+ assignments, ensuring academic excellence for students worldwide. Our services guarantee timely delivery and a clear understanding of econometrics topics, helping you achieve better grades in academics. Choose us to turn your academic challenges into success.</p>
                    </div>
					 
			          <a href="/upload-your-assignment"> <button style="background: #37AFE1;  color:black; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >Order Now</button> </a>	 
			     </div>
			 </div>

			<!-- Image Column -->
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">
					 <div class="image titlt"  style="mix-blend-mode: multiply;">
						<img src="images2\resource\unnamed (5).png  " alt="">  
					</div>        
				</div>
			</div>

		</div>
	</div>
            </section>

            <!-- end new section -->
 
	    <!-- FAQs Question  section for Expert Assignment Writing Help -->
 
	        
		<section class="faq-section bg-light">
	    	<div class="auto-container">
			<div class="row ">
				<div class="titel-column col-lg-12 col-md-12 col-sm-12">  
				    <div class="title-box text-center">
						<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4"><b>Frequently Asked Questions For Econometrics Assignment Help Online</b></h2> 
					 </div>
					<div class="row"> 
					 		 
				<div class="column col-lg-6 col-md-6 col-sm-12 ">
					 
					<ul class="accordion-box ">
					       <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">1. What Is the Purpose of Econometrics?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <p>Econometrics measures how economic variables relate to each other. It uses statistical tools for this task. </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">2. What Are the Three Major Problems of Econometrics?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Three big problems exist in econometrics. Multicollinearity is one of them. Autocorrelation causes issues as well.   </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            
                  	</ul>
					
				</div>
			
				<div class="column col-lg-6 col-md-6 col-sm-12">
					 
					<ul class="accordion-box">
                    <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">3. What Are the Three Major Uses of Econometrics?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Econometrics serves many important purposes. It plays a role in evaluating policies. Economic forecasting is another major use.  </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">4. What Are the Techniques of Econometrics?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Many techniques help in econometrics. Regression analysis tops the list. Hypothesis testing also plays a crucial role. </p>
										</div>
                                    </div>
                                </div>
                            </li>
					</ul>
					
				</div>
				 
				 
			     </div>
				   <div class="title-box text-center">
				   <button style="background: #37AFE1;  color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >View More FAQs</button>
				   </div> 

				</div> 
				 
 			</div>
			  
		</div>
		 
   </section> 

	   
@endsection