  
 @extends('frontend-layouts.app')

@section('content')


<style>
		.text {
			color: #0c0d24;
			line-height: 1.8em;
			font-size: 16px;
		}
		.text-black{
			color: black;
			
		}
		.banner-section-three .content-column .inner-column {
			padding-top: 5px;
		}
		
	</style>
	<style>
		.iti {
			position: relative;
			display: inline-block;
			width: 100%;
		}
	</style>

	<style>
		.header-section 
		{
			background: rgb(255,255,255);
			background: linear-gradient(170deg, rgba(255,255,255,1) 6%, rgba(135,166,219,0.4009978991596639) 72%, rgba(135,166,219,0.5690651260504201) 91%, rgba(126,137,221,0.865983893557423) 100%);
		}

		h1 {
			font-size: 35px;
			font-weight: 600;
			color: black
			}

		p {
			position: relative;
			line-height: 1.8em;
			font-size: large;
			color:black;
			text-align: justify;
		}
		.place-order 
		{
			background:#d7f0fd; 
			color:black;
			padding: 10px 20px;
			border-radius: 5%;
			margin: 10px;
		}
		.place-now
		{
			background:#77bfe5; 
			color:black;
			padding: 20px 80px;
			border-radius: 3%;
			margin: 10px;
			font-weight: 500;
			font-size: 20px;
		}
		.place-order:hover
		{
			background:#7e89dd;
			color:white ;

		}
		.place-now:hover
		{
			box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;			
			color: white;
			transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */

		}
		.order-now		
		{
			font-size: 25px;
			font-weight: 500;	
			color: black;
		}

		.offer-badge {
		    position: absolute;
			top: -65px;
			right: -30px;
			color: white;
			font-weight: bold;
			border-radius: 10%;
			font-size: 17px;
			z-index: 0;
		}
		.banner-stats-title
		{
			font-size: 30px;
			font-weight: 600;
			color: black;
		}
		.banner-stats-container {
			display: flex;
			justify-content: space-between;
			text-align: center;
		}

		.banner-stat {
			flex: 1;
			padding: 0 10px; /* Adjust the space between elements */
		}

		.banner-stats-text {
			font-size: 1em;
			margin-top: 5px;
		}
		
		ul 
		{
			font-size: 17px;
			color: black;
		}

		h3 
		{
			font-size: 21px;
			font-weight: 500;
			color: black;
		}

		@media (min-width: 768px) {
		.content {
			flex-direction: row;
			align-items: flex-start;
			justify-content: center;
			text-align: left;
		}

			.image-container {
				width: 50%;
			}

			.text-content {
				width: 50%;
				margin-left: 40px;
			}

			.text-content h2 {
				font-size: 2rem;
			}
		}

		.current_offer
		{
			font-weight: bold;
			font-size: 35px;
		}

		.offer-container
		{
			background: rgb(221,245,245);
			background: -moz-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: -webkit-linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,214,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 68%, rgba(110,186,231,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ddf5f5",endColorstr="#6ebae7",GradientType=1);
						background-color: white; 
			border-radius: 
			5px; 
			box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); 
			padding: 20px;
		}

		@media (min-width: 1200px) {
    .container {
        max-width: 1199px;
    }
}
	.offer-badge-offer {
		position: absolute;
		top: -8px;
		right: 23px;
		color: white;
		font-weight: bold;
		border-radius: 10%;
		font-size: 17px;
		z-index: 0;
	}
	.offer-badge-offer:hover{

		box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
				transition: box-shadow 0.4s ease-in-out, color 0.3s ease-in-out; /* Smooth transition */
	}

	.testimonial-section-three .owl-carousel .owl-stage-outer {
    padding: 0px 0px 0px;
}
      /* Assignment Writing */
	</style>
	<section class="banner-section-three header-section" >
		<div class="auto-container" style="margin-top: 100px;">
			<div style="text-align: center;">
				<ul class="page-breadcrumb">
					<!-- <li><a href="/">Home</a></li>
					<li>Math Assignment</li> -->
				</ul>
            </div>
            <div class="row clearfix">
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h1 class="text-center">Get Professional Physical Geography Assignment Help | Physical Geography Homework Help For Students
						</h1>
					</div>
				<div>
			</div>
			<div class="mt-2" style="padding: 20px;">
				<div class="banner-stats-container">
					<div class="banner-stat">
						<div class="banner-stats-title">98.2%</div>
						
						<div class="banner-stats-text"><i class="fa fa-star"></i> Orders Arrive Timely</div>
					</div>
					<div class="banner-stat">
						<div class="banner-stats-title">9/10</div>
						
						<div class="banner-stats-text"><i class="fa fa-graduation-cap"> </i> Report Better Grades</div>
					</div>
				</div>
			</div>

			
			<div class="mt-2" style="background-color: white; border-radius: 5px; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, .08); padding: 20px;">
				<div style="display: flex; align-items: center;">
					<div style="width: 50px;">
						<img src="assets/media/avatars/assignment_logo.png" alt="Client Logo" style="max-width: 100%;">
					</div>
					<!-- Second Section: Review Banner -->
					<div style="flex-grow: 1; margin-left: 20px;">
						<div style="display: flex; align-items: center;">
							<div style="flex-grow: 1;">
								<span style="font-size: 20px; font-weight: bold;">Client Reviews </span>
							</div>
							<div style="display: flex; align-items: center;">
								<!-- Star Rating -->
								<span style="font-size:20px; margin-right: 10px;">
									<i style="color:gold" class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star"></i>
									<i style="color:gold"class="fa fa-star-half-o"></i> <!-- Half-active star -->
								</span>
								<!-- Rating Number -->
								<span style="font-size: 20px; font-weight: bold; color: #333;">4.5 / 5 Ratting</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
				
		@include('formsection')
			</section>


		<section class="news-section-two py-3 mt-3">
		<div class="auto-container">
			<div class="row clearfix">
				<div class="col-md-12 col-md-offset-2">
					<h2 style="font-weight:500; font-size: 30px;; color:black" class="text-center my-4">How Our do Physical Geography Help Service Work?</h2>
					<!-- <p class="textCommon text-center">How Our Quality Assignment Writing Services Work  in Assignment ?</p> -->
				</div>
				<div class="blocks-column col-lg-12 col-md-12 col-sm-12 mt-2">
					<div class="inner-column">
						<div class="row clearfix p-2">
							<div class="column col-lg-4 col-md-4 col-sm-12 ">
								<div class="news-block-four mt-0">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/shopping-list.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Submit Your Order</a></h3>
										<div class="text">Fill in the 'order now' form, mention your basic information and specific requirements that you want us to meet.</div>
										
									</div>
								</div>
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="150ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 150ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/secure-payment.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Make Secure Payment</a></h3>
										<div class="text">Pay an affordable price for the assignment help provided to you via our secure payment gateway that is fully protected from privacy infringements.</div>
									</div>
								</div>
								
							</div>
							<div class="column col-lg-4 col-md-4 col-sm-12">
								<div class="news-block-four">
									<div class="inner-box wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
										<span style="display: inline-block; width: auto; height: 150px;">
											<img src="images/sharing.png" alt="" style="width: 100%; height: 100%;">
										</span>
										<h3><a>Receive Your Paper</a></h3>
										<div class="text">
											Get a high-quality assignment writing services by our expert writers within the given deadline and score better than your expectations.
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Claim Your Offer -->
	<section  class=" pt-3 pb-3" >
		<div class="content-section-white">
			
			<div class="container" >
				
				<div class="offer-container row pb-0">
					
					<div class="col-md-4 col-xs-12 mb-3">
					</div>
					<div class="col-md-6 col-xs-12 mb-3 test">
						
						<h2 style="font-weight:500; font-size: 30px;; color:black">Claim Your Offer</h2>
					</div>
					<div class="col-md-4 col-xs-12">
						<div class="offer-badge-offer"><img src="assets/media/avatars/offer.png" alt=""></div> 
						<div style="heught:100px" class="offer-text hidden-xs"><img src="assets/media/avatars/fashionable-young-man-with-stubble-has-surprised-expression.png" alt=""></div>
					</div>
					<div class="col-md-6 col-xs-12 mt-3">

						<p class="offer-title">Type your whatsapp number to get an exclusive code. </p>
						<div class="clearfix"></div>
						<span id="offerWhatsappSuccessMsg2"></span>
						<div class="offer-input-box">
							<form class="onload-offer-form" id="offerWhatsappForm2" onkeydown="return event.key != 'Enter';">
								<div class="contact-right-container">
									<div class="form-group d-flex">
										<div class="col-sm-2" style="padding-left:0;padding-right:0">
											<input type="text" id="isdCode2" style="border-left: 2px solid #ccc;" placeholder="+1" class="form-control">
										</div>
										<div class="col-sm-10" style="padding-left:0;padding-right:0">
											<input type="text" name="offerWhatsappNumber" id="offerWhatsappNumber2" class="form-control" placeholder="Enter Your Whats App No.">
										</div>
										<button type="button" id="offerWhatsappBtn2" class="btn btn-secondary btn-bg-red" style="background:#33b533"><i class="fa fa-whatsapp"></i> </button>
									</div>
								</div>
							</form>
							<div style="text-center">
								<a href="/Offers"><button class=" place-now">View More Offer</button></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Our Writer -->
 @if($data['expert']->isEmpty())
    
@else
    <!-- Case: Experts are available -->
    <section class="testimonial-section-three py-0">
        <div class="color-layer"></div>
        <div class="auto-container">
            <div class="sec-title">
                <div class="section-color-layer"></div>
                <h2 style="font-weight:500; font-size: 30px; color:black">
                Our Writer For Professional Physical Assignment help
                </h2>
            </div>
            <div class="testimonial-carousel-three owl-carousel owl-theme">
                @foreach($data['expert'] as $expert)
                    <!-- Testimonial Block Three -->
                    <div class="testimonial-block-three">
                        <div class="inner-box">
                            <div class="image-outer">
                                <div class="image">
                                    <img src="{{$expert->image}}" alt="Expert Image" />
                                </div>
                                <div class="quote flaticon-left-quote"></div>
                            </div>
                            <h6>{{$expert->name}}</h6>
                            <div class="designation" style="
                                color: blue !important;
                                margin: 0 auto;
                                text-align: center;
                                width: auto;
                                padding: 5px 15px;
                                border-radius: 20px;
                                font-size: 20px;
                                font-weight: 700;">
                                {{$expert->service}}
                            </div>
                            <div class="text" style="text-align: justify; margin-top: 10px;">
                                <span class="short-content">
                                    {{ Str::limit($expert->content, 150) }}
                                </span>
                                <span class="full-content" style="display: none;">
                                    {{$expert->content}}
                                </span>
                                <button class="btn-toggle" onclick="toggleContent(this)" style="
                                    margin-top: 5px;
                                    border: none;
                                    background-color: transparent;
                                    color: #007BFF;
                                    cursor: pointer;">
                                    ...
                                </button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="lower-text">Click the button for slide</div>
        </div>
    </section>
@endif

	<script>
    function toggleContent(button) {
        const textContainer = button.parentElement;
        const shortContent = textContainer.querySelector('.short-content');
        const fullContent = textContainer.querySelector('.full-content');

        if (shortContent.style.display === 'none') {
            shortContent.style.display = '';
            fullContent.style.display = 'none';
            button.textContent = '...';
        } else {
            shortContent.style.display = 'none';
            fullContent.style.display = '';
            button.textContent = 'Less';
        }
    }
</script>

    <!-- Online Physical Geography Assignment Writing Help Services -->
	<section class=" py-0">
		<div class="auto-container ">
			<div class="row clearfix">
				<div class="title-column col-lg-12 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<div class="section-color-layer"></div>
							<h2 style="font-weight:500; font-size: 30px;; color:black" class=" my-4">Online Physical Geography Assignment Writing Help Services</h2>
                              <p>At <a href="https://www.assignnmentinneed.com"><b>Assignment in Need</b></a> , we help students in the UK with physical geography tasks. Need physical geography assignment help for your school or university work? Our team of experts is ready to provide guidance just for you. No matter if you're located in Wakefield, Winchester, York, or anywhere else, our services make it easier for you to succeed in this interesting subject with physical geography help online.</p>
                            </div>
					</div>
				</div>
			</div>
		</div>
	</section>
       <!-- order box -->
	<section class=" pt-3 pb-3">
		<div class="auto-container ">
			<div class="my-5 images-container" style="position: relative; border-radius: 5px; overflow: hidden; box-shadow: 0 1rem 1rem 0 rgba(0, 0, 0, 0.08);">
				<div style="background: linear-gradient(275deg, rgba(221,245,245,1) 0%, rgba(175,213,232,0.23012955182072825) 10%, rgba(155,205,231,0.43461134453781514) 21%, rgba(110,186,231,1) 100%); background-size: cover; background-position: center; height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: 1;"></div>
				<div style="background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.9)); position: absolute; top: 0; left: 0; height: 100%; width: 100%; z-index: 2;"></div>
				<div class="container" style="position: relative; z-index: 3;">
					<div class="row">
						<div class="col-md-4">
							<img src="assets/media/avatars/books-with-graduation-cap-digital-art-style-education-day-removebg-preview.png" alt="Client Logo" class="img-fluid">
						</div>
						<div class="col-md-6 mt-4">
							<h2 style="font-size: 30px; font-weight: 600; color: black; margin-bottom: 10px; align-items:justify">Order our Physical Geography Help today and enjoy a special discount!</h2>
							<p>Get help with your assignments easily and stress-free with our expert helpers!</p>
							<div style="text-center">
								<a href="/upload-your-assignment"><button class=" place-now">Order Now</button></a>
							</div>
						</div>
					</div>
				</div>
				</div>
				</div>
	</section>
	  
    <!-- Get Expert Help with Your Physical Geography Assignments Online -->
     <section>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-laye"></div>
                            <h2 style="font-weight:500; font-size: 30px;; color:black" class=" my-4">Get Expert Help with Your Physical Geography Assignments Online</h2>
                            <p>Dealing with physical geography assignments can feel a bit tough, right? Luckily, help is at hand. Our online platform pairs you with skilled experts eager to provide physical geography help online and guide you through your academic troubles. You will find detailed solutions that suit your needs, along with support just for you. For those seeking <a href="https://www.assignnmentinneed.com/geography-assignment-writing-help"><b>geography assignment help</b></a> , think of us as your reliable friend in reaching success in school, whatever part of the UK you are in.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     </section>

     <!-- What Our Students Say about Our Physical Geography Assignment Help? -->
      <section>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size: 30px;; color:black" class=" my-4">What Our Students Say about Our Physical Geography Assignment Help?</h2>
                            <p>Students in the UK often praise our dependable and efficient services. Many find our focus on quality and fast help important. One student said, "Assignment in Need gave me clear answers and quick support for my tasks," including physical geography assignment help when I needed it most.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>

      <!-- Why Hiring Our Physical Geography Homework Help Is a Smart Choice? -->
      <section>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-laye"></div>
                            <h2 style="font-weight:500; font-size: 30px;; color:black" class=" my-4">Why Hiring Our Physical Geography Homework Help Is a Smart Choice?</h2>
                            <p>Our homework help service is different because we focus on what you need for each assignment. Choosing us means you get the benefit of our team's knowledge and dedication to doing a good job, including physical geography help online for your assignments. Need physical geography homework help to wrap your head around tough ideas? Or maybe you have a deadline that feels too close? We make sure that your time in school stays easy and without stress.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>

      <!-- Reliable and Professional Physical Geography Homework Help – Your Ultimate Resource -->
       <section>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-lg-12 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box">
                            <div class="section-color-layer"></div>
                            <h2 style="font-weight:500; font-size: 30px;; color:black" class=" my-4">Reliable and Professional Physical Geography Homework Help - Your Ultimate Resource</h2>
                            <p>Choosing Assignment in Need means you pick a service that cares about professionalism and trust. An expert team works hard to provide well-researched, solid assignments. For those looking for physical geography homework help, with years of experience in physical geography, you find us as your key source for grasping tough topics and sharing them clearly in your school work.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       </section>

       <!-- Physical Geography Topics We Cover -->
        <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="titiel-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class=" my-4">Physical Geography Topics We Cover</h2>
                                <p>A wide variety of physical geography topics are part of what we offer, like climatology, hydrology, geomorphology, and soil science. Experts on our team do a great job of breaking down complicated theories and showing how they work in real life. If you want to learn about tectonic processes or biogeographical patterns, look no further. For physical geography help online that fits your exact academic needs, we provide the support you need.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Advantages of Getting Physical Geography Assignment Assistance -->
         <section>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="title-column col-lg-12 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-box">
                                <div class="section-color-layer"></div>
                                <h2 style="font-weight:500; font-size: 30px;; color:black" class=" my-4">Advantages of Getting Physical Geography Assignment Assistance</h2>
                                <p>Working with Assignment in Need gives you many benefits. You get expert help, save time, and see better grades. A professional approach helps you understand tough ideas while creating clear, quality assignments. For those seeking physical geography assignment help, we are committed to your success and are here to help you do well in your physical geography studies.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </section>



      <!-- new section -->

	 <section class="py-4" style="background-color:#BFECFF;"  >
	            <div class="auto-container">
                    <div class="row clearfix">

			<!-- Content Column -->
			  <div class="content-column col-lg-6 col-md-12 col-sm-12">
				 <div class="inner-column">
					<h2 class="py-3" style="font-weight:500; font-size: 30px; color:black">Assignment in Need Help With Physical Geography Help and Homework Help For Students Across the Global </h2>
					  <div class="text">
					   <p>Navigating the challenges of physical geography? Assignment in Need is here to provide you with the solution! Our Physical Geography Help covers almost everything, from landform and climate systems to hydrology and ecosystem analysis for students in the UK, Canada, Australia, Malaysia, UAE, Spain, and beyond. With over 30,000 satisfied clients and more than 7+ years of experience, we ensure very accurate, reliable assignment solutions that ensure timely submission and better grades. Whether you're tackling tough assignments or preparing for exams, trust us to deliver quality every time.</p>
                    </div>
					 
			          <a href="/upload-your-assignment"> <button style="background: #37AFE1;  color:black; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >Order Now</button> </a>	 
			     </div>
			 </div>

			<!-- Image Column -->
			<div class="image-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">
					 <div class="image titlt"  style="mix-blend-mode: multiply;">
						<img src="images2\resource\unnamed (5).png  " alt="">  
					</div>        
				</div>
			</div>

		</div>
	</div>
            </section>

            <!-- end new section -->
 
	    <!-- FAQs Question  section for Expert Assignment Writing Help -->
 
	        
		<section class="faq-section bg-light">
	    	<div class="auto-container">
			<div class="row ">
				<div class="titel-column col-lg-12 col-md-12 col-sm-12">  
				    <div class="title-box text-center">
						<h2 style="font-weight:500; font-size: 30px;; color:black" class="my-4"><b>Frequently Asked Questions For Physical Geography Help </b></h2> 
					 </div>
					<div class="row"> 
					 		 
				<div class="column col-lg-6 col-md-6 col-sm-12 ">
					 
					<ul class="accordion-box ">
					       <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">1. How Does Physical Geography Work?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                           <p>Physical geography looks at natural processes. These include climate, landforms, and ecosystems. The idea is to understand how Earth's systems work and change over time. </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">2. What Is the Purpose of Geography?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Geography links people and the environment. This connection helps in making smart choices for living in a way that does not harm the planet. </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            
                  	</ul>
					
				</div>
			
				<div class="column col-lg-6 col-md-6 col-sm-12">
					 
					<ul class="accordion-box">
                    <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">3. What Are the Benefits of Physical Geography?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Managing resources gets easier with this knowledge. Predictions about natural disasters become clearer, which is pretty helpful. </p>
										</div>
                                    </div>
                                </div>
                            </li>
                            <li class="accordion block">
                                <div class="acc-btn bg-white border " style="font-weight:500; font-size: 20px;; color:black">4. How Has Physical Geography Evolved?<div class="icon fa fa-angle-down"></div></div>
                                <div class="acc-content">
                                    <div class="content">
                                        <div class="text">
                                          <p>Technology has made big changes, especially with tools like satellite images. Now, physical geography can give us clearer views of how the Earth works. </p>
										</div>
                                    </div>
                                </div>
                            </li>
					</ul>
					
				</div>
				 
				 
			     </div>
				   <div class="title-box text-center">
				   <button style="background: #37AFE1;  color:white; padding: 20px 80px; border-radius: 50px; margin: 10px; font-weight: 500; 	font-size: 20px;  " >View More FAQs</button>
				   </div> 

				</div> 
				 
 			</div>
			  
		</div>
		 
   </section> 

	   
@endsection